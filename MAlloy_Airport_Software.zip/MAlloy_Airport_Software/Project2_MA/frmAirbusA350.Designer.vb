﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAirbusA350
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Labe = New System.Windows.Forms.Label()
        Me.Label = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.LabelD = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.btnReserveSeat = New System.Windows.Forms.Button()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.A1 = New System.Windows.Forms.CheckBox()
        Me.B1 = New System.Windows.Forms.CheckBox()
        Me.B2 = New System.Windows.Forms.CheckBox()
        Me.A2 = New System.Windows.Forms.CheckBox()
        Me.B3 = New System.Windows.Forms.CheckBox()
        Me.A3 = New System.Windows.Forms.CheckBox()
        Me.B4 = New System.Windows.Forms.CheckBox()
        Me.A4 = New System.Windows.Forms.CheckBox()
        Me.B5 = New System.Windows.Forms.CheckBox()
        Me.A5 = New System.Windows.Forms.CheckBox()
        Me.B6 = New System.Windows.Forms.CheckBox()
        Me.A6 = New System.Windows.Forms.CheckBox()
        Me.B7 = New System.Windows.Forms.CheckBox()
        Me.A7 = New System.Windows.Forms.CheckBox()
        Me.B8 = New System.Windows.Forms.CheckBox()
        Me.A8 = New System.Windows.Forms.CheckBox()
        Me.B9 = New System.Windows.Forms.CheckBox()
        Me.A9 = New System.Windows.Forms.CheckBox()
        Me.B10 = New System.Windows.Forms.CheckBox()
        Me.A10 = New System.Windows.Forms.CheckBox()
        Me.B11 = New System.Windows.Forms.CheckBox()
        Me.A11 = New System.Windows.Forms.CheckBox()
        Me.B12 = New System.Windows.Forms.CheckBox()
        Me.A12 = New System.Windows.Forms.CheckBox()
        Me.D12 = New System.Windows.Forms.CheckBox()
        Me.C12 = New System.Windows.Forms.CheckBox()
        Me.D11 = New System.Windows.Forms.CheckBox()
        Me.C11 = New System.Windows.Forms.CheckBox()
        Me.D10 = New System.Windows.Forms.CheckBox()
        Me.C10 = New System.Windows.Forms.CheckBox()
        Me.D9 = New System.Windows.Forms.CheckBox()
        Me.C9 = New System.Windows.Forms.CheckBox()
        Me.D8 = New System.Windows.Forms.CheckBox()
        Me.C8 = New System.Windows.Forms.CheckBox()
        Me.D7 = New System.Windows.Forms.CheckBox()
        Me.C7 = New System.Windows.Forms.CheckBox()
        Me.D6 = New System.Windows.Forms.CheckBox()
        Me.C6 = New System.Windows.Forms.CheckBox()
        Me.D5 = New System.Windows.Forms.CheckBox()
        Me.C5 = New System.Windows.Forms.CheckBox()
        Me.D4 = New System.Windows.Forms.CheckBox()
        Me.C4 = New System.Windows.Forms.CheckBox()
        Me.D3 = New System.Windows.Forms.CheckBox()
        Me.C3 = New System.Windows.Forms.CheckBox()
        Me.D2 = New System.Windows.Forms.CheckBox()
        Me.C2 = New System.Windows.Forms.CheckBox()
        Me.D1 = New System.Windows.Forms.CheckBox()
        Me.C1 = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'Labe
        '
        Me.Labe.Location = New System.Drawing.Point(85, 24)
        Me.Labe.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Labe.Name = "Labe"
        Me.Labe.Size = New System.Drawing.Size(28, 26)
        Me.Labe.TabIndex = 63
        Me.Labe.Text = "A"
        Me.Labe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label
        '
        Me.Label.Location = New System.Drawing.Point(137, 24)
        Me.Label.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label.Name = "Label"
        Me.Label.Size = New System.Drawing.Size(28, 26)
        Me.Label.TabIndex = 64
        Me.Label.Text = "B"
        Me.Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(221, 24)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(28, 26)
        Me.Label3.TabIndex = 65
        Me.Label3.Text = "C"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelD
        '
        Me.LabelD.Location = New System.Drawing.Point(273, 24)
        Me.LabelD.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelD.Name = "LabelD"
        Me.LabelD.Size = New System.Drawing.Size(28, 26)
        Me.LabelD.TabIndex = 66
        Me.LabelD.Text = "D"
        Me.LabelD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(179, 61)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(28, 26)
        Me.Label5.TabIndex = 67
        Me.Label5.Text = "1"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(179, 96)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(28, 26)
        Me.Label6.TabIndex = 68
        Me.Label6.Text = "2"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label15
        '
        Me.Label15.Location = New System.Drawing.Point(179, 337)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(28, 26)
        Me.Label15.TabIndex = 77
        Me.Label15.Text = "9"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(179, 130)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(28, 26)
        Me.Label7.TabIndex = 69
        Me.Label7.Text = "3"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label14
        '
        Me.Label14.Location = New System.Drawing.Point(179, 371)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(28, 26)
        Me.Label14.TabIndex = 76
        Me.Label14.Text = "10"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(179, 164)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(28, 26)
        Me.Label8.TabIndex = 70
        Me.Label8.Text = "4"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label13
        '
        Me.Label13.Location = New System.Drawing.Point(179, 406)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(28, 26)
        Me.Label13.TabIndex = 75
        Me.Label13.Text = "11"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(179, 199)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(28, 26)
        Me.Label9.TabIndex = 71
        Me.Label9.Text = "5"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(179, 440)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(28, 26)
        Me.Label12.TabIndex = 74
        Me.Label12.Text = "12"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(179, 233)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(28, 26)
        Me.Label10.TabIndex = 72
        Me.Label10.Text = "6"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label16
        '
        Me.Label16.Location = New System.Drawing.Point(179, 302)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(28, 26)
        Me.Label16.TabIndex = 78
        Me.Label16.Text = "8"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(179, 268)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(28, 26)
        Me.Label11.TabIndex = 73
        Me.Label11.Text = "7"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnReserveSeat
        '
        Me.btnReserveSeat.Location = New System.Drawing.Point(37, 508)
        Me.btnReserveSeat.Margin = New System.Windows.Forms.Padding(4)
        Me.btnReserveSeat.Name = "btnReserveSeat"
        Me.btnReserveSeat.Size = New System.Drawing.Size(139, 70)
        Me.btnReserveSeat.TabIndex = 127
        Me.btnReserveSeat.Text = "Reserve Seat"
        Me.btnReserveSeat.UseVisualStyleBackColor = True
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(209, 508)
        Me.btnCancel.Margin = New System.Windows.Forms.Padding(4)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(139, 70)
        Me.btnCancel.TabIndex = 128
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'A1
        '
        Me.A1.AutoSize = True
        Me.A1.Location = New System.Drawing.Point(88, 67)
        Me.A1.Name = "A1"
        Me.A1.Size = New System.Drawing.Size(18, 17)
        Me.A1.TabIndex = 129
        Me.A1.UseVisualStyleBackColor = True
        '
        'B1
        '
        Me.B1.AutoSize = True
        Me.B1.Location = New System.Drawing.Point(140, 67)
        Me.B1.Name = "B1"
        Me.B1.Size = New System.Drawing.Size(18, 17)
        Me.B1.TabIndex = 130
        Me.B1.UseVisualStyleBackColor = True
        '
        'B2
        '
        Me.B2.AutoSize = True
        Me.B2.Location = New System.Drawing.Point(140, 102)
        Me.B2.Name = "B2"
        Me.B2.Size = New System.Drawing.Size(18, 17)
        Me.B2.TabIndex = 132
        Me.B2.UseVisualStyleBackColor = True
        '
        'A2
        '
        Me.A2.AutoSize = True
        Me.A2.Location = New System.Drawing.Point(88, 102)
        Me.A2.Name = "A2"
        Me.A2.Size = New System.Drawing.Size(18, 17)
        Me.A2.TabIndex = 131
        Me.A2.UseVisualStyleBackColor = True
        '
        'B3
        '
        Me.B3.AutoSize = True
        Me.B3.Location = New System.Drawing.Point(140, 136)
        Me.B3.Name = "B3"
        Me.B3.Size = New System.Drawing.Size(18, 17)
        Me.B3.TabIndex = 134
        Me.B3.UseVisualStyleBackColor = True
        '
        'A3
        '
        Me.A3.AutoSize = True
        Me.A3.Location = New System.Drawing.Point(88, 136)
        Me.A3.Name = "A3"
        Me.A3.Size = New System.Drawing.Size(18, 17)
        Me.A3.TabIndex = 133
        Me.A3.UseVisualStyleBackColor = True
        '
        'B4
        '
        Me.B4.AutoSize = True
        Me.B4.Location = New System.Drawing.Point(140, 170)
        Me.B4.Name = "B4"
        Me.B4.Size = New System.Drawing.Size(18, 17)
        Me.B4.TabIndex = 136
        Me.B4.UseVisualStyleBackColor = True
        '
        'A4
        '
        Me.A4.AutoSize = True
        Me.A4.Location = New System.Drawing.Point(88, 170)
        Me.A4.Name = "A4"
        Me.A4.Size = New System.Drawing.Size(18, 17)
        Me.A4.TabIndex = 135
        Me.A4.UseVisualStyleBackColor = True
        '
        'B5
        '
        Me.B5.AutoSize = True
        Me.B5.Location = New System.Drawing.Point(140, 205)
        Me.B5.Name = "B5"
        Me.B5.Size = New System.Drawing.Size(18, 17)
        Me.B5.TabIndex = 138
        Me.B5.UseVisualStyleBackColor = True
        '
        'A5
        '
        Me.A5.AutoSize = True
        Me.A5.Location = New System.Drawing.Point(88, 205)
        Me.A5.Name = "A5"
        Me.A5.Size = New System.Drawing.Size(18, 17)
        Me.A5.TabIndex = 137
        Me.A5.UseVisualStyleBackColor = True
        '
        'B6
        '
        Me.B6.AutoSize = True
        Me.B6.Location = New System.Drawing.Point(140, 239)
        Me.B6.Name = "B6"
        Me.B6.Size = New System.Drawing.Size(18, 17)
        Me.B6.TabIndex = 140
        Me.B6.UseVisualStyleBackColor = True
        '
        'A6
        '
        Me.A6.AutoSize = True
        Me.A6.Location = New System.Drawing.Point(88, 239)
        Me.A6.Name = "A6"
        Me.A6.Size = New System.Drawing.Size(18, 17)
        Me.A6.TabIndex = 139
        Me.A6.UseVisualStyleBackColor = True
        '
        'B7
        '
        Me.B7.AutoSize = True
        Me.B7.Location = New System.Drawing.Point(140, 274)
        Me.B7.Name = "B7"
        Me.B7.Size = New System.Drawing.Size(18, 17)
        Me.B7.TabIndex = 142
        Me.B7.UseVisualStyleBackColor = True
        '
        'A7
        '
        Me.A7.AutoSize = True
        Me.A7.Location = New System.Drawing.Point(88, 274)
        Me.A7.Name = "A7"
        Me.A7.Size = New System.Drawing.Size(18, 17)
        Me.A7.TabIndex = 141
        Me.A7.UseVisualStyleBackColor = True
        '
        'B8
        '
        Me.B8.AutoSize = True
        Me.B8.Location = New System.Drawing.Point(140, 308)
        Me.B8.Name = "B8"
        Me.B8.Size = New System.Drawing.Size(18, 17)
        Me.B8.TabIndex = 144
        Me.B8.UseVisualStyleBackColor = True
        '
        'A8
        '
        Me.A8.AutoSize = True
        Me.A8.Location = New System.Drawing.Point(88, 308)
        Me.A8.Name = "A8"
        Me.A8.Size = New System.Drawing.Size(18, 17)
        Me.A8.TabIndex = 143
        Me.A8.UseVisualStyleBackColor = True
        '
        'B9
        '
        Me.B9.AutoSize = True
        Me.B9.Location = New System.Drawing.Point(140, 343)
        Me.B9.Name = "B9"
        Me.B9.Size = New System.Drawing.Size(18, 17)
        Me.B9.TabIndex = 146
        Me.B9.UseVisualStyleBackColor = True
        '
        'A9
        '
        Me.A9.AutoSize = True
        Me.A9.Location = New System.Drawing.Point(88, 343)
        Me.A9.Name = "A9"
        Me.A9.Size = New System.Drawing.Size(18, 17)
        Me.A9.TabIndex = 145
        Me.A9.UseVisualStyleBackColor = True
        '
        'B10
        '
        Me.B10.AutoSize = True
        Me.B10.Location = New System.Drawing.Point(140, 377)
        Me.B10.Name = "B10"
        Me.B10.Size = New System.Drawing.Size(18, 17)
        Me.B10.TabIndex = 148
        Me.B10.UseVisualStyleBackColor = True
        '
        'A10
        '
        Me.A10.AutoSize = True
        Me.A10.Location = New System.Drawing.Point(88, 377)
        Me.A10.Name = "A10"
        Me.A10.Size = New System.Drawing.Size(18, 17)
        Me.A10.TabIndex = 147
        Me.A10.UseVisualStyleBackColor = True
        '
        'B11
        '
        Me.B11.AutoSize = True
        Me.B11.Location = New System.Drawing.Point(140, 412)
        Me.B11.Name = "B11"
        Me.B11.Size = New System.Drawing.Size(18, 17)
        Me.B11.TabIndex = 150
        Me.B11.UseVisualStyleBackColor = True
        '
        'A11
        '
        Me.A11.AutoSize = True
        Me.A11.Location = New System.Drawing.Point(88, 412)
        Me.A11.Name = "A11"
        Me.A11.Size = New System.Drawing.Size(18, 17)
        Me.A11.TabIndex = 149
        Me.A11.UseVisualStyleBackColor = True
        '
        'B12
        '
        Me.B12.AutoSize = True
        Me.B12.Location = New System.Drawing.Point(140, 446)
        Me.B12.Name = "B12"
        Me.B12.Size = New System.Drawing.Size(18, 17)
        Me.B12.TabIndex = 152
        Me.B12.UseVisualStyleBackColor = True
        '
        'A12
        '
        Me.A12.AutoSize = True
        Me.A12.Location = New System.Drawing.Point(88, 446)
        Me.A12.Name = "A12"
        Me.A12.Size = New System.Drawing.Size(18, 17)
        Me.A12.TabIndex = 151
        Me.A12.UseVisualStyleBackColor = True
        '
        'D12
        '
        Me.D12.AutoSize = True
        Me.D12.Location = New System.Drawing.Point(283, 446)
        Me.D12.Name = "D12"
        Me.D12.Size = New System.Drawing.Size(18, 17)
        Me.D12.TabIndex = 176
        Me.D12.UseVisualStyleBackColor = True
        '
        'C12
        '
        Me.C12.AutoSize = True
        Me.C12.Location = New System.Drawing.Point(231, 446)
        Me.C12.Name = "C12"
        Me.C12.Size = New System.Drawing.Size(18, 17)
        Me.C12.TabIndex = 175
        Me.C12.UseVisualStyleBackColor = True
        '
        'D11
        '
        Me.D11.AutoSize = True
        Me.D11.Location = New System.Drawing.Point(283, 412)
        Me.D11.Name = "D11"
        Me.D11.Size = New System.Drawing.Size(18, 17)
        Me.D11.TabIndex = 174
        Me.D11.UseVisualStyleBackColor = True
        '
        'C11
        '
        Me.C11.AutoSize = True
        Me.C11.Location = New System.Drawing.Point(231, 412)
        Me.C11.Name = "C11"
        Me.C11.Size = New System.Drawing.Size(18, 17)
        Me.C11.TabIndex = 173
        Me.C11.UseVisualStyleBackColor = True
        '
        'D10
        '
        Me.D10.AutoSize = True
        Me.D10.Location = New System.Drawing.Point(283, 377)
        Me.D10.Name = "D10"
        Me.D10.Size = New System.Drawing.Size(18, 17)
        Me.D10.TabIndex = 172
        Me.D10.UseVisualStyleBackColor = True
        '
        'C10
        '
        Me.C10.AutoSize = True
        Me.C10.Location = New System.Drawing.Point(231, 377)
        Me.C10.Name = "C10"
        Me.C10.Size = New System.Drawing.Size(18, 17)
        Me.C10.TabIndex = 171
        Me.C10.UseVisualStyleBackColor = True
        '
        'D9
        '
        Me.D9.AutoSize = True
        Me.D9.Location = New System.Drawing.Point(283, 343)
        Me.D9.Name = "D9"
        Me.D9.Size = New System.Drawing.Size(18, 17)
        Me.D9.TabIndex = 170
        Me.D9.UseVisualStyleBackColor = True
        '
        'C9
        '
        Me.C9.AutoSize = True
        Me.C9.Location = New System.Drawing.Point(231, 343)
        Me.C9.Name = "C9"
        Me.C9.Size = New System.Drawing.Size(18, 17)
        Me.C9.TabIndex = 169
        Me.C9.UseVisualStyleBackColor = True
        '
        'D8
        '
        Me.D8.AutoSize = True
        Me.D8.Location = New System.Drawing.Point(283, 308)
        Me.D8.Name = "D8"
        Me.D8.Size = New System.Drawing.Size(18, 17)
        Me.D8.TabIndex = 168
        Me.D8.UseVisualStyleBackColor = True
        '
        'C8
        '
        Me.C8.AutoSize = True
        Me.C8.Location = New System.Drawing.Point(231, 308)
        Me.C8.Name = "C8"
        Me.C8.Size = New System.Drawing.Size(18, 17)
        Me.C8.TabIndex = 167
        Me.C8.UseVisualStyleBackColor = True
        '
        'D7
        '
        Me.D7.AutoSize = True
        Me.D7.Location = New System.Drawing.Point(283, 274)
        Me.D7.Name = "D7"
        Me.D7.Size = New System.Drawing.Size(18, 17)
        Me.D7.TabIndex = 166
        Me.D7.UseVisualStyleBackColor = True
        '
        'C7
        '
        Me.C7.AutoSize = True
        Me.C7.Location = New System.Drawing.Point(231, 274)
        Me.C7.Name = "C7"
        Me.C7.Size = New System.Drawing.Size(18, 17)
        Me.C7.TabIndex = 165
        Me.C7.UseVisualStyleBackColor = True
        '
        'D6
        '
        Me.D6.AutoSize = True
        Me.D6.Location = New System.Drawing.Point(283, 239)
        Me.D6.Name = "D6"
        Me.D6.Size = New System.Drawing.Size(18, 17)
        Me.D6.TabIndex = 164
        Me.D6.UseVisualStyleBackColor = True
        '
        'C6
        '
        Me.C6.AutoSize = True
        Me.C6.Location = New System.Drawing.Point(231, 239)
        Me.C6.Name = "C6"
        Me.C6.Size = New System.Drawing.Size(18, 17)
        Me.C6.TabIndex = 163
        Me.C6.UseVisualStyleBackColor = True
        '
        'D5
        '
        Me.D5.AutoSize = True
        Me.D5.Location = New System.Drawing.Point(283, 205)
        Me.D5.Name = "D5"
        Me.D5.Size = New System.Drawing.Size(18, 17)
        Me.D5.TabIndex = 162
        Me.D5.UseVisualStyleBackColor = True
        '
        'C5
        '
        Me.C5.AutoSize = True
        Me.C5.Location = New System.Drawing.Point(231, 205)
        Me.C5.Name = "C5"
        Me.C5.Size = New System.Drawing.Size(18, 17)
        Me.C5.TabIndex = 161
        Me.C5.UseVisualStyleBackColor = True
        '
        'D4
        '
        Me.D4.AutoSize = True
        Me.D4.Location = New System.Drawing.Point(283, 170)
        Me.D4.Name = "D4"
        Me.D4.Size = New System.Drawing.Size(18, 17)
        Me.D4.TabIndex = 160
        Me.D4.UseVisualStyleBackColor = True
        '
        'C4
        '
        Me.C4.AutoSize = True
        Me.C4.Location = New System.Drawing.Point(231, 170)
        Me.C4.Name = "C4"
        Me.C4.Size = New System.Drawing.Size(18, 17)
        Me.C4.TabIndex = 159
        Me.C4.UseVisualStyleBackColor = True
        '
        'D3
        '
        Me.D3.AutoSize = True
        Me.D3.Location = New System.Drawing.Point(283, 136)
        Me.D3.Name = "D3"
        Me.D3.Size = New System.Drawing.Size(18, 17)
        Me.D3.TabIndex = 158
        Me.D3.UseVisualStyleBackColor = True
        '
        'C3
        '
        Me.C3.AutoSize = True
        Me.C3.Location = New System.Drawing.Point(231, 136)
        Me.C3.Name = "C3"
        Me.C3.Size = New System.Drawing.Size(18, 17)
        Me.C3.TabIndex = 157
        Me.C3.UseVisualStyleBackColor = True
        '
        'D2
        '
        Me.D2.AutoSize = True
        Me.D2.Location = New System.Drawing.Point(283, 102)
        Me.D2.Name = "D2"
        Me.D2.Size = New System.Drawing.Size(18, 17)
        Me.D2.TabIndex = 156
        Me.D2.UseVisualStyleBackColor = True
        '
        'C2
        '
        Me.C2.AutoSize = True
        Me.C2.Location = New System.Drawing.Point(231, 102)
        Me.C2.Name = "C2"
        Me.C2.Size = New System.Drawing.Size(18, 17)
        Me.C2.TabIndex = 155
        Me.C2.UseVisualStyleBackColor = True
        '
        'D1
        '
        Me.D1.AutoSize = True
        Me.D1.Location = New System.Drawing.Point(283, 67)
        Me.D1.Name = "D1"
        Me.D1.Size = New System.Drawing.Size(18, 17)
        Me.D1.TabIndex = 154
        Me.D1.UseVisualStyleBackColor = True
        '
        'C1
        '
        Me.C1.AutoSize = True
        Me.C1.Location = New System.Drawing.Point(231, 67)
        Me.C1.Name = "C1"
        Me.C1.Size = New System.Drawing.Size(18, 17)
        Me.C1.TabIndex = 153
        Me.C1.UseVisualStyleBackColor = True
        '
        'frmAirbusA350
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(399, 603)
        Me.Controls.Add(Me.D12)
        Me.Controls.Add(Me.C12)
        Me.Controls.Add(Me.D11)
        Me.Controls.Add(Me.C11)
        Me.Controls.Add(Me.D10)
        Me.Controls.Add(Me.C10)
        Me.Controls.Add(Me.D9)
        Me.Controls.Add(Me.C9)
        Me.Controls.Add(Me.D8)
        Me.Controls.Add(Me.C8)
        Me.Controls.Add(Me.D7)
        Me.Controls.Add(Me.C7)
        Me.Controls.Add(Me.D6)
        Me.Controls.Add(Me.C6)
        Me.Controls.Add(Me.D5)
        Me.Controls.Add(Me.C5)
        Me.Controls.Add(Me.D4)
        Me.Controls.Add(Me.C4)
        Me.Controls.Add(Me.D3)
        Me.Controls.Add(Me.C3)
        Me.Controls.Add(Me.D2)
        Me.Controls.Add(Me.C2)
        Me.Controls.Add(Me.D1)
        Me.Controls.Add(Me.C1)
        Me.Controls.Add(Me.B12)
        Me.Controls.Add(Me.A12)
        Me.Controls.Add(Me.B11)
        Me.Controls.Add(Me.A11)
        Me.Controls.Add(Me.B10)
        Me.Controls.Add(Me.A10)
        Me.Controls.Add(Me.B9)
        Me.Controls.Add(Me.A9)
        Me.Controls.Add(Me.B8)
        Me.Controls.Add(Me.A8)
        Me.Controls.Add(Me.B7)
        Me.Controls.Add(Me.A7)
        Me.Controls.Add(Me.B6)
        Me.Controls.Add(Me.A6)
        Me.Controls.Add(Me.B5)
        Me.Controls.Add(Me.A5)
        Me.Controls.Add(Me.B4)
        Me.Controls.Add(Me.A4)
        Me.Controls.Add(Me.B3)
        Me.Controls.Add(Me.A3)
        Me.Controls.Add(Me.B2)
        Me.Controls.Add(Me.A2)
        Me.Controls.Add(Me.B1)
        Me.Controls.Add(Me.A1)
        Me.Controls.Add(Me.Labe)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnReserveSeat)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.LabelD)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmAirbusA350"
        Me.Text = "Flight Seats"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Labe As Label
    Friend WithEvents Label As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents LabelD As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents btnReserveSeat As Button
    Friend WithEvents btnCancel As Button
    Friend WithEvents A1 As CheckBox
    Friend WithEvents B1 As CheckBox
    Friend WithEvents B2 As CheckBox
    Friend WithEvents A2 As CheckBox
    Friend WithEvents B3 As CheckBox
    Friend WithEvents A3 As CheckBox
    Friend WithEvents B4 As CheckBox
    Friend WithEvents A4 As CheckBox
    Friend WithEvents B5 As CheckBox
    Friend WithEvents A5 As CheckBox
    Friend WithEvents B6 As CheckBox
    Friend WithEvents A6 As CheckBox
    Friend WithEvents B7 As CheckBox
    Friend WithEvents A7 As CheckBox
    Friend WithEvents B8 As CheckBox
    Friend WithEvents A8 As CheckBox
    Friend WithEvents B9 As CheckBox
    Friend WithEvents A9 As CheckBox
    Friend WithEvents B10 As CheckBox
    Friend WithEvents A10 As CheckBox
    Friend WithEvents B11 As CheckBox
    Friend WithEvents A11 As CheckBox
    Friend WithEvents B12 As CheckBox
    Friend WithEvents A12 As CheckBox
    Friend WithEvents D12 As CheckBox
    Friend WithEvents C12 As CheckBox
    Friend WithEvents D11 As CheckBox
    Friend WithEvents C11 As CheckBox
    Friend WithEvents D10 As CheckBox
    Friend WithEvents C10 As CheckBox
    Friend WithEvents D9 As CheckBox
    Friend WithEvents C9 As CheckBox
    Friend WithEvents D8 As CheckBox
    Friend WithEvents C8 As CheckBox
    Friend WithEvents D7 As CheckBox
    Friend WithEvents C7 As CheckBox
    Friend WithEvents D6 As CheckBox
    Friend WithEvents C6 As CheckBox
    Friend WithEvents D5 As CheckBox
    Friend WithEvents C5 As CheckBox
    Friend WithEvents D4 As CheckBox
    Friend WithEvents C4 As CheckBox
    Friend WithEvents D3 As CheckBox
    Friend WithEvents C3 As CheckBox
    Friend WithEvents D2 As CheckBox
    Friend WithEvents C2 As CheckBox
    Friend WithEvents D1 As CheckBox
    Friend WithEvents C1 As CheckBox
End Class

﻿Public Class frmAttendantPastFlights
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub

    Private Sub frmAttendantPastFlights_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try

            Dim strSelect As String = ""
            Dim cmdSelect As OleDb.OleDbCommand            ' this will be used for our Select statement
            Dim drSourceTable As OleDb.OleDbDataReader     ' this will be where our result set will 
            Dim dt As DataTable = New DataTable            ' this is the table we will load from our reader
            Dim objParam As OleDb.OleDbParameter

            ' open the DB
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand("uspAttendantPastFlights", m_conAdministrator)
            cmdSelect.CommandType = CommandType.StoredProcedure

            objParam = cmdSelect.Parameters.Add("@Attendant_ID", OleDb.OleDbType.Integer)
            objParam.Direction = ParameterDirection.Input
            objParam.Value = strCurrentUser

            drSourceTable = cmdSelect.ExecuteReader

            'loop through result set and display in Listbox
            lstPastFlights.Items.Clear()
            lstPastFlights.Items.Add("All Past Flights")
            lstPastFlights.Items.Add("=============================")
            Dim intTotalMiles As Integer

            While drSourceTable.Read()

                lstPastFlights.Items.Add("  ")
                lstPastFlights.Items.Add("Flight Number: " & vbTab & drSourceTable("strFlightNumber"))
                lstPastFlights.Items.Add("Flight Date: " & vbTab & drSourceTable("dtmFlightDate"))
                lstPastFlights.Items.Add("Time of Departure: " & vbTab & drSourceTable("dtmTimeofDeparture"))
                lstPastFlights.Items.Add("Time of Landing: " & vbTab & drSourceTable("dtmTimeofLanding"))
                lstPastFlights.Items.Add("Departed From: " & vbTab & drSourceTable("City_From"))
                lstPastFlights.Items.Add("Landed At: " & vbTab & drSourceTable("City_To"))
                lstPastFlights.Items.Add("Miles Flown: " & vbTab & drSourceTable("intMilesFlown"))
                lstPastFlights.Items.Add("Plane Type: " & vbTab & drSourceTable("strPlaneType"))
                lstPastFlights.Items.Add("  ")
                lstPastFlights.Items.Add("=============================")
                intTotalMiles += drSourceTable("intMilesFlown")

            End While
            lblTotalMilesFlown.Text = intTotalMiles

            ' Clean up
            drSourceTable.Close()

            ' close the database connection
            CloseDatabaseConnection()

        Catch ex As Exception

            ' Log and display error message
            MessageBox.Show(ex.Message)

        End Try
    End Sub
End Class
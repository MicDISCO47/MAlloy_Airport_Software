﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAddAttendant
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnAddAttendant = New System.Windows.Forms.Button()
        Me.dtpDateofTermination = New System.Windows.Forms.DateTimePicker()
        Me.dtpDateofHire = New System.Windows.Forms.DateTimePicker()
        Me.txtEmployeeID = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.txtUserID = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(265, 273)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(128, 66)
        Me.btnExit.TabIndex = 78
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnAddAttendant
        '
        Me.btnAddAttendant.Location = New System.Drawing.Point(101, 273)
        Me.btnAddAttendant.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnAddAttendant.Name = "btnAddAttendant"
        Me.btnAddAttendant.Size = New System.Drawing.Size(128, 66)
        Me.btnAddAttendant.TabIndex = 77
        Me.btnAddAttendant.Text = "Add Attendant"
        Me.btnAddAttendant.UseVisualStyleBackColor = True
        '
        'dtpDateofTermination
        '
        Me.dtpDateofTermination.Location = New System.Drawing.Point(189, 164)
        Me.dtpDateofTermination.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dtpDateofTermination.Name = "dtpDateofTermination"
        Me.dtpDateofTermination.Size = New System.Drawing.Size(256, 22)
        Me.dtpDateofTermination.TabIndex = 75
        '
        'dtpDateofHire
        '
        Me.dtpDateofHire.Location = New System.Drawing.Point(189, 128)
        Me.dtpDateofHire.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.dtpDateofHire.Name = "dtpDateofHire"
        Me.dtpDateofHire.Size = New System.Drawing.Size(256, 22)
        Me.dtpDateofHire.TabIndex = 74
        '
        'txtEmployeeID
        '
        Me.txtEmployeeID.Location = New System.Drawing.Point(189, 89)
        Me.txtEmployeeID.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtEmployeeID.Name = "txtEmployeeID"
        Me.txtEmployeeID.Size = New System.Drawing.Size(169, 22)
        Me.txtEmployeeID.TabIndex = 73
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(23, 162)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(161, 23)
        Me.Label5.TabIndex = 71
        Me.Label5.Text = "Date of Termination"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(23, 127)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(161, 23)
        Me.Label4.TabIndex = 70
        Me.Label4.Text = "Date of Hire"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(23, 91)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(161, 23)
        Me.Label1.TabIndex = 69
        Me.Label1.Text = "Employee ID"
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(189, 52)
        Me.txtLastName.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(169, 22)
        Me.txtLastName.TabIndex = 68
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(189, 16)
        Me.txtFirstName.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(169, 22)
        Me.txtFirstName.TabIndex = 67
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(23, 55)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(161, 23)
        Me.Label3.TabIndex = 66
        Me.Label3.Text = "Last Name"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(23, 18)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(161, 23)
        Me.Label2.TabIndex = 65
        Me.Label2.Text = "First Name"
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(189, 231)
        Me.txtPassword.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(169, 22)
        Me.txtPassword.TabIndex = 98
        '
        'txtUserID
        '
        Me.txtUserID.Location = New System.Drawing.Point(189, 196)
        Me.txtUserID.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.txtUserID.Name = "txtUserID"
        Me.txtUserID.Size = New System.Drawing.Size(169, 22)
        Me.txtUserID.TabIndex = 97
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(23, 233)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(161, 23)
        Me.Label9.TabIndex = 96
        Me.Label9.Text = "Attendant Password"
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(23, 197)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(161, 23)
        Me.Label8.TabIndex = 95
        Me.Label8.Text = "Attendant UserID"
        '
        'frmAddAttendant
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(493, 354)
        Me.Controls.Add(Me.txtPassword)
        Me.Controls.Add(Me.txtUserID)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnAddAttendant)
        Me.Controls.Add(Me.dtpDateofTermination)
        Me.Controls.Add(Me.dtpDateofHire)
        Me.Controls.Add(Me.txtEmployeeID)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtLastName)
        Me.Controls.Add(Me.txtFirstName)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "frmAddAttendant"
        Me.Text = "Add Attendant"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents btnAddAttendant As Button
    Friend WithEvents dtpDateofTermination As DateTimePicker
    Friend WithEvents dtpDateofHire As DateTimePicker
    Friend WithEvents txtEmployeeID As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents txtLastName As TextBox
    Friend WithEvents txtFirstName As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents txtUserID As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
End Class

﻿Public Class frmManagePilots
    Private Sub btnAddPilot_Click(sender As Object, e As EventArgs) Handles btnAddPilot.Click
        Dim frmAddPilot As New frmAddPilot
        frmAddPilot.ShowDialog()
    End Sub

    Private Sub btnDeletePilot_Click(sender As Object, e As EventArgs) Handles btnDeletePilot.Click
        Dim frmDeletePilot As New frmDeletePilot
        frmDeletePilot.ShowDialog()
    End Sub

    Private Sub btnAddPilotToFlight_Click(sender As Object, e As EventArgs) Handles btnAddPilotToFlight.Click
        Dim frmAddPilotFlight As New frmAddPilotFlight
        frmAddPilotFlight.ShowDialog()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub

    Private Sub btnUpdatePilot_Click(sender As Object, e As EventArgs) Handles btnUpdatePilot.Click
        Dim frmAdminUpdatePilots As New frmAdminUpdatePilots
        frmAdminUpdatePilots.ShowDialog()
    End Sub
End Class
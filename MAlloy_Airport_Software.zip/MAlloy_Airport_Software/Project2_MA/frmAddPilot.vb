﻿Public Class frmAddPilot
    Private Sub frmAddPilot_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try

            Dim strSelect As String = ""
            Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement
            Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to
            Dim dtr As DataTable = New DataTable ' this is the table we will load from our reader for Role

            ' open the DB
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            ' Build the select statement to obtain Pilot Roles
            strSelect = "SELECT * From TPilotRoles"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            dtr.Load(drSourceTable)

            'load the Pilots result set into the combobox.  For VB, we do this by binding the data to the combobox

            cboPilotRole.ValueMember = "intPilotRoleID"
            cboPilotRole.DisplayMember = "strPilotRole"
            cboPilotRole.DataSource = dtr

            ' close the database connection
            drSourceTable.Close()

            CloseDatabaseConnection()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub

    Private Sub btnAddPilot_Click(sender As Object, e As EventArgs) Handles btnAddPilot.Click
        Dim strFirstName As String
        Dim strLastName As String
        Dim strEmployeeID As String
        Dim strDateofHire As String
        Dim strDateofTermination As String
        Dim strDateofLicense As String
        Dim intPilotRoleID As Integer
        Dim strUserID As String
        Dim strPassword As String

        Dim blnValidated = True

        Dim strSelect As String
        Dim strInsert As String
        Dim cmdSelect As OleDb.OleDbCommand ' select command object
        Dim cmdInsert As OleDb.OleDbCommand ' insert command object
        Dim drSourceTable As OleDb.OleDbDataReader ' data reader for pulling info
        Dim intNextPrimaryKey As Integer ' holds next highest PK value
        Dim intNextForeignKey As Integer
        Dim intRowsAffected As Integer  ' how many rows were affected when sql executed

        ' validate data is entered
        blnValidated = True
        Get_And_Validate_Inputs(strFirstName, strLastName, strEmployeeID, strDateofHire, strDateofTermination, strDateofLicense, intPilotRoleID, strUserID, strPassword, blnValidated)

        If blnValidated = True Then
            Try
                If OpenDatabaseConnectionSQLServer() = False Then

                    ' No, warn the user ...
                    MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                        "The application will now close.",
                                        Me.Text + " Error",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error)

                    ' and close the form/application
                    Me.Close()

                End If

                strSelect = "Select MAX(intPilotID) + 1 As intNextPrimaryKey From TPilots"

                ' Execute command
                cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
                drSourceTable = cmdSelect.ExecuteReader

                ' Read result( highest ID )
                drSourceTable.Read()

                ' Null? (empty table)
                If drSourceTable.IsDBNull(0) = True Then

                    ' Yes, start numbering at 1
                    intNextPrimaryKey = 1
                    intNextForeignKey = 1

                Else

                    ' No, get the next highest ID
                    intNextPrimaryKey = CInt(drSourceTable("intNextPrimaryKey"))
                    intNextForeignKey = CInt(drSourceTable("intNextPrimaryKey"))

                End If

                strInsert = "INSERT INTO TPilots (intPilotID, strFirstName, strLastName, strEmployeeID, dtmDateofHire, dtmDateofTermination, dtmDateofLicense, intPilotRoleID)" &
                    " VALUES (" & intNextPrimaryKey & ",'" & strFirstName & "','" & strLastName & "','" & strEmployeeID & "','" & strDateofHire & "','" & strDateofTermination & "','" & strDateofLicense & "','" & intPilotRoleID & "')"

                ' use insert command with sql string and connection object
                cmdInsert = New OleDb.OleDbCommand(strInsert, m_conAdministrator)

                ' execute query to insert data
                intRowsAffected = cmdInsert.ExecuteNonQuery()

                ' If not 0 insert successful
                If intRowsAffected > 0 Then
                    MessageBox.Show("Pilot has been added")    ' let user know success
                    ' close new player form
                End If


                strSelect = "Select MAX(intEmployeeOverallID) + 1 As intNextPrimaryKey From TEmployees"

                ' Execute command
                cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
                drSourceTable = cmdSelect.ExecuteReader

                ' Read result( highest ID )
                drSourceTable.Read()

                ' Null? (empty table)
                If drSourceTable.IsDBNull(0) = True Then

                    ' Yes, start numbering at 1
                    intNextPrimaryKey = 1

                Else

                    ' No, get the next highest ID
                    intNextPrimaryKey = CInt(drSourceTable("intNextPrimaryKey"))

                End If

                strInsert = "INSERT INTO TEmployees (intEmployeeOverallID, strEmployeeLoginID, strEmployeePassword, intEmployeeRoleID, intEmployeeID)" &
                    " VALUES (" & intNextPrimaryKey & ", '" & strUserID & "', '" & strPassword & "', " & 1 & ", " & intNextForeignKey & ")"

                ' use insert command with sql string and connection object
                cmdInsert = New OleDb.OleDbCommand(strInsert, m_conAdministrator)

                ' execute query to insert data
                intRowsAffected = cmdInsert.ExecuteNonQuery()

                ' If not 0 insert successful
                If intRowsAffected > 0 Then
                    MessageBox.Show("Employee has been added")    ' let user know success
                    ' close new player form
                End If


                CloseDatabaseConnection()       ' close connection if insert didn't work
                Close()

            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If

    End Sub

    Private Sub Get_And_Validate_Inputs(ByRef strFirstName As String, ByRef strLastName As String, ByRef strEmployeeID As String, ByRef strDateofHire As String, ByRef strDateofTermination As String, ByRef strDateofLicense As String, ByRef intPilotRoleID As Integer, ByRef strUserID As String, ByRef strPassword As String, ByRef blnValidated As Boolean)
        Get_And_Validate_FirstName(strFirstName, blnValidated, txtFirstName)
        If blnValidated = True Then
            Get_And_Validate_LastName(strLastName, blnValidated, txtLastName)
            If blnValidated = True Then
                Get_And_Validate_strEmployeeID(strEmployeeID, blnValidated, txtEmployeeID)
                If blnValidated = True Then
                    Get_And_Validate_DateofHire(strDateofHire, blnValidated, dtpDateofHire)
                    If blnValidated = True Then
                        Get_And_Validate_DateofTermination(strDateofTermination, blnValidated, dtpDateofHire, dtpDateofTermination)
                        If blnValidated = True Then
                            Get_And_Validate_DateofLicense(strDateofLicense, blnValidated, dtpDateofHire, dtpDateofLicense)
                            If blnValidated = True Then
                                Get_And_Validate_PilotRoleID(intPilotRoleID, blnValidated, cboPilotRole)
                                If blnValidated = True Then
                                    Get_And_Validate_EmployeeUserIDAdd(strUserID, blnValidated, txtUserID)
                                    If blnValidated = True Then
                                        Get_And_Validate_Password(strPassword, blnValidated, txtPassword)
                                    End If
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        End If
    End Sub
End Class
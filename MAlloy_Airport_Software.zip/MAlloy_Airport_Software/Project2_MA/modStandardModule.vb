﻿Module modStandardModule

    Public strCurrentUser As String
    Public strCurrentSeat As String
    Public strCurrentFlight As String

    Public Sub Get_And_Validate_FirstName(ByRef strFirstName As String, ByRef blnValidated As Boolean, ByRef txtFirstName As TextBox)
        If txtFirstName.Text = String.Empty Then
            blnValidated = False
            MessageBox.Show("Input a first name.")
            txtFirstName.Focus()
        Else
            strFirstName = txtFirstName.Text.Trim
            blnValidated = True
        End If
    End Sub

    Public Sub Get_And_Validate_LastName(ByRef strLastName As String, ByRef blnValidated As Boolean, ByRef txtLastName As TextBox)
        If txtLastName.Text = String.Empty Then
            blnValidated = False
            MessageBox.Show("Input a last name.")
            txtLastName.Focus()
        Else
            strLastName = txtLastName.Text.Trim
            blnValidated = True
        End If
    End Sub

    Public Sub Get_And_Validate_Address(ByRef strAddress As String, ByRef blnValidated As Boolean, ByRef txtAddress As TextBox)
        If txtAddress.Text = String.Empty Then
            blnValidated = False
            MessageBox.Show("Input an address.")
            txtAddress.Focus()
        Else
            strAddress = txtAddress.Text.Trim
            blnValidated = True
        End If
    End Sub

    Public Sub Get_And_Validate_City(ByRef strCity As String, ByRef blnValidated As Boolean, ByRef txtCity As TextBox)
        If txtCity.Text = String.Empty Then
            blnValidated = False
            MessageBox.Show("Input an city.")
            txtCity.Focus()
        Else
            strCity = txtCity.Text.Trim
            blnValidated = True
        End If
    End Sub

    Public Sub Get_And_Validate_State(ByRef intState As Integer, ByRef blnValidated As Boolean, ByRef cboState As ComboBox)
        If cboState.Text = String.Empty Then
            blnValidated = False
            MessageBox.Show("Input an available state.")
            cboState.Focus()
        Else
            If cboState.Text.Trim = "Ohio" Then
                blnValidated = True
                intState = cboState.SelectedValue
            Else
                If cboState.Text.Trim = "Kentucky" Then
                    blnValidated = True
                    intState = cboState.SelectedValue
                Else
                    If cboState.Text.Trim = "Indiana" Then
                        blnValidated = True
                        intState = cboState.SelectedValue
                    Else
                        blnValidated = False
                        MessageBox.Show("Input an available state.")
                        cboState.Focus()
                    End If
                End If
            End If
        End If
    End Sub

    Public Sub Get_And_Validate_ZIPCode(ByRef strZipCode As String, ByRef blnValidated As Boolean, ByRef txtZipCode As TextBox)
        If txtZipCode.Text = String.Empty Then
            blnValidated = False
            MessageBox.Show("Input a ZIP Code.")
            txtZipCode.Focus()
        Else
            If txtZipCode.Text.Length = 5 Then
                strZipCode = txtZipCode.Text.Trim
                blnValidated = True
            Else
                blnValidated = False
                MessageBox.Show("Input a ZIP Code.")
                txtZipCode.Focus()
            End If
        End If
    End Sub

    Public Sub Get_And_Validate_PhoneNumber(ByRef strPhoneNumber As String, ByRef blnValidated As Boolean, ByRef txtPhoneNumber As TextBox)
        If txtPhoneNumber.Text = String.Empty Then
            blnValidated = False
            MessageBox.Show("Input a phone number with no dashes in it.")
            txtPhoneNumber.Focus()
        Else
            If txtPhoneNumber.Text.Length = 10 Then
                If Long.TryParse(txtPhoneNumber.Text, strPhoneNumber) Then
                    strPhoneNumber = strPhoneNumber.ToString()
                    strPhoneNumber = strPhoneNumber.Trim
                    blnValidated = True
                Else
                    blnValidated = False
                    MessageBox.Show("Input a phone number with no dashes in it.")
                    txtPhoneNumber.Focus()
                End If
            Else
                blnValidated = False
                MessageBox.Show("Input a phone number with no dashes in it.")
                txtPhoneNumber.Focus()
            End If
        End If
    End Sub

    Public Sub Get_And_Validate_Email(ByRef strEmail As String, ByRef blnValidated As Boolean, ByRef txtEmailAddress As TextBox)
        If txtEmailAddress.Text = String.Empty Then
            blnValidated = False
            MessageBox.Show("Input an email.")
            txtEmailAddress.Focus()
        Else
            If txtEmailAddress.Text.IndexOf("@") > -1 Then
                strEmail = txtEmailAddress.Text.Trim
                blnValidated = True
            Else
                blnValidated = False
                MessageBox.Show("Input an email.")
                txtEmailAddress.Focus()
            End If
        End If
    End Sub

    Public Sub Get_And_Validate_PassengerUserIDUpd(ByRef strUserID As String, ByRef blnValidated As Boolean, ByRef txtUserID As TextBox)
        Dim strSelect As String
        Dim cmdSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim blnGotUserID As Boolean
        If txtUserID.Text = String.Empty Then
            blnValidated = False
            MessageBox.Show("Input a UserID")
            txtUserID.Focus()
        Else
            Try
                blnGotUserID = False
                If OpenDatabaseConnectionSQLServer() = False Then
                    MessageBox.Show("Cannot connect to database.")
                Else
                    strSelect = "Select * " &
                            "From TPassengers " &
                            "Where strPassengerUserID NOT IN(Select strPassengerUserID From TPassengers " &
                            "Where intPassengerID = " & strCurrentUser & ")"

                    cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
                    drSourceTable = cmdSelect.ExecuteReader

                    While drSourceTable.Read()
                        If drSourceTable("strPassengerUserID") = txtUserID.Text.Trim Then
                            MessageBox.Show("That UserID is already in use.")
                            blnGotUserID = True
                            blnValidated = False
                        End If
                    End While

                    If blnGotUserID = False Then
                        strUserID = txtUserID.Text.Trim
                        blnValidated = True
                    End If
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
    End Sub

    Public Sub Get_And_Validate_PassengerUserIDAdd(ByRef strUserID As String, ByRef blnValidated As Boolean, ByRef txtUserID As TextBox)
        Dim strSelect As String
        Dim cmdSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim blnGotUserID As Boolean
        If txtUserID.Text = String.Empty Then
            blnValidated = False
            MessageBox.Show("Input a UserID")
            txtUserID.Focus()
        Else
            Try
                blnGotUserID = False
                If OpenDatabaseConnectionSQLServer() = False Then
                    MessageBox.Show("Cannot connect to database.")
                Else
                    strSelect = "Select * " &
                            "From TPassengers "

                    cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
                    drSourceTable = cmdSelect.ExecuteReader

                    While drSourceTable.Read()
                            If drSourceTable("strPassengerUserID") = txtUserID.Text.Trim Then
                                MessageBox.Show("That UserID is already in use.")
                                blnGotUserID = True
                                blnValidated = False
                            End If
                    End While

                    If blnGotUserID = False Then
                        strUserID = txtUserID.Text.Trim
                        blnValidated = True
                    End If
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
    End Sub

    Public Sub Get_And_Validate_EmployeeUserIDUpt(ByRef strUserID As String, ByRef blnValidated As Boolean, ByRef txtUserID As TextBox)
        Dim strSelect As String
        Dim cmdSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim blnGotUserID As Boolean
        If txtUserID.Text = String.Empty Then
            blnValidated = False
            MessageBox.Show("Input a UserID")
            txtUserID.Focus()
        Else
            Try
                blnGotUserID = False
                If OpenDatabaseConnectionSQLServer() = False Then
                    MessageBox.Show("Cannot connect to database.")
                Else
                    strSelect = "Select * " &
                            "From TEmployees " &
                            "Where strEmployeeLoginID NOT IN(Select strEmployeeLoginID From TEmployees " &
                            "Where intEmployeeID = " & strCurrentUser & ")"

                    cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
                    drSourceTable = cmdSelect.ExecuteReader


                    While drSourceTable.Read()
                        If drSourceTable("strEmployeeLoginID") = txtUserID.Text.Trim Then
                            MessageBox.Show("That UserID is already in use.")
                            blnGotUserID = True
                            blnValidated = False
                        End If
                    End While

                    If blnGotUserID = False Then
                        strUserID = txtUserID.Text.Trim
                        blnValidated = True
                    End If
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try

        End If
    End Sub


    Public Sub Get_And_Validate_AdminIDUpt(ByRef strUserID As String, ByRef blnValidated As Boolean, ByRef txtUserID As TextBox, ByVal cboValue As ComboBox)
        Dim strSelect As String
        Dim cmdSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim blnGotUserID As Boolean
        If txtUserID.Text = String.Empty Then
            blnValidated = False
            MessageBox.Show("Input a UserID")
            txtUserID.Focus()
        Else
            Try
                blnGotUserID = False
                If OpenDatabaseConnectionSQLServer() = False Then
                    MessageBox.Show("Cannot connect to database.")
                Else
                    strSelect = "Select * " &
                            "From TEmployees " &
                            "Where strEmployeeLoginID NOT IN(Select strEmployeeLoginID From TEmployees " &
                            "Where intEmployeeID = " & cboValue.SelectedValue & ")"

                    cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
                    drSourceTable = cmdSelect.ExecuteReader


                    While drSourceTable.Read()
                        If drSourceTable("strEmployeeLoginID") = txtUserID.Text.Trim Then
                            MessageBox.Show("That UserID is already in use.")
                            blnGotUserID = True
                            blnValidated = False
                        End If
                    End While

                    If blnGotUserID = False Then
                        strUserID = txtUserID.Text.Trim
                        blnValidated = True
                    End If
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try

        End If
    End Sub

    Public Sub Get_And_Validate_EmployeeUserIDAdd(ByRef strUserID As String, ByRef blnValidated As Boolean, ByRef txtUserID As TextBox)
        Dim strSelect As String
        Dim cmdSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim blnGotUserID As Boolean
        If txtUserID.Text = String.Empty Then
            blnValidated = False
            MessageBox.Show("Input a UserID")
            txtUserID.Focus()
        Else
            Try
                blnGotUserID = False
                If OpenDatabaseConnectionSQLServer() = False Then
                    MessageBox.Show("Cannot connect to database.")
                Else
                    strSelect = "Select * " &
                            "From TEmployees "

                    cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
                    drSourceTable = cmdSelect.ExecuteReader

                    While drSourceTable.Read()
                            If drSourceTable("strEmployeeLoginID") = txtUserID.Text.Trim Then
                                MessageBox.Show("That UserID is already in use.")
                                blnGotUserID = True
                                blnValidated = False
                            End If
                    End While

                    If blnGotUserID = False Then
                        strUserID = txtUserID.Text.Trim
                        blnValidated = True
                    End If
                End If
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try

        End If
    End Sub

    Public Sub Get_And_Validate_Password(ByRef strPassword As String, ByRef blnValidated As Boolean, ByRef txtPassword As TextBox)
        If txtPassword.Text = String.Empty Then
            blnValidated = False
            MessageBox.Show("Input a Password")
            txtPassword.Focus()
        Else
            strPassword = txtPassword.Text.Trim
            blnValidated = True
        End If
    End Sub

    Public Sub Confirm_Password(ByRef strPassword As String, ByRef blnValidated As Boolean, ByRef txtConfirmPassword As TextBox)
        If txtConfirmPassword.Text.Trim = strPassword Then
            blnValidated = True
        Else
            blnValidated = False
            MessageBox.Show("Confirm your password by repeating it in the password confirmation.")
            txtConfirmPassword.Focus()
        End If
    End Sub

    Public Sub Get_And_Validate_DateofBirth(ByRef strDateofBirth As String, ByRef blnValidated As Boolean, ByRef dtpDateofBirth As DateTimePicker)
        If dtpDateofBirth.Value > #1/1/1900# Then
            If dtpDateofBirth.Value < Today Then
                strDateofBirth = dtpDateofBirth.Value
            Else
                blnValidated = False
                MessageBox.Show("Invalid Date of Birth")
            End If
        Else
            blnValidated = False
            MessageBox.Show("Invalid Date of Birth")
        End If
        strDateofBirth = dtpDateofBirth.Value
    End Sub

    Public Sub Get_And_Validate_strEmployeeID(ByRef strEmployeeID As String, ByRef blnValidated As Boolean, ByRef txtEmployeeID As TextBox)
        If txtEmployeeID.Text = String.Empty Then
            blnValidated = False
            MessageBox.Show("Input an employee ID that is at least five numbers.")
            txtEmployeeID.Focus()
        Else
            If txtEmployeeID.Text.Length = 5 Then
                Try
                    Integer.TryParse(txtEmployeeID.Text.Trim, strEmployeeID)
                    blnValidated = True
                Catch ex As Exception
                    MessageBox.Show("Employee ID must be a number.")
                End Try
            Else
                blnValidated = False
                MessageBox.Show("Input an employee ID that is at least five numbers.")
                txtEmployeeID.Focus()
            End If
        End If
    End Sub

    Public Sub Get_And_Validate_DateofHire(ByRef strDateofHire As String, ByRef blnValidated As Boolean, ByRef dtpDateofHire As DateTimePicker)
        If dtpDateofHire.Value > #1/1/2000# Then
            strDateofHire = dtpDateofHire.Value
            blnValidated = True
        Else
            blnValidated = False
            MessageBox.Show("Date of Hire too early.")
        End If
    End Sub

    Public Sub Get_And_Validate_DateofTermination(ByRef strDateofTermination As String, ByRef blnValidated As Boolean, ByRef dtpDateofHire As DateTimePicker, ByRef dtpDateofTermination As DateTimePicker)
        If dtpDateofTermination.Value < dtpDateofHire.Value Then
            blnValidated = False
            MessageBox.Show("Date of Termination cannot be earlier than date of hire.")
        Else
            strDateofTermination = dtpDateofTermination.Value
            blnValidated = True
        End If
    End Sub

    Public Sub Get_And_Validate_DateofLicense(ByRef strDateofLicense As String, ByRef blnValidated As Boolean, ByRef dtpDateofHire As DateTimePicker, ByRef dtpDateofLicense As DateTimePicker)
        If dtpDateofLicense.Value > dtpDateofHire.Value Then
            blnValidated = False
            MessageBox.Show("Date of License must be before Date of Hire.")
        Else
            strDateofLicense = dtpDateofLicense.Value
            blnValidated = True
        End If
    End Sub

    Public Sub Get_And_Validate_PilotRoleID(ByRef intPilotRoleID As Integer, ByRef blnValidated As Boolean, ByRef cboPilotRole As ComboBox)
        If cboPilotRole.Text = String.Empty Then
            blnValidated = False
            MessageBox.Show("Input an available role.")
            cboPilotRole.Focus()
        Else
            If cboPilotRole.Text.Trim = "Co-Pilot" Then
                blnValidated = True
                intPilotRoleID = cboPilotRole.SelectedValue
            Else
                If cboPilotRole.Text.Trim = "Captain" Then
                    blnValidated = True
                    intPilotRoleID = cboPilotRole.SelectedValue
                End If
            End If
        End If
    End Sub
End Module

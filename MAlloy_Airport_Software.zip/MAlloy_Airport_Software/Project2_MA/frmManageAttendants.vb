﻿Public Class frmManageAttendants
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub

    Private Sub btnAddAttendant_Click(sender As Object, e As EventArgs) Handles btnAddAttendant.Click
        Dim frmAddAttendant As New frmAddAttendant
        frmAddAttendant.ShowDialog()
    End Sub

    Private Sub btnDeleteAttendant_Click(sender As Object, e As EventArgs) Handles btnDeleteAttendant.Click
        Dim frmDeleteAttendant As New frmDeleteAttendant
        frmDeleteAttendant.ShowDialog()
    End Sub

    Private Sub btnAddAttendantToFlight_Click(sender As Object, e As EventArgs) Handles btnAddAttendantToFlight.Click
        Dim frmAddAttendantFlight As New frmAddAttendantFlight
        frmAddAttendantFlight.ShowDialog()
    End Sub

    Private Sub btnUpdateAttendant_Click(sender As Object, e As EventArgs) Handles btnUpdateAttendant.Click
        Dim frmAdminUpdateAttendants As New frmAdminUpdateAttendants
        frmAdminUpdateAttendants.ShowDialog()
    End Sub
End Class
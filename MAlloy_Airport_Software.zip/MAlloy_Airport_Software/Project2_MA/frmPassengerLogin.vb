﻿Public Class frmPassengerLogin
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub

    Private Sub btnRegisterPassenger_Click(sender As Object, e As EventArgs) Handles btnRegisterPassenger.Click
        Dim frmAddPassenger As New frmAddPassenger
        frmAddPassenger.ShowDialog()
    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim strSelect As String
        Dim cmdSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim blnGotPassenger As Boolean

        Dim strUserID = txtUserID.Text
        Dim strPassword = txtPassword.Text

        Try
            ' open the DB
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            strSelect = "Select intPassengerID, strPassengerUserID, strPassengerPassword " &
                        "From TPassengers "

            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            While drSourceTable.Read()
                If drSourceTable("strPassengerUserID") = txtUserID.Text.Trim Then
                    If drSourceTable("strPassengerPassword") = txtPassword.Text.Trim Then
                        blnGotPassenger = True
                        strCurrentUser = drSourceTable("intPassengerID")
                        Dim frmPassengerMainMenu As New frmPassengerMainMenu
                        frmPassengerMainMenu.ShowDialog()
                    End If
                End If
            End While

            If blnGotPassenger = False Then
                MessageBox.Show("Invalid UserID or Password.")
            End If

            ' Clean up
            drSourceTable.Close()

            ' close the database connection
            CloseDatabaseConnection()

        Catch ex As Exception

            ' Log and display error message
            MessageBox.Show(ex.Message)
        End Try

    End Sub
End Class
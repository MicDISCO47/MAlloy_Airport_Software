﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmManageAttendants
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnAddAttendantToFlight = New System.Windows.Forms.Button()
        Me.btnDeleteAttendant = New System.Windows.Forms.Button()
        Me.btnAddAttendant = New System.Windows.Forms.Button()
        Me.btnUpdateAttendant = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(114, 138)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(92, 50)
        Me.btnExit.TabIndex = 11
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnAddAttendantToFlight
        '
        Me.btnAddAttendantToFlight.Location = New System.Drawing.Point(178, 22)
        Me.btnAddAttendantToFlight.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnAddAttendantToFlight.Name = "btnAddAttendantToFlight"
        Me.btnAddAttendantToFlight.Size = New System.Drawing.Size(92, 50)
        Me.btnAddAttendantToFlight.TabIndex = 10
        Me.btnAddAttendantToFlight.Text = "Add Attendant to Flight"
        Me.btnAddAttendantToFlight.UseVisualStyleBackColor = True
        '
        'btnDeleteAttendant
        '
        Me.btnDeleteAttendant.Location = New System.Drawing.Point(178, 76)
        Me.btnDeleteAttendant.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnDeleteAttendant.Name = "btnDeleteAttendant"
        Me.btnDeleteAttendant.Size = New System.Drawing.Size(92, 50)
        Me.btnDeleteAttendant.TabIndex = 9
        Me.btnDeleteAttendant.Text = "Delete Attendant"
        Me.btnDeleteAttendant.UseVisualStyleBackColor = True
        '
        'btnAddAttendant
        '
        Me.btnAddAttendant.Location = New System.Drawing.Point(55, 22)
        Me.btnAddAttendant.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnAddAttendant.Name = "btnAddAttendant"
        Me.btnAddAttendant.Size = New System.Drawing.Size(92, 50)
        Me.btnAddAttendant.TabIndex = 8
        Me.btnAddAttendant.Text = "Add Attendant"
        Me.btnAddAttendant.UseVisualStyleBackColor = True
        '
        'btnUpdateAttendant
        '
        Me.btnUpdateAttendant.Location = New System.Drawing.Point(55, 76)
        Me.btnUpdateAttendant.Margin = New System.Windows.Forms.Padding(2)
        Me.btnUpdateAttendant.Name = "btnUpdateAttendant"
        Me.btnUpdateAttendant.Size = New System.Drawing.Size(92, 50)
        Me.btnUpdateAttendant.TabIndex = 12
        Me.btnUpdateAttendant.Text = "Update Attendant"
        Me.btnUpdateAttendant.UseVisualStyleBackColor = True
        '
        'frmManageAttendants
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(328, 199)
        Me.Controls.Add(Me.btnUpdateAttendant)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnAddAttendantToFlight)
        Me.Controls.Add(Me.btnDeleteAttendant)
        Me.Controls.Add(Me.btnAddAttendant)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "frmManageAttendants"
        Me.Text = "Manage Attendants"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents btnAddAttendantToFlight As Button
    Friend WithEvents btnDeleteAttendant As Button
    Friend WithEvents btnAddAttendant As Button
    Friend WithEvents btnUpdateAttendant As Button
End Class

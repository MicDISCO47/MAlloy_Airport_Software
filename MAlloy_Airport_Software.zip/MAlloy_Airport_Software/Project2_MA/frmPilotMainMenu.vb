﻿Public Class frmPilotMainMenu
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub

    Private Sub btnUpdatePilot_Click(sender As Object, e As EventArgs) Handles btnUpdatePilot.Click
        Dim frmUpdatePilot As New frmUpdatePilot
        frmUpdatePilot.ShowDialog()
    End Sub

    Private Sub btnPastFlights_Click(sender As Object, e As EventArgs) Handles btnPastFlights.Click
        Dim frmPilotPastFlights As New frmPilotPastFlights
        frmPilotPastFlights.ShowDialog()
    End Sub

    Private Sub btnFutureFlights_Click(sender As Object, e As EventArgs) Handles btnFutureFlights.Click
        Dim frmPilotFutureFlights As New frmPilotFutureFlights
        frmPilotFutureFlights.ShowDialog()
    End Sub
End Class
﻿Public Class frmStatistics
    Private Sub frmStatistics_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try

            Dim strSelect As String = ""
            Dim cmdSelect As OleDb.OleDbCommand            ' this will be used for our Select statement
            Dim drSourceTable As OleDb.OleDbDataReader     ' this will be where our result set will 
            Dim dt As DataTable = New DataTable            ' this is the table we will load from our reader

            ' open the DB
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            ' Build the select statement
            strSelect = "Select COUNT(intPassengerID) As Passenger_Total " &
                "From TPassengers"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            drSourceTable.Read()

            lblTotalCustomers.Text = drSourceTable("Passenger_Total")


            strSelect = "Select COUNT(intFlightPassengerID) As Passenger_Flights " &
                "From TFlightPassengers As TFP JOIN TFlights As TF " &
                "ON TF.intFlightID = TFP.intFlightID " &
                "Where dtmFlightDate < '4/1/2025'"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            drSourceTable.Read()

            lblTotalPassengerFlights.Text = drSourceTable("Passenger_Flights")


            strSelect = "Select AVG(TF.intMilesFlown) As Average_Miles_Flown " &
                "From TFlights As TF JOIN TFlightPassengers As TFP ON TF.intFlightID = TFP.intFlightID " &
                "JOIN TPassengers As TP ON TP.intPassengerID = TFP.intPassengerID " &
                "Where dtmFlightDate < '4/1/2025'"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            drSourceTable.Read()

            lblAveragePassengerMiles.Text = drSourceTable("Average_Miles_Flown")

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand("uspTotalPilotMiles", m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            'loop through result set and display in Listbox
            lstPilotMiles.Items.Clear()
            lstPilotMiles.Items.Add("All Pilots Total Miles")
            lstPilotMiles.Items.Add("=============================")

            While drSourceTable.Read()

                lstPilotMiles.Items.Add("  ")
                lstPilotMiles.Items.Add("Pilot Name: " & drSourceTable("Pilot_Name"))
                lstPilotMiles.Items.Add("Total Miles: " & drSourceTable("Total_Miles"))
                lstPilotMiles.Items.Add("  ")
                lstPilotMiles.Items.Add("=============================")

            End While

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand("uspTotalAttendantMiles", m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            'loop through result set and display in Listbox
            lstAttendantMiles.Items.Clear()
            lstAttendantMiles.Items.Add("All Attendant Total Miles")
            lstAttendantMiles.Items.Add("=============================")

            While drSourceTable.Read()

                lstAttendantMiles.Items.Add("  ")
                lstAttendantMiles.Items.Add("Attendant Name: " & drSourceTable("Attendant_Name"))
                lstAttendantMiles.Items.Add("Total Miles: " & drSourceTable("Total_Miles"))
                lstAttendantMiles.Items.Add("  ")
                lstAttendantMiles.Items.Add("=============================")

            End While


            ' Clean up
            drSourceTable.Close()

            ' close the database connection
            CloseDatabaseConnection()

        Catch ex As Exception

            ' Log and display error message
            MessageBox.Show(ex.Message)

        End Try
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class
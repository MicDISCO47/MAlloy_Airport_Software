﻿Imports System.CodeDom

Public Class frmAddPassengerFlight

    Private Sub frmAddPassengerFlight_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try

            Dim strSelect As String = ""
            Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement
            Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to
            Dim dtf As DataTable = New DataTable ' this is the table we will load from our reader for Flights

            ' open the DB
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            ' Build the select statement to obtain States
            strSelect = "SELECT intFlightID, TAF.strAirportCity + ' to ' + TAT.strAirportCity As Travel_Path " &
                "From TFlights As TF JOIN TAirports As TAT ON TF.intToAirportID = TAT.intAirportID " &
                "JOIN TAirports As TAF ON TAF.intAirportID = TF.intFromAirportID " &
                "Where TF.dtmFlightDate > '4/1/2025'"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            dtf.Load(drSourceTable)

            'load the States result set into the combobox.  For VB, we do this by binding the data to the combobox

            cboFutureFlights.ValueMember = "intFlightID"
            cboFutureFlights.DisplayMember = "Travel_Path"
            cboFutureFlights.DataSource = dtf

            ' close the database connection
            CloseDatabaseConnection()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub cboFutureFlights_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboFutureFlights.SelectedIndexChanged
        Dim strSelect As String = ""
        Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement
        Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to
        Dim blnIsFull = True
        Dim intNumberofPassengers = 0

        Try
            ' open the DB
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            strSelect = "SELECT COUNT(intPassengerID) As Passengers " &
                "FROM TFlightPassengers " &
                "Where intFlightID = " & cboFutureFlights.SelectedValue


            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            drSourceTable.Read()

            intNumberofPassengers = drSourceTable("Passengers")

            strSelect = "SELECT TF.intFlightID, TPT.strPlaneType " &
                "FROM TFlights As TF JOIN TPlanes As TP " &
                "ON TP.intPlaneID = TF.intPlaneID " &
                "JOIN TPlaneTypes AS TPT " &
                "ON TPT.intPlaneTypeID = TP.intPlaneTypeID " &
                "Where TF.intFlightID = " & cboFutureFlights.SelectedValue


            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            drSourceTable.Read()

            If drSourceTable("strPlaneType") = "Airbus A350" And intNumberofPassengers >= 48 Then
                blnIsFull = True
                lblIsFull.Text = "Flight is full!"
                radNoReservation.Enabled = False
                radReserveSeat.Enabled = False
                btnBookFlight.Enabled = False
                lblNormalCost.Text = " "
                lblReserveCost.Text = " "
            Else
                If drSourceTable("strPlaneType") = "Boeing 747-8" And intNumberofPassengers >= 60 Then
                    blnIsFull = True
                    lblIsFull.Text = "Flight is full!"
                    radNoReservation.Enabled = False
                    radReserveSeat.Enabled = False
                    btnBookFlight.Enabled = False
                    lblNormalCost.Text = " "
                    lblReserveCost.Text = " "
                Else
                    If drSourceTable("strPlaneType") = "Boeing 767-300F" And intNumberofPassengers >= 90 Then
                        blnIsFull = True
                        lblIsFull.Text = "Flight is full!"
                        radNoReservation.Enabled = False
                        radReserveSeat.Enabled = False
                        btnBookFlight.Enabled = False
                        lblNormalCost.Text = " "
                        lblReserveCost.Text = " "
                    Else
                        blnIsFull = False
                    End If
                End If
            End If

            If blnIsFull = False Then
                lblIsFull.Text = " "
                radNoReservation.Enabled = True
                radReserveSeat.Enabled = True
            End If

            radNoReservation.Checked = False
            radReserveSeat.Checked = False
            lblNormalCost.Text = " "
            lblReserveCost.Text = " "
            lblSeat.Text = ""


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Close()
    End Sub

    Private Sub radNoReservation_CheckedChanged(sender As Object, e As EventArgs) Handles radNoReservation.Click
        Dim strSelect As String = ""
        Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement
        Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to
        Dim decTotalCost As Decimal
        Dim intNumberOfPassengers As Integer
        Dim intTotalMiles As Integer
        Dim intAirport As Integer
        Dim strFlightDate As String
        Dim datDateofBirth As Date
        Dim intFlightCount As Integer


        Try
            ' open the DB
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            strSelect = "SELECT IsNull(COUNT(intPassengerID), 0) As Passengers " &
                "FROM TFlightPassengers " &
                "Where intFlightID = " & cboFutureFlights.SelectedValue


            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            drSourceTable.Read()

            intNumberOfPassengers = drSourceTable("Passengers")


            strSelect = "SELECT TF.intMilesFlown, TF.intToAirportID, TF.dtmFlightDate " &
                "FROM TFlights As TF " &
                "Where TF.intFlightID = " & cboFutureFlights.SelectedValue


            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            drSourceTable.Read()

            intTotalMiles = drSourceTable("intMilesFlown")
            intAirport = drSourceTable("intToAirportID")
            strFlightDate = drSourceTable("dtmFlightDate")


            strSelect = "Select COUNT(TF.intFlightID) As Flights, TP.dtmDateofBirth " &
                "FROM TFlights As TF RIGHT JOIN TFlightPassengers As TFP " &
                "ON TF.intFlightID = TFP.intFlightID " &
                "RIGHT JOIN TPassengers As TP " &
                "ON TP.intPassengerID = TFP.intPassengerID " &
                "Where EXISTS (Select isNull(TF.intFlightID, 0) As Flights, TF.dtmFlightDate " &
                "From TFlights As TF RIGHT JOIN TFlightPassengers As TFP " &
                "ON TF.intFlightID = TFP.intFlightID " &
                "RIGHT JOIN TPassengers As TP " &
                "ON TP.intPassengerID = TFP.intPassengerID " &
                "Where TF.dtmFlightDate < '" & strFlightDate & "') " &
                "and TP.intPassengerID = " & strCurrentUser &
                "Group By TP.dtmDateofBirth"


            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            drSourceTable.Read()

            datDateofBirth = drSourceTable("dtmDateofBirth")
            intFlightCount = drSourceTable("Flights")


            decTotalCost = 250

            If intTotalMiles > 750 Then
                decTotalCost += 50
            End If

            If intNumberOfPassengers > 8 Then
                decTotalCost += 100
            ElseIf intNumberOfPassengers < 4 Then
                decTotalCost -= 50
            End If

            If intAirport = 2 Then
                decTotalCost += 15
            End If

            If datDateofBirth <= #4/1/1960# Then
                decTotalCost *= 0.8
            ElseIf datDateofBirth >= #5/1/2020# Then
                decTotalCost *= 0.35
            End If

            If intFlightCount > 10 Then
                decTotalCost *= 0.8
            ElseIf intFlightCount > 5 Then
                decTotalCost *= 0.9
            End If

            lblNormalCost.Text = decTotalCost.ToString("c")
            btnBookFlight.Enabled = True


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub radReserveSeat_CheckedChanged(sender As Object, e As EventArgs) Handles radReserveSeat.Click
        Dim strSelect As String = ""
        Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement
        Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to
        Dim decTotalCost As Decimal
        Dim intNumberOfPassengers As Integer
        Dim intTotalMiles As Integer
        Dim intAirport As Integer
        Dim strFlightDate As String
        Dim datDateofBirth As Date
        Dim intFlightCount As Integer
        Dim intSeatCost As Integer
        Dim strPlaneType As String

        Try


            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            strSelect = "Select TPT.strPlaneType, TF.intFlightID " &
                "From TPlaneTypes As TPT JOIN TPlanes As TP ON TPT.intPlaneTypeID = TP.intPlaneTypeID " &
                "JOIN TFlights As TF ON TF.intPlaneID = TP.intPlaneID " &
                "Where TF.intFlightID = " & cboFutureFlights.SelectedValue

            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            drSourceTable.Read()

            strPlaneType = drSourceTable("strPlaneType")

            If strPlaneType = "Airbus A350" Then
                strCurrentFlight = drSourceTable("intFlightID")
                Dim frmAirbusA350 As New frmAirbusA350
                frmAirbusA350.ShowDialog()
            ElseIf strPlaneType = "Boeing 747-8" Then
                strCurrentFlight = drSourceTable("intFlightID")
                Dim frmSeatSelect As New frmBoeing747_8
                frmSeatSelect.ShowDialog()
            ElseIf strPlaneType = "Boeing 767-300F" Then
                strCurrentFlight = drSourceTable("intFlightID")
                Dim frmSeatThing As New frmBoeing767_300F
                frmSeatThing.ShowDialog()
            Else
                MessageBox.Show("Cannot open seat select.")
            End If

            If strCurrentSeat <> "" Then
                lblSeat.Text = strCurrentSeat

                strSelect = "SELECT IsNull(COUNT(intPassengerID), 0) As Passengers " &
                "FROM TFlightPassengers " &
                "Where intFlightID = " & cboFutureFlights.SelectedValue


                cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
                drSourceTable = cmdSelect.ExecuteReader
                drSourceTable.Read()

                intNumberOfPassengers = drSourceTable("Passengers")


                strSelect = "SELECT TF.intMilesFlown, TF.intToAirportID, TF.dtmFlightDate " &
                "FROM TFlights As TF " &
                "Where TF.intFlightID = " & cboFutureFlights.SelectedValue


                cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
                drSourceTable = cmdSelect.ExecuteReader
                drSourceTable.Read()

                intTotalMiles = drSourceTable("intMilesFlown")
                intAirport = drSourceTable("intToAirportID")
                strFlightDate = drSourceTable("dtmFlightDate")


                strSelect = "Select COUNT(TF.intFlightID) As Flights, TP.dtmDateofBirth " &
                "FROM TFlights As TF RIGHT JOIN TFlightPassengers As TFP " &
                "ON TF.intFlightID = TFP.intFlightID " &
                "RIGHT JOIN TPassengers As TP " &
                "ON TP.intPassengerID = TFP.intPassengerID " &
                "Where EXISTS (Select isNull(TF.intFlightID, 0) As Flights, TF.dtmFlightDate " &
                "From TFlights As TF RIGHT JOIN TFlightPassengers As TFP " &
                "ON TF.intFlightID = TFP.intFlightID " &
                "RIGHT JOIN TPassengers As TP " &
                "ON TP.intPassengerID = TFP.intPassengerID " &
                "Where TF.dtmFlightDate < '" & strFlightDate & "') " &
                "and TP.intPassengerID = " & strCurrentUser &
                "Group By TP.dtmDateofBirth"


                cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
                drSourceTable = cmdSelect.ExecuteReader
                drSourceTable.Read()

                datDateofBirth = drSourceTable("dtmDateofBirth")
                intFlightCount = drSourceTable("Flights")


                decTotalCost = 250

                If intTotalMiles > 750 Then
                    decTotalCost += 50
                End If

                If intNumberOfPassengers > 8 Then
                    decTotalCost += 100
                ElseIf intNumberOfPassengers < 4 Then
                    decTotalCost -= 50
                End If

                If strPlaneType = "Airbus A350" Then
                    Calculate_Airbus_SeatCost(strCurrentSeat, intSeatCost)
                ElseIf strPlaneType = "Boeing 747-8" Then
                    Calculate_Boeing8_SeatCost(strCurrentSeat, intSeatCost)
                ElseIf strPlaneType = "Boeing 767-300F" Then
                    Calculate_BoeingF_SeatCost(strCurrentSeat, intSeatCost)
                End If

                decTotalCost += intSeatCost

                If intAirport = 2 Then
                    decTotalCost += 15
                End If

                If datDateofBirth <= #4/1/1960# Then
                    decTotalCost *= 0.8
                ElseIf datDateofBirth >= #5/1/2020# Then
                    decTotalCost *= 0.35
                End If

                If intFlightCount > 10 Then
                    decTotalCost *= 0.8
                ElseIf intFlightCount > 5 Then
                    decTotalCost *= 0.9
                End If

                lblReserveCost.Text = decTotalCost.ToString("c")
                btnBookFlight.Enabled = True
            Else
                lblSeat.Text = ""
                btnBookFlight.Enabled = False
            End If


        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub Calculate_Airbus_SeatCost(ByVal strSeat As String, ByRef intSeatCost As Integer)
        Dim strLength = strSeat.Length

        If strLength = 3 Then
            If strSeat.Substring(1, 2) = "10" Or strSeat.Substring(1, 2) = "11" Or strSeat.Substring(1, 2) = "12" Then
                intSeatCost = 10
            End If
        ElseIf strLength = 2 Then
            If strSeat.Substring(1) = "9" Then
                intSeatCost = 10
            ElseIf strSeat.Substring(1) = "8" Or strSeat.Substring(1) = "7" Or strSeat.Substring(1) = "6" Or strSeat.Substring(1) = "5" Then
                intSeatCost = 25
            ElseIf strSeat.Substring(1) = "1" Or strSeat.Substring(1) = "2" Or strSeat.Substring(1) = "3" Or strSeat.Substring(1) = "4" Then
                intSeatCost = 50
            End If
        End If
    End Sub

    Private Sub Calculate_Boeing8_SeatCost(ByVal strSeat As String, ByRef intSeatCost As Integer)
        Dim strLength = strSeat.Length

        If strLength = 3 Then
            If strSeat.Substring(1, 2) = "10" Then
                intSeatCost = 10
            End If
        ElseIf strLength = 2 Then
            If strSeat.Substring(1) = "9" Then
                intSeatCost = 10
            ElseIf strSeat.Substring(1) = "8" Or strSeat.Substring(1) = "7" Or strSeat.Substring(1) = "6" Or strSeat.Substring(1) = "5" Or strSeat.Substring(1) = "4" Then
                intSeatCost = 25
            ElseIf strSeat.Substring(1) = "1" Or strSeat.Substring(1) = "2" Or strSeat.Substring(1) = "3" Then
                intSeatCost = 50
            End If
        End If
    End Sub

    Private Sub Calculate_BoeingF_SeatCost(ByVal strSeat As String, ByRef intSeatCost As Integer)
        Dim strLength = strSeat.Length

        If strLength = 3 Then
            If strSeat.Substring(1, 2) = "10" Then
                intSeatCost = 20
            End If
        ElseIf strLength = 2 Then
            If strSeat.Substring(1) = "9" Then
                intSeatCost = 20
            ElseIf strSeat.Substring(1) = "8" Or strSeat.Substring(1) = "7" Or strSeat.Substring(1) = "6" Or strSeat.Substring(1) = "5" Or strSeat.Substring(1) = "4" Then
                intSeatCost = 50
            ElseIf strSeat.Substring(1) = "1" Or strSeat.Substring(1) = "2" Or strSeat.Substring(1) = "3" Then
                intSeatCost = 150
            End If
        End If

        If strSeat.Substring(0) = "D" Or strSeat.Substring(0) = "E" Or strSeat.Substring(0) = "F" Then
            intSeatCost -= 10
        End If
    End Sub

    Private Sub btnBookFlight_Click(sender As Object, e As EventArgs) Handles btnBookFlight.Click
        Dim strSelect As String
        Dim strInsert As String
        Dim cmdSelect As OleDb.OleDbCommand ' select command object
        Dim cmdInsert As OleDb.OleDbCommand ' insert command object
        Dim drSourceTable As OleDb.OleDbDataReader ' data reader for pulling info
        Dim intNextPrimaryKey As Integer ' holds next highest PK value
        Dim intRowsAffected As Integer  ' how many rows were affected when sql executed
        Dim decFlightCost As Decimal

        Dim intFlightID = cboFutureFlights.SelectedValue
        Dim intPassengerID = strCurrentUser
        Dim strSeat = lblSeat.Text

        If radNoReservation.Checked = True Then
            strSeat = "Seat to be selected at check-in."
        End If

        Try
            If radNoReservation.Checked = True Then
                Decimal.TryParse(lblNormalCost.Text, decFlightCost)
            ElseIf radReserveSeat.Checked = True Then
                Decimal.TryParse(lblReserveCost.Text, decFlightCost)
            End If

            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            strSelect = "Select MAX(intFlightPassengerID) + 1 As intNextPrimaryKey From TFlightPassengers"

            ' Execute command
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            ' Read result( highest ID )
            drSourceTable.Read()

            ' Null? (empty table)
            If drSourceTable.IsDBNull(0) = True Then

                ' Yes, start numbering at 1
                intNextPrimaryKey = 1

            Else

                ' No, get the next highest ID
                intNextPrimaryKey = CInt(drSourceTable("intNextPrimaryKey"))

            End If

            strInsert = "INSERT INTO TFlightPassengers (intFlightPassengerID, intFlightID, intPassengerID, strSeat, decFlightCost)" &
                    " VALUES (" & intNextPrimaryKey & ", " & intFlightID & ", " & intPassengerID & ", '" & strSeat & "', " & decFlightCost & ")"

            ' use insert command with sql string and connection object
            cmdInsert = New OleDb.OleDbCommand(strInsert, m_conAdministrator)

            ' execute query to insert data
            intRowsAffected = cmdInsert.ExecuteNonQuery()

            ' If not 0 insert successful
            If intRowsAffected > 0 Then
                MessageBox.Show("You've been added to the flight from " & cboFutureFlights.Text & ".")    ' let user know success
                ' close new player form
            End If

            CloseDatabaseConnection()       ' close connection if insert didn't work
            Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class
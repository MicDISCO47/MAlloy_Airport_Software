﻿Public Class frmAddAttendantFlight
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub

    Private Sub frmAddAttendantFlight_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strSelect As String = ""
        Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement
        Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to
        Dim dt As DataTable = New DataTable ' this is the table we will load from our reader
        Dim dtf As DataTable = New DataTable ' this is the table we will load from our reader
        Try

            ' open the DB this is in module
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                "The application will now close.",
                                Me.Text + " Error",
                                MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            ' Build the select statement
            strSelect = "SELECT intAttendantID, strFirstName + ' ' + strLastName as AttendantName FROM TAttendants"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            ' load table from data reader
            dt.Load(drSourceTable)

            cboAttendants.ValueMember = "intAttendantID"
            cboAttendants.DisplayMember = "AttendantName"
            cboAttendants.DataSource = dt

            If cboAttendants.Items.Count > 0 Then cboAttendants.SelectedIndex = 0

            ' Build the select statement to obtain States
            strSelect = "SELECT intFlightID, TAF.strAirportCity + ' to ' + TAT.strAirportCity As Travel_Path " &
                "From TFlights As TF JOIN TAirports As TAT ON TF.intToAirportID = TAT.intAirportID " &
                "JOIN TAirports As TAF ON TAF.intAirportID = TF.intFromAirportID " &
                "Where TF.dtmFlightDate > '4/1/2025'"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            dtf.Load(drSourceTable)

            'load the States result set into the combobox.  For VB, we do this by binding the data to the combobox

            cboFutureFlights.ValueMember = "intFlightID"
            cboFutureFlights.DisplayMember = "Travel_Path"
            cboFutureFlights.DataSource = dtf

            ' Clean up
            drSourceTable.Close()

            ' close the database connection
            CloseDatabaseConnection()

        Catch excError As Exception

            ' Log and display error message
            MessageBox.Show(excError.Message)

        End Try
    End Sub

    Private Sub btnAddToFlight_Click(sender As Object, e As EventArgs) Handles btnAddToFlight.Click
        Dim strSelect As String
        Dim strInsert As String
        Dim cmdSelect As OleDb.OleDbCommand ' select command object
        Dim cmdInsert As OleDb.OleDbCommand ' insert command object
        Dim drSourceTable As OleDb.OleDbDataReader ' data reader for pulling info
        Dim intNextPrimaryKey As Integer ' holds next highest PK value
        Dim intRowsAffected As Integer  ' how many rows were affected when sql executed
        Dim result As DialogResult  ' this is the result of which button the user selects

        Try
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            result = MessageBox.Show("Confirm " & cboAttendants.Text & " for flight: " & cboFutureFlights.Text & "?", "Confirm Flight?", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)

            ' this will figure out which button was selected. Cancel and No does nothing, Yes will allow deletion
            Select Case result
                Case DialogResult.Cancel
                    MessageBox.Show("Action Canceled")
                Case DialogResult.No
                    MessageBox.Show("Action Canceled")
                Case DialogResult.Yes

                    strSelect = "Select MAX(intAttendantFlightID) + 1 As intNextPrimaryKey From TAttendantFlights"

                    ' Execute command
                    cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
                    drSourceTable = cmdSelect.ExecuteReader

                    ' Read result( highest ID )
                    drSourceTable.Read()

                    ' Null? (empty table)
                    If drSourceTable.IsDBNull(0) = True Then

                        ' Yes, start numbering at 1
                        intNextPrimaryKey = 1

                    Else

                        ' No, get the next highest ID
                        intNextPrimaryKey = CInt(drSourceTable("intNextPrimaryKey"))

                    End If

                    strInsert = "INSERT INTO TAttendantFlights (intAttendantFlightID, intFlightID, intAttendantID)" &
                                    " VALUES (" & intNextPrimaryKey & ", " & cboFutureFlights.SelectedValue & ", " & cboAttendants.SelectedValue & ")"

                    ' use insert command with sql string and connection object
                    cmdInsert = New OleDb.OleDbCommand(strInsert, m_conAdministrator)

                    ' execute query to insert data
                    intRowsAffected = cmdInsert.ExecuteNonQuery()

                    ' If not 0 insert successful
                    If intRowsAffected > 0 Then
                        MessageBox.Show("Flight has been added")    ' let user know success
                        ' close new player form
                    End If


                    CloseDatabaseConnection()       ' close connection if insert didn't work
                    Close()

            End Select

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class
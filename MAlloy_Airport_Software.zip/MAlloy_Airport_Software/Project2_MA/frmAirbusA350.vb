﻿Public Class frmAirbusA350
    Private Sub frmAirbusA350_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strSelect As String = ""
        Dim cmdSelect As OleDb.OleDbCommand            ' this will be used for our Select statement
        Dim drSourceTable As OleDb.OleDbDataReader     ' this will be where our result set will 
        Dim dt As DataTable = New DataTable            ' this is the table we will load from our reader
        Dim objParam As OleDb.OleDbParameter

        Try
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            cmdSelect = New OleDb.OleDbCommand("uspSeatCheck", m_conAdministrator)
            cmdSelect.CommandType = CommandType.StoredProcedure

            objParam = cmdSelect.Parameters.Add("@flight", OleDb.OleDbType.Integer)
            objParam.Direction = ParameterDirection.Input
            objParam.Value = strCurrentFlight

            drSourceTable = cmdSelect.ExecuteReader

            While drSourceTable.Read()
                For Each cb As CheckBox In Controls.OfType(Of CheckBox)
                    If drSourceTable("strSeat") = cb.Name Then
                        cb.Checked = True
                        cb.Enabled = False
                    End If
                Next
            End While
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnReserveSeat_Click(sender As Object, e As EventArgs) Handles btnReserveSeat.Click

        Dim intCheckedBoxes = 0

        For Each cb As CheckBox In Controls.OfType(Of CheckBox)
            If cb.Enabled = True Then
                If cb.Checked = True Then
                    intCheckedBoxes += 1
                    strCurrentSeat = cb.Name
                End If
            End If
        Next

        If intCheckedBoxes = 1 Then
            Close()
        ElseIf intCheckedBoxes = 0 Then
            MessageBox.Show("No seat has been selected.")
        ElseIf intCheckedBoxes > 1 Then
            MessageBox.Show("Too many seats have been selected.")
        End If
    End Sub

    Private Sub btnCancel_Click(sender As Object, e As EventArgs) Handles btnCancel.Click
        strCurrentSeat = ""
        Close()
    End Sub
End Class
﻿Public Class frmUpdateAttendant
    Private Sub frmUpdateAttendant_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try

            Dim strSelect As String = ""
            Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement
            Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to

            ' open the DB
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()
            End If

            'Pilot select statement
            strSelect = "Select * From TAttendants " &
                    "Where intAttendantID = " & strCurrentUser

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            drSourceTable.Read()
            txtFirstName.Text = drSourceTable("strFirstName")
            txtLastName.Text = drSourceTable("strLastName")
            txtEmployeeID.Text = drSourceTable("strEmployeeID")
            dtpDateofHire.Value = drSourceTable("dtmDateofHire")
            dtpDateofTermination.Value = drSourceTable("dtmDateofTermination")

            strSelect = "SELECT * From TEmployees " &
                "Where intEmployeeRoleID = 2 " &
                "and intEmployeeID = " & strCurrentUser

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            drSourceTable.Read()

            txtUserID.Text = drSourceTable("strEmployeeLoginID")
            txtPassword.Text = drSourceTable("strEmployeePassword")

            ' close the database connection
            CloseDatabaseConnection()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim strFirstName As String
        Dim strLastName As String
        Dim strEmployeeID As String
        Dim strDateofHire As String
        Dim strDateofTermination As String
        Dim strUserID As String
        Dim strPassword As String

        Dim blnValidated = True

        Dim strSelect As String
        Dim cmdUpdate As OleDb.OleDbCommand ' update command object
        Dim drSourceTable As OleDb.OleDbDataReader ' data reader for pulling info
        Dim intRowsAffected As Integer  ' how many rows were affected when sql executed

        ' validate data is entered
        blnValidated = True
        Get_And_Validate_Inputs(strFirstName, strLastName, strEmployeeID, strDateofHire, strDateofTermination, strUserID, strPassword, blnValidated)

        If blnValidated = True Then
            Try
                If OpenDatabaseConnectionSQLServer() = False Then

                    ' No, warn the user ...
                    MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                        "The application will now close.",
                                        Me.Text + " Error",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error)

                    ' and close the form/application
                    Me.Close()

                End If

                ' Build the select statement using PK from name selected
                strSelect = "Update TAttendants Set " &
                            "strFirstName = '" & strFirstName & "', " &
                            "strLastName = '" & strLastName & "', " &
                            "strEmployeeID = '" & strEmployeeID & "', " &
                            "dtmDateofHire = '" & strDateofHire & "', " &
                            "dtmDateofTermination = '" & strDateofTermination & "' " &
                            "Where intAttendantID = " & strCurrentUser

                cmdUpdate = New OleDb.OleDbCommand(strSelect, m_conAdministrator)

                ' IUpdate the row with execute the statement
                intRowsAffected = cmdUpdate.ExecuteNonQuery()

                ' have to let the user know what happened 
                If intRowsAffected = 1 Then
                    MessageBox.Show("Attendant Update successful")
                Else
                    MessageBox.Show("Attendant Update failed")
                End If

                intRowsAffected = 0

                ' Build the select statement using PK from name selected
                strSelect = "Update TEmployees Set " &
                            "strEmployeeLoginID = '" & strUserID & "', " &
                            "strEmployeePassword = '" & strPassword & "', " &
                            "intEmployeeRoleID = " & 2 &
                            "Where intEmployeeID = " & strCurrentUser

                cmdUpdate = New OleDb.OleDbCommand(strSelect, m_conAdministrator)

                ' IUpdate the row with execute the statement
                intRowsAffected = cmdUpdate.ExecuteNonQuery()

                ' have to let the user know what happened 
                If intRowsAffected = 1 Then
                    MessageBox.Show("Employee Update successful")
                Else
                    MessageBox.Show("Employee Update failed")
                End If

                ' close the database connection
                CloseDatabaseConnection()

                Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
    End Sub

    Private Sub Get_And_Validate_Inputs(ByRef strFirstName As String, ByRef strLastName As String, ByRef strEmployeeID As String, ByRef strDateofHire As String, ByRef strDateofTermination As String, ByRef strUserID As String, ByRef strPassword As String, ByRef blnValidated As Boolean)
        Get_And_Validate_FirstName(strFirstName, blnValidated, txtFirstName)
        If blnValidated = True Then
            Get_And_Validate_LastName(strLastName, blnValidated, txtLastName)
            If blnValidated = True Then
                Get_And_Validate_strEmployeeID(strEmployeeID, blnValidated, txtEmployeeID)
                If blnValidated = True Then
                    Get_And_Validate_DateofHire(strDateofHire, blnValidated, dtpDateofHire)
                    If blnValidated = True Then
                        Get_And_Validate_DateofTermination(strDateofTermination, blnValidated, dtpDateofHire, dtpDateofTermination)
                        If blnValidated = True Then
                            Get_And_Validate_EmployeeUserIDUpt(strUserID, blnValidated, txtUserID)
                            If blnValidated = True Then
                                Get_And_Validate_Password(strPassword, blnValidated, txtPassword)
                            End If
                        End If
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class
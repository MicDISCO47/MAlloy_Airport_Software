﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmBoeing747_8
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnReserveSeat = New System.Windows.Forms.Button()
        Me.Labe = New System.Windows.Forms.Label()
        Me.Label = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.LabelD = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.B10 = New System.Windows.Forms.CheckBox()
        Me.A10 = New System.Windows.Forms.CheckBox()
        Me.B9 = New System.Windows.Forms.CheckBox()
        Me.A9 = New System.Windows.Forms.CheckBox()
        Me.B8 = New System.Windows.Forms.CheckBox()
        Me.A8 = New System.Windows.Forms.CheckBox()
        Me.B7 = New System.Windows.Forms.CheckBox()
        Me.A7 = New System.Windows.Forms.CheckBox()
        Me.B6 = New System.Windows.Forms.CheckBox()
        Me.A6 = New System.Windows.Forms.CheckBox()
        Me.B5 = New System.Windows.Forms.CheckBox()
        Me.A5 = New System.Windows.Forms.CheckBox()
        Me.B4 = New System.Windows.Forms.CheckBox()
        Me.A4 = New System.Windows.Forms.CheckBox()
        Me.B3 = New System.Windows.Forms.CheckBox()
        Me.A3 = New System.Windows.Forms.CheckBox()
        Me.B2 = New System.Windows.Forms.CheckBox()
        Me.A2 = New System.Windows.Forms.CheckBox()
        Me.B1 = New System.Windows.Forms.CheckBox()
        Me.A1 = New System.Windows.Forms.CheckBox()
        Me.C10 = New System.Windows.Forms.CheckBox()
        Me.C9 = New System.Windows.Forms.CheckBox()
        Me.C8 = New System.Windows.Forms.CheckBox()
        Me.C7 = New System.Windows.Forms.CheckBox()
        Me.C6 = New System.Windows.Forms.CheckBox()
        Me.C5 = New System.Windows.Forms.CheckBox()
        Me.C4 = New System.Windows.Forms.CheckBox()
        Me.C3 = New System.Windows.Forms.CheckBox()
        Me.C2 = New System.Windows.Forms.CheckBox()
        Me.C1 = New System.Windows.Forms.CheckBox()
        Me.D10 = New System.Windows.Forms.CheckBox()
        Me.D9 = New System.Windows.Forms.CheckBox()
        Me.D8 = New System.Windows.Forms.CheckBox()
        Me.D7 = New System.Windows.Forms.CheckBox()
        Me.D6 = New System.Windows.Forms.CheckBox()
        Me.D5 = New System.Windows.Forms.CheckBox()
        Me.D4 = New System.Windows.Forms.CheckBox()
        Me.D3 = New System.Windows.Forms.CheckBox()
        Me.D2 = New System.Windows.Forms.CheckBox()
        Me.D1 = New System.Windows.Forms.CheckBox()
        Me.E10 = New System.Windows.Forms.CheckBox()
        Me.E9 = New System.Windows.Forms.CheckBox()
        Me.E8 = New System.Windows.Forms.CheckBox()
        Me.E7 = New System.Windows.Forms.CheckBox()
        Me.E6 = New System.Windows.Forms.CheckBox()
        Me.E5 = New System.Windows.Forms.CheckBox()
        Me.E4 = New System.Windows.Forms.CheckBox()
        Me.E3 = New System.Windows.Forms.CheckBox()
        Me.E2 = New System.Windows.Forms.CheckBox()
        Me.E1 = New System.Windows.Forms.CheckBox()
        Me.F10 = New System.Windows.Forms.CheckBox()
        Me.F9 = New System.Windows.Forms.CheckBox()
        Me.F8 = New System.Windows.Forms.CheckBox()
        Me.F7 = New System.Windows.Forms.CheckBox()
        Me.F6 = New System.Windows.Forms.CheckBox()
        Me.F5 = New System.Windows.Forms.CheckBox()
        Me.F4 = New System.Windows.Forms.CheckBox()
        Me.F3 = New System.Windows.Forms.CheckBox()
        Me.F2 = New System.Windows.Forms.CheckBox()
        Me.F1 = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(189, 414)
        Me.btnCancel.Margin = New System.Windows.Forms.Padding(4)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(139, 70)
        Me.btnCancel.TabIndex = 194
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnReserveSeat
        '
        Me.btnReserveSeat.Location = New System.Drawing.Point(28, 414)
        Me.btnReserveSeat.Margin = New System.Windows.Forms.Padding(4)
        Me.btnReserveSeat.Name = "btnReserveSeat"
        Me.btnReserveSeat.Size = New System.Drawing.Size(139, 70)
        Me.btnReserveSeat.TabIndex = 193
        Me.btnReserveSeat.Text = "Reserve Seat"
        Me.btnReserveSeat.UseVisualStyleBackColor = True
        '
        'Labe
        '
        Me.Labe.Location = New System.Drawing.Point(77, 20)
        Me.Labe.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Labe.Name = "Labe"
        Me.Labe.Size = New System.Drawing.Size(28, 26)
        Me.Labe.TabIndex = 129
        Me.Labe.Text = "B"
        Me.Labe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label
        '
        Me.Label.Location = New System.Drawing.Point(124, 20)
        Me.Label.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label.Name = "Label"
        Me.Label.Size = New System.Drawing.Size(28, 26)
        Me.Label.TabIndex = 130
        Me.Label.Text = "C"
        Me.Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(208, 20)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(28, 26)
        Me.Label3.TabIndex = 131
        Me.Label3.Text = "D"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelD
        '
        Me.LabelD.Location = New System.Drawing.Point(261, 20)
        Me.LabelD.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelD.Name = "LabelD"
        Me.LabelD.Size = New System.Drawing.Size(28, 26)
        Me.LabelD.TabIndex = 132
        Me.LabelD.Text = "E"
        Me.LabelD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(166, 57)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(28, 26)
        Me.Label5.TabIndex = 133
        Me.Label5.Text = "1"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(166, 92)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(28, 26)
        Me.Label6.TabIndex = 134
        Me.Label6.Text = "2"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label15
        '
        Me.Label15.Location = New System.Drawing.Point(166, 333)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(28, 26)
        Me.Label15.TabIndex = 143
        Me.Label15.Text = "9"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(166, 126)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(28, 26)
        Me.Label7.TabIndex = 135
        Me.Label7.Text = "3"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label14
        '
        Me.Label14.Location = New System.Drawing.Point(166, 367)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(28, 26)
        Me.Label14.TabIndex = 142
        Me.Label14.Text = "10"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(166, 160)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(28, 26)
        Me.Label8.TabIndex = 136
        Me.Label8.Text = "4"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(166, 195)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(28, 26)
        Me.Label9.TabIndex = 137
        Me.Label9.Text = "5"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(166, 229)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(28, 26)
        Me.Label10.TabIndex = 138
        Me.Label10.Text = "6"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label16
        '
        Me.Label16.Location = New System.Drawing.Point(166, 298)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(28, 26)
        Me.Label16.TabIndex = 144
        Me.Label16.Text = "8"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(166, 264)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(28, 26)
        Me.Label11.TabIndex = 139
        Me.Label11.Text = "7"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(25, 20)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(28, 26)
        Me.Label1.TabIndex = 195
        Me.Label1.Text = "A"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(316, 20)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(28, 26)
        Me.Label2.TabIndex = 196
        Me.Label2.Text = "F"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'B10
        '
        Me.B10.AutoSize = True
        Me.B10.Location = New System.Drawing.Point(80, 373)
        Me.B10.Name = "B10"
        Me.B10.Size = New System.Drawing.Size(18, 17)
        Me.B10.TabIndex = 216
        Me.B10.UseVisualStyleBackColor = True
        '
        'A10
        '
        Me.A10.AutoSize = True
        Me.A10.Location = New System.Drawing.Point(28, 373)
        Me.A10.Name = "A10"
        Me.A10.Size = New System.Drawing.Size(18, 17)
        Me.A10.TabIndex = 215
        Me.A10.UseVisualStyleBackColor = True
        '
        'B9
        '
        Me.B9.AutoSize = True
        Me.B9.Location = New System.Drawing.Point(80, 339)
        Me.B9.Name = "B9"
        Me.B9.Size = New System.Drawing.Size(18, 17)
        Me.B9.TabIndex = 214
        Me.B9.UseVisualStyleBackColor = True
        '
        'A9
        '
        Me.A9.AutoSize = True
        Me.A9.Location = New System.Drawing.Point(28, 339)
        Me.A9.Name = "A9"
        Me.A9.Size = New System.Drawing.Size(18, 17)
        Me.A9.TabIndex = 213
        Me.A9.UseVisualStyleBackColor = True
        '
        'B8
        '
        Me.B8.AutoSize = True
        Me.B8.Location = New System.Drawing.Point(80, 304)
        Me.B8.Name = "B8"
        Me.B8.Size = New System.Drawing.Size(18, 17)
        Me.B8.TabIndex = 212
        Me.B8.UseVisualStyleBackColor = True
        '
        'A8
        '
        Me.A8.AutoSize = True
        Me.A8.Location = New System.Drawing.Point(28, 304)
        Me.A8.Name = "A8"
        Me.A8.Size = New System.Drawing.Size(18, 17)
        Me.A8.TabIndex = 211
        Me.A8.UseVisualStyleBackColor = True
        '
        'B7
        '
        Me.B7.AutoSize = True
        Me.B7.Location = New System.Drawing.Point(80, 270)
        Me.B7.Name = "B7"
        Me.B7.Size = New System.Drawing.Size(18, 17)
        Me.B7.TabIndex = 210
        Me.B7.UseVisualStyleBackColor = True
        '
        'A7
        '
        Me.A7.AutoSize = True
        Me.A7.Location = New System.Drawing.Point(28, 270)
        Me.A7.Name = "A7"
        Me.A7.Size = New System.Drawing.Size(18, 17)
        Me.A7.TabIndex = 209
        Me.A7.UseVisualStyleBackColor = True
        '
        'B6
        '
        Me.B6.AutoSize = True
        Me.B6.Location = New System.Drawing.Point(80, 235)
        Me.B6.Name = "B6"
        Me.B6.Size = New System.Drawing.Size(18, 17)
        Me.B6.TabIndex = 208
        Me.B6.UseVisualStyleBackColor = True
        '
        'A6
        '
        Me.A6.AutoSize = True
        Me.A6.Location = New System.Drawing.Point(28, 235)
        Me.A6.Name = "A6"
        Me.A6.Size = New System.Drawing.Size(18, 17)
        Me.A6.TabIndex = 207
        Me.A6.UseVisualStyleBackColor = True
        '
        'B5
        '
        Me.B5.AutoSize = True
        Me.B5.Location = New System.Drawing.Point(80, 201)
        Me.B5.Name = "B5"
        Me.B5.Size = New System.Drawing.Size(18, 17)
        Me.B5.TabIndex = 206
        Me.B5.UseVisualStyleBackColor = True
        '
        'A5
        '
        Me.A5.AutoSize = True
        Me.A5.Location = New System.Drawing.Point(28, 201)
        Me.A5.Name = "A5"
        Me.A5.Size = New System.Drawing.Size(18, 17)
        Me.A5.TabIndex = 205
        Me.A5.UseVisualStyleBackColor = True
        '
        'B4
        '
        Me.B4.AutoSize = True
        Me.B4.Location = New System.Drawing.Point(80, 166)
        Me.B4.Name = "B4"
        Me.B4.Size = New System.Drawing.Size(18, 17)
        Me.B4.TabIndex = 204
        Me.B4.UseVisualStyleBackColor = True
        '
        'A4
        '
        Me.A4.AutoSize = True
        Me.A4.Location = New System.Drawing.Point(28, 166)
        Me.A4.Name = "A4"
        Me.A4.Size = New System.Drawing.Size(18, 17)
        Me.A4.TabIndex = 203
        Me.A4.UseVisualStyleBackColor = True
        '
        'B3
        '
        Me.B3.AutoSize = True
        Me.B3.Location = New System.Drawing.Point(80, 132)
        Me.B3.Name = "B3"
        Me.B3.Size = New System.Drawing.Size(18, 17)
        Me.B3.TabIndex = 202
        Me.B3.UseVisualStyleBackColor = True
        '
        'A3
        '
        Me.A3.AutoSize = True
        Me.A3.Location = New System.Drawing.Point(28, 132)
        Me.A3.Name = "A3"
        Me.A3.Size = New System.Drawing.Size(18, 17)
        Me.A3.TabIndex = 201
        Me.A3.UseVisualStyleBackColor = True
        '
        'B2
        '
        Me.B2.AutoSize = True
        Me.B2.Location = New System.Drawing.Point(80, 98)
        Me.B2.Name = "B2"
        Me.B2.Size = New System.Drawing.Size(18, 17)
        Me.B2.TabIndex = 200
        Me.B2.UseVisualStyleBackColor = True
        '
        'A2
        '
        Me.A2.AutoSize = True
        Me.A2.Location = New System.Drawing.Point(28, 98)
        Me.A2.Name = "A2"
        Me.A2.Size = New System.Drawing.Size(18, 17)
        Me.A2.TabIndex = 199
        Me.A2.UseVisualStyleBackColor = True
        '
        'B1
        '
        Me.B1.AutoSize = True
        Me.B1.Location = New System.Drawing.Point(80, 63)
        Me.B1.Name = "B1"
        Me.B1.Size = New System.Drawing.Size(18, 17)
        Me.B1.TabIndex = 198
        Me.B1.UseVisualStyleBackColor = True
        '
        'A1
        '
        Me.A1.AutoSize = True
        Me.A1.Location = New System.Drawing.Point(28, 63)
        Me.A1.Name = "A1"
        Me.A1.Size = New System.Drawing.Size(18, 17)
        Me.A1.TabIndex = 197
        Me.A1.UseVisualStyleBackColor = True
        '
        'C10
        '
        Me.C10.AutoSize = True
        Me.C10.Location = New System.Drawing.Point(127, 373)
        Me.C10.Name = "C10"
        Me.C10.Size = New System.Drawing.Size(18, 17)
        Me.C10.TabIndex = 226
        Me.C10.UseVisualStyleBackColor = True
        '
        'C9
        '
        Me.C9.AutoSize = True
        Me.C9.Location = New System.Drawing.Point(127, 339)
        Me.C9.Name = "C9"
        Me.C9.Size = New System.Drawing.Size(18, 17)
        Me.C9.TabIndex = 225
        Me.C9.UseVisualStyleBackColor = True
        '
        'C8
        '
        Me.C8.AutoSize = True
        Me.C8.Location = New System.Drawing.Point(127, 304)
        Me.C8.Name = "C8"
        Me.C8.Size = New System.Drawing.Size(18, 17)
        Me.C8.TabIndex = 224
        Me.C8.UseVisualStyleBackColor = True
        '
        'C7
        '
        Me.C7.AutoSize = True
        Me.C7.Location = New System.Drawing.Point(127, 270)
        Me.C7.Name = "C7"
        Me.C7.Size = New System.Drawing.Size(18, 17)
        Me.C7.TabIndex = 223
        Me.C7.UseVisualStyleBackColor = True
        '
        'C6
        '
        Me.C6.AutoSize = True
        Me.C6.Location = New System.Drawing.Point(127, 235)
        Me.C6.Name = "C6"
        Me.C6.Size = New System.Drawing.Size(18, 17)
        Me.C6.TabIndex = 222
        Me.C6.UseVisualStyleBackColor = True
        '
        'C5
        '
        Me.C5.AutoSize = True
        Me.C5.Location = New System.Drawing.Point(127, 201)
        Me.C5.Name = "C5"
        Me.C5.Size = New System.Drawing.Size(18, 17)
        Me.C5.TabIndex = 221
        Me.C5.UseVisualStyleBackColor = True
        '
        'C4
        '
        Me.C4.AutoSize = True
        Me.C4.Location = New System.Drawing.Point(127, 166)
        Me.C4.Name = "C4"
        Me.C4.Size = New System.Drawing.Size(18, 17)
        Me.C4.TabIndex = 220
        Me.C4.UseVisualStyleBackColor = True
        '
        'C3
        '
        Me.C3.AutoSize = True
        Me.C3.Location = New System.Drawing.Point(127, 132)
        Me.C3.Name = "C3"
        Me.C3.Size = New System.Drawing.Size(18, 17)
        Me.C3.TabIndex = 219
        Me.C3.UseVisualStyleBackColor = True
        '
        'C2
        '
        Me.C2.AutoSize = True
        Me.C2.Location = New System.Drawing.Point(127, 98)
        Me.C2.Name = "C2"
        Me.C2.Size = New System.Drawing.Size(18, 17)
        Me.C2.TabIndex = 218
        Me.C2.UseVisualStyleBackColor = True
        '
        'C1
        '
        Me.C1.AutoSize = True
        Me.C1.Location = New System.Drawing.Point(127, 63)
        Me.C1.Name = "C1"
        Me.C1.Size = New System.Drawing.Size(18, 17)
        Me.C1.TabIndex = 217
        Me.C1.UseVisualStyleBackColor = True
        '
        'D10
        '
        Me.D10.AutoSize = True
        Me.D10.Location = New System.Drawing.Point(218, 373)
        Me.D10.Name = "D10"
        Me.D10.Size = New System.Drawing.Size(18, 17)
        Me.D10.TabIndex = 236
        Me.D10.UseVisualStyleBackColor = True
        '
        'D9
        '
        Me.D9.AutoSize = True
        Me.D9.Location = New System.Drawing.Point(218, 339)
        Me.D9.Name = "D9"
        Me.D9.Size = New System.Drawing.Size(18, 17)
        Me.D9.TabIndex = 235
        Me.D9.UseVisualStyleBackColor = True
        '
        'D8
        '
        Me.D8.AutoSize = True
        Me.D8.Location = New System.Drawing.Point(218, 304)
        Me.D8.Name = "D8"
        Me.D8.Size = New System.Drawing.Size(18, 17)
        Me.D8.TabIndex = 234
        Me.D8.UseVisualStyleBackColor = True
        '
        'D7
        '
        Me.D7.AutoSize = True
        Me.D7.Location = New System.Drawing.Point(218, 270)
        Me.D7.Name = "D7"
        Me.D7.Size = New System.Drawing.Size(18, 17)
        Me.D7.TabIndex = 233
        Me.D7.UseVisualStyleBackColor = True
        '
        'D6
        '
        Me.D6.AutoSize = True
        Me.D6.Location = New System.Drawing.Point(218, 235)
        Me.D6.Name = "D6"
        Me.D6.Size = New System.Drawing.Size(18, 17)
        Me.D6.TabIndex = 232
        Me.D6.UseVisualStyleBackColor = True
        '
        'D5
        '
        Me.D5.AutoSize = True
        Me.D5.Location = New System.Drawing.Point(218, 201)
        Me.D5.Name = "D5"
        Me.D5.Size = New System.Drawing.Size(18, 17)
        Me.D5.TabIndex = 231
        Me.D5.UseVisualStyleBackColor = True
        '
        'D4
        '
        Me.D4.AutoSize = True
        Me.D4.Location = New System.Drawing.Point(218, 166)
        Me.D4.Name = "D4"
        Me.D4.Size = New System.Drawing.Size(18, 17)
        Me.D4.TabIndex = 230
        Me.D4.UseVisualStyleBackColor = True
        '
        'D3
        '
        Me.D3.AutoSize = True
        Me.D3.Location = New System.Drawing.Point(218, 132)
        Me.D3.Name = "D3"
        Me.D3.Size = New System.Drawing.Size(18, 17)
        Me.D3.TabIndex = 229
        Me.D3.UseVisualStyleBackColor = True
        '
        'D2
        '
        Me.D2.AutoSize = True
        Me.D2.Location = New System.Drawing.Point(218, 98)
        Me.D2.Name = "D2"
        Me.D2.Size = New System.Drawing.Size(18, 17)
        Me.D2.TabIndex = 228
        Me.D2.UseVisualStyleBackColor = True
        '
        'D1
        '
        Me.D1.AutoSize = True
        Me.D1.Location = New System.Drawing.Point(218, 63)
        Me.D1.Name = "D1"
        Me.D1.Size = New System.Drawing.Size(18, 17)
        Me.D1.TabIndex = 227
        Me.D1.UseVisualStyleBackColor = True
        '
        'E10
        '
        Me.E10.AutoSize = True
        Me.E10.Location = New System.Drawing.Point(271, 373)
        Me.E10.Name = "E10"
        Me.E10.Size = New System.Drawing.Size(18, 17)
        Me.E10.TabIndex = 246
        Me.E10.UseVisualStyleBackColor = True
        '
        'E9
        '
        Me.E9.AutoSize = True
        Me.E9.Location = New System.Drawing.Point(271, 339)
        Me.E9.Name = "E9"
        Me.E9.Size = New System.Drawing.Size(18, 17)
        Me.E9.TabIndex = 245
        Me.E9.UseVisualStyleBackColor = True
        '
        'E8
        '
        Me.E8.AutoSize = True
        Me.E8.Location = New System.Drawing.Point(271, 304)
        Me.E8.Name = "E8"
        Me.E8.Size = New System.Drawing.Size(18, 17)
        Me.E8.TabIndex = 244
        Me.E8.UseVisualStyleBackColor = True
        '
        'E7
        '
        Me.E7.AutoSize = True
        Me.E7.Location = New System.Drawing.Point(271, 270)
        Me.E7.Name = "E7"
        Me.E7.Size = New System.Drawing.Size(18, 17)
        Me.E7.TabIndex = 243
        Me.E7.UseVisualStyleBackColor = True
        '
        'E6
        '
        Me.E6.AutoSize = True
        Me.E6.Location = New System.Drawing.Point(271, 235)
        Me.E6.Name = "E6"
        Me.E6.Size = New System.Drawing.Size(18, 17)
        Me.E6.TabIndex = 242
        Me.E6.UseVisualStyleBackColor = True
        '
        'E5
        '
        Me.E5.AutoSize = True
        Me.E5.Location = New System.Drawing.Point(271, 201)
        Me.E5.Name = "E5"
        Me.E5.Size = New System.Drawing.Size(18, 17)
        Me.E5.TabIndex = 241
        Me.E5.UseVisualStyleBackColor = True
        '
        'E4
        '
        Me.E4.AutoSize = True
        Me.E4.Location = New System.Drawing.Point(271, 166)
        Me.E4.Name = "E4"
        Me.E4.Size = New System.Drawing.Size(18, 17)
        Me.E4.TabIndex = 240
        Me.E4.UseVisualStyleBackColor = True
        '
        'E3
        '
        Me.E3.AutoSize = True
        Me.E3.Location = New System.Drawing.Point(271, 132)
        Me.E3.Name = "E3"
        Me.E3.Size = New System.Drawing.Size(18, 17)
        Me.E3.TabIndex = 239
        Me.E3.UseVisualStyleBackColor = True
        '
        'E2
        '
        Me.E2.AutoSize = True
        Me.E2.Location = New System.Drawing.Point(271, 98)
        Me.E2.Name = "E2"
        Me.E2.Size = New System.Drawing.Size(18, 17)
        Me.E2.TabIndex = 238
        Me.E2.UseVisualStyleBackColor = True
        '
        'E1
        '
        Me.E1.AutoSize = True
        Me.E1.Location = New System.Drawing.Point(271, 63)
        Me.E1.Name = "E1"
        Me.E1.Size = New System.Drawing.Size(18, 17)
        Me.E1.TabIndex = 237
        Me.E1.UseVisualStyleBackColor = True
        '
        'F10
        '
        Me.F10.AutoSize = True
        Me.F10.Location = New System.Drawing.Point(326, 373)
        Me.F10.Name = "F10"
        Me.F10.Size = New System.Drawing.Size(18, 17)
        Me.F10.TabIndex = 256
        Me.F10.UseVisualStyleBackColor = True
        '
        'F9
        '
        Me.F9.AutoSize = True
        Me.F9.Location = New System.Drawing.Point(326, 339)
        Me.F9.Name = "F9"
        Me.F9.Size = New System.Drawing.Size(18, 17)
        Me.F9.TabIndex = 255
        Me.F9.UseVisualStyleBackColor = True
        '
        'F8
        '
        Me.F8.AutoSize = True
        Me.F8.Location = New System.Drawing.Point(326, 304)
        Me.F8.Name = "F8"
        Me.F8.Size = New System.Drawing.Size(18, 17)
        Me.F8.TabIndex = 254
        Me.F8.UseVisualStyleBackColor = True
        '
        'F7
        '
        Me.F7.AutoSize = True
        Me.F7.Location = New System.Drawing.Point(326, 270)
        Me.F7.Name = "F7"
        Me.F7.Size = New System.Drawing.Size(18, 17)
        Me.F7.TabIndex = 253
        Me.F7.UseVisualStyleBackColor = True
        '
        'F6
        '
        Me.F6.AutoSize = True
        Me.F6.Location = New System.Drawing.Point(326, 235)
        Me.F6.Name = "F6"
        Me.F6.Size = New System.Drawing.Size(18, 17)
        Me.F6.TabIndex = 252
        Me.F6.UseVisualStyleBackColor = True
        '
        'F5
        '
        Me.F5.AutoSize = True
        Me.F5.Location = New System.Drawing.Point(326, 201)
        Me.F5.Name = "F5"
        Me.F5.Size = New System.Drawing.Size(18, 17)
        Me.F5.TabIndex = 251
        Me.F5.UseVisualStyleBackColor = True
        '
        'F4
        '
        Me.F4.AutoSize = True
        Me.F4.Location = New System.Drawing.Point(326, 166)
        Me.F4.Name = "F4"
        Me.F4.Size = New System.Drawing.Size(18, 17)
        Me.F4.TabIndex = 250
        Me.F4.UseVisualStyleBackColor = True
        '
        'F3
        '
        Me.F3.AutoSize = True
        Me.F3.Location = New System.Drawing.Point(326, 132)
        Me.F3.Name = "F3"
        Me.F3.Size = New System.Drawing.Size(18, 17)
        Me.F3.TabIndex = 249
        Me.F3.UseVisualStyleBackColor = True
        '
        'F2
        '
        Me.F2.AutoSize = True
        Me.F2.Location = New System.Drawing.Point(326, 98)
        Me.F2.Name = "F2"
        Me.F2.Size = New System.Drawing.Size(18, 17)
        Me.F2.TabIndex = 248
        Me.F2.UseVisualStyleBackColor = True
        '
        'F1
        '
        Me.F1.AutoSize = True
        Me.F1.Location = New System.Drawing.Point(326, 63)
        Me.F1.Name = "F1"
        Me.F1.Size = New System.Drawing.Size(18, 17)
        Me.F1.TabIndex = 247
        Me.F1.UseVisualStyleBackColor = True
        '
        'frmBoeing747_8
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(371, 508)
        Me.Controls.Add(Me.F10)
        Me.Controls.Add(Me.F9)
        Me.Controls.Add(Me.F8)
        Me.Controls.Add(Me.F7)
        Me.Controls.Add(Me.F6)
        Me.Controls.Add(Me.F5)
        Me.Controls.Add(Me.F4)
        Me.Controls.Add(Me.F3)
        Me.Controls.Add(Me.F2)
        Me.Controls.Add(Me.F1)
        Me.Controls.Add(Me.E10)
        Me.Controls.Add(Me.E9)
        Me.Controls.Add(Me.E8)
        Me.Controls.Add(Me.E7)
        Me.Controls.Add(Me.E6)
        Me.Controls.Add(Me.E5)
        Me.Controls.Add(Me.E4)
        Me.Controls.Add(Me.E3)
        Me.Controls.Add(Me.E2)
        Me.Controls.Add(Me.E1)
        Me.Controls.Add(Me.D10)
        Me.Controls.Add(Me.D9)
        Me.Controls.Add(Me.D8)
        Me.Controls.Add(Me.D7)
        Me.Controls.Add(Me.D6)
        Me.Controls.Add(Me.D5)
        Me.Controls.Add(Me.D4)
        Me.Controls.Add(Me.D3)
        Me.Controls.Add(Me.D2)
        Me.Controls.Add(Me.D1)
        Me.Controls.Add(Me.C10)
        Me.Controls.Add(Me.C9)
        Me.Controls.Add(Me.C8)
        Me.Controls.Add(Me.C7)
        Me.Controls.Add(Me.C6)
        Me.Controls.Add(Me.C5)
        Me.Controls.Add(Me.C4)
        Me.Controls.Add(Me.C3)
        Me.Controls.Add(Me.C2)
        Me.Controls.Add(Me.C1)
        Me.Controls.Add(Me.B10)
        Me.Controls.Add(Me.A10)
        Me.Controls.Add(Me.B9)
        Me.Controls.Add(Me.A9)
        Me.Controls.Add(Me.B8)
        Me.Controls.Add(Me.A8)
        Me.Controls.Add(Me.B7)
        Me.Controls.Add(Me.A7)
        Me.Controls.Add(Me.B6)
        Me.Controls.Add(Me.A6)
        Me.Controls.Add(Me.B5)
        Me.Controls.Add(Me.A5)
        Me.Controls.Add(Me.B4)
        Me.Controls.Add(Me.A4)
        Me.Controls.Add(Me.B3)
        Me.Controls.Add(Me.A3)
        Me.Controls.Add(Me.B2)
        Me.Controls.Add(Me.A2)
        Me.Controls.Add(Me.B1)
        Me.Controls.Add(Me.A1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnReserveSeat)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.LabelD)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label)
        Me.Controls.Add(Me.Labe)
        Me.Controls.Add(Me.Label2)
        Me.Name = "frmBoeing747_8"
        Me.Text = "Flight Seats"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCancel As Button
    Friend WithEvents btnReserveSeat As Button
    Friend WithEvents Labe As Label
    Friend WithEvents Label As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents LabelD As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents B10 As CheckBox
    Friend WithEvents A10 As CheckBox
    Friend WithEvents B9 As CheckBox
    Friend WithEvents A9 As CheckBox
    Friend WithEvents B8 As CheckBox
    Friend WithEvents A8 As CheckBox
    Friend WithEvents B7 As CheckBox
    Friend WithEvents A7 As CheckBox
    Friend WithEvents B6 As CheckBox
    Friend WithEvents A6 As CheckBox
    Friend WithEvents B5 As CheckBox
    Friend WithEvents A5 As CheckBox
    Friend WithEvents B4 As CheckBox
    Friend WithEvents A4 As CheckBox
    Friend WithEvents B3 As CheckBox
    Friend WithEvents A3 As CheckBox
    Friend WithEvents B2 As CheckBox
    Friend WithEvents A2 As CheckBox
    Friend WithEvents B1 As CheckBox
    Friend WithEvents A1 As CheckBox
    Friend WithEvents C10 As CheckBox
    Friend WithEvents C9 As CheckBox
    Friend WithEvents C8 As CheckBox
    Friend WithEvents C7 As CheckBox
    Friend WithEvents C6 As CheckBox
    Friend WithEvents C5 As CheckBox
    Friend WithEvents C4 As CheckBox
    Friend WithEvents C3 As CheckBox
    Friend WithEvents C2 As CheckBox
    Friend WithEvents C1 As CheckBox
    Friend WithEvents D10 As CheckBox
    Friend WithEvents D9 As CheckBox
    Friend WithEvents D8 As CheckBox
    Friend WithEvents D7 As CheckBox
    Friend WithEvents D6 As CheckBox
    Friend WithEvents D5 As CheckBox
    Friend WithEvents D4 As CheckBox
    Friend WithEvents D3 As CheckBox
    Friend WithEvents D2 As CheckBox
    Friend WithEvents D1 As CheckBox
    Friend WithEvents E10 As CheckBox
    Friend WithEvents E9 As CheckBox
    Friend WithEvents E8 As CheckBox
    Friend WithEvents E7 As CheckBox
    Friend WithEvents E6 As CheckBox
    Friend WithEvents E5 As CheckBox
    Friend WithEvents E4 As CheckBox
    Friend WithEvents E3 As CheckBox
    Friend WithEvents E2 As CheckBox
    Friend WithEvents E1 As CheckBox
    Friend WithEvents F10 As CheckBox
    Friend WithEvents F9 As CheckBox
    Friend WithEvents F8 As CheckBox
    Friend WithEvents F7 As CheckBox
    Friend WithEvents F6 As CheckBox
    Friend WithEvents F5 As CheckBox
    Friend WithEvents F4 As CheckBox
    Friend WithEvents F3 As CheckBox
    Friend WithEvents F2 As CheckBox
    Friend WithEvents F1 As CheckBox
End Class

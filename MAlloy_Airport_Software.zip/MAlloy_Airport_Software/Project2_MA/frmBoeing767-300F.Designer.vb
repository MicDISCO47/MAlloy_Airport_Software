﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmBoeing767_300F
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnCancel = New System.Windows.Forms.Button()
        Me.btnReserveSeat = New System.Windows.Forms.Button()
        Me.Labe = New System.Windows.Forms.Label()
        Me.Label = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.LabelD = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.C10 = New System.Windows.Forms.CheckBox()
        Me.C9 = New System.Windows.Forms.CheckBox()
        Me.C8 = New System.Windows.Forms.CheckBox()
        Me.C7 = New System.Windows.Forms.CheckBox()
        Me.C6 = New System.Windows.Forms.CheckBox()
        Me.C5 = New System.Windows.Forms.CheckBox()
        Me.C4 = New System.Windows.Forms.CheckBox()
        Me.C3 = New System.Windows.Forms.CheckBox()
        Me.C2 = New System.Windows.Forms.CheckBox()
        Me.C1 = New System.Windows.Forms.CheckBox()
        Me.B10 = New System.Windows.Forms.CheckBox()
        Me.A10 = New System.Windows.Forms.CheckBox()
        Me.B9 = New System.Windows.Forms.CheckBox()
        Me.A9 = New System.Windows.Forms.CheckBox()
        Me.B8 = New System.Windows.Forms.CheckBox()
        Me.A8 = New System.Windows.Forms.CheckBox()
        Me.B7 = New System.Windows.Forms.CheckBox()
        Me.A7 = New System.Windows.Forms.CheckBox()
        Me.B6 = New System.Windows.Forms.CheckBox()
        Me.A6 = New System.Windows.Forms.CheckBox()
        Me.B5 = New System.Windows.Forms.CheckBox()
        Me.A5 = New System.Windows.Forms.CheckBox()
        Me.B4 = New System.Windows.Forms.CheckBox()
        Me.A4 = New System.Windows.Forms.CheckBox()
        Me.B3 = New System.Windows.Forms.CheckBox()
        Me.A3 = New System.Windows.Forms.CheckBox()
        Me.B2 = New System.Windows.Forms.CheckBox()
        Me.A2 = New System.Windows.Forms.CheckBox()
        Me.B1 = New System.Windows.Forms.CheckBox()
        Me.A1 = New System.Windows.Forms.CheckBox()
        Me.F10 = New System.Windows.Forms.CheckBox()
        Me.F9 = New System.Windows.Forms.CheckBox()
        Me.F8 = New System.Windows.Forms.CheckBox()
        Me.F7 = New System.Windows.Forms.CheckBox()
        Me.F6 = New System.Windows.Forms.CheckBox()
        Me.F5 = New System.Windows.Forms.CheckBox()
        Me.F4 = New System.Windows.Forms.CheckBox()
        Me.F3 = New System.Windows.Forms.CheckBox()
        Me.F2 = New System.Windows.Forms.CheckBox()
        Me.F1 = New System.Windows.Forms.CheckBox()
        Me.E10 = New System.Windows.Forms.CheckBox()
        Me.E9 = New System.Windows.Forms.CheckBox()
        Me.E8 = New System.Windows.Forms.CheckBox()
        Me.E7 = New System.Windows.Forms.CheckBox()
        Me.E6 = New System.Windows.Forms.CheckBox()
        Me.E5 = New System.Windows.Forms.CheckBox()
        Me.E4 = New System.Windows.Forms.CheckBox()
        Me.E3 = New System.Windows.Forms.CheckBox()
        Me.E2 = New System.Windows.Forms.CheckBox()
        Me.E1 = New System.Windows.Forms.CheckBox()
        Me.D10 = New System.Windows.Forms.CheckBox()
        Me.D9 = New System.Windows.Forms.CheckBox()
        Me.D8 = New System.Windows.Forms.CheckBox()
        Me.D7 = New System.Windows.Forms.CheckBox()
        Me.D6 = New System.Windows.Forms.CheckBox()
        Me.D5 = New System.Windows.Forms.CheckBox()
        Me.D4 = New System.Windows.Forms.CheckBox()
        Me.D3 = New System.Windows.Forms.CheckBox()
        Me.D2 = New System.Windows.Forms.CheckBox()
        Me.D1 = New System.Windows.Forms.CheckBox()
        Me.I10 = New System.Windows.Forms.CheckBox()
        Me.I9 = New System.Windows.Forms.CheckBox()
        Me.I8 = New System.Windows.Forms.CheckBox()
        Me.I7 = New System.Windows.Forms.CheckBox()
        Me.I6 = New System.Windows.Forms.CheckBox()
        Me.I5 = New System.Windows.Forms.CheckBox()
        Me.I4 = New System.Windows.Forms.CheckBox()
        Me.I3 = New System.Windows.Forms.CheckBox()
        Me.I2 = New System.Windows.Forms.CheckBox()
        Me.I1 = New System.Windows.Forms.CheckBox()
        Me.H10 = New System.Windows.Forms.CheckBox()
        Me.H9 = New System.Windows.Forms.CheckBox()
        Me.H8 = New System.Windows.Forms.CheckBox()
        Me.H7 = New System.Windows.Forms.CheckBox()
        Me.H6 = New System.Windows.Forms.CheckBox()
        Me.H5 = New System.Windows.Forms.CheckBox()
        Me.H4 = New System.Windows.Forms.CheckBox()
        Me.H3 = New System.Windows.Forms.CheckBox()
        Me.H2 = New System.Windows.Forms.CheckBox()
        Me.H1 = New System.Windows.Forms.CheckBox()
        Me.G10 = New System.Windows.Forms.CheckBox()
        Me.G9 = New System.Windows.Forms.CheckBox()
        Me.G8 = New System.Windows.Forms.CheckBox()
        Me.G7 = New System.Windows.Forms.CheckBox()
        Me.G6 = New System.Windows.Forms.CheckBox()
        Me.G5 = New System.Windows.Forms.CheckBox()
        Me.G4 = New System.Windows.Forms.CheckBox()
        Me.G3 = New System.Windows.Forms.CheckBox()
        Me.G2 = New System.Windows.Forms.CheckBox()
        Me.G1 = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(322, 22)
        Me.Label2.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(28, 26)
        Me.Label2.TabIndex = 274
        Me.Label2.Text = "F"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(31, 22)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(28, 26)
        Me.Label1.TabIndex = 273
        Me.Label1.Text = "A"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnCancel
        '
        Me.btnCancel.Location = New System.Drawing.Point(294, 418)
        Me.btnCancel.Margin = New System.Windows.Forms.Padding(4)
        Me.btnCancel.Name = "btnCancel"
        Me.btnCancel.Size = New System.Drawing.Size(139, 70)
        Me.btnCancel.TabIndex = 272
        Me.btnCancel.Text = "Cancel"
        Me.btnCancel.UseVisualStyleBackColor = True
        '
        'btnReserveSeat
        '
        Me.btnReserveSeat.Location = New System.Drawing.Point(133, 418)
        Me.btnReserveSeat.Margin = New System.Windows.Forms.Padding(4)
        Me.btnReserveSeat.Name = "btnReserveSeat"
        Me.btnReserveSeat.Size = New System.Drawing.Size(139, 70)
        Me.btnReserveSeat.TabIndex = 271
        Me.btnReserveSeat.Text = "Reserve Seat"
        Me.btnReserveSeat.UseVisualStyleBackColor = True
        '
        'Labe
        '
        Me.Labe.Location = New System.Drawing.Point(83, 22)
        Me.Labe.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Labe.Name = "Labe"
        Me.Labe.Size = New System.Drawing.Size(28, 26)
        Me.Labe.TabIndex = 217
        Me.Labe.Text = "B"
        Me.Labe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label
        '
        Me.Label.Location = New System.Drawing.Point(130, 22)
        Me.Label.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label.Name = "Label"
        Me.Label.Size = New System.Drawing.Size(28, 26)
        Me.Label.TabIndex = 218
        Me.Label.Text = "C"
        Me.Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(222, 22)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(28, 26)
        Me.Label3.TabIndex = 219
        Me.Label3.Text = "D"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelD
        '
        Me.LabelD.Location = New System.Drawing.Point(274, 22)
        Me.LabelD.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LabelD.Name = "LabelD"
        Me.LabelD.Size = New System.Drawing.Size(28, 26)
        Me.LabelD.TabIndex = 220
        Me.LabelD.Text = "E"
        Me.LabelD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(172, 59)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(28, 26)
        Me.Label5.TabIndex = 221
        Me.Label5.Text = "1"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(172, 94)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(28, 26)
        Me.Label6.TabIndex = 222
        Me.Label6.Text = "2"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label15
        '
        Me.Label15.Location = New System.Drawing.Point(172, 340)
        Me.Label15.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(28, 26)
        Me.Label15.TabIndex = 229
        Me.Label15.Text = "9"
        Me.Label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(172, 129)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(28, 26)
        Me.Label7.TabIndex = 223
        Me.Label7.Text = "3"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label14
        '
        Me.Label14.Location = New System.Drawing.Point(172, 375)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(28, 26)
        Me.Label14.TabIndex = 228
        Me.Label14.Text = "10"
        Me.Label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(172, 164)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(28, 26)
        Me.Label8.TabIndex = 224
        Me.Label8.Text = "4"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(172, 202)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(28, 26)
        Me.Label9.TabIndex = 225
        Me.Label9.Text = "5"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label10
        '
        Me.Label10.Location = New System.Drawing.Point(172, 237)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(28, 26)
        Me.Label10.TabIndex = 226
        Me.Label10.Text = "6"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label16
        '
        Me.Label16.Location = New System.Drawing.Point(172, 306)
        Me.Label16.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(28, 26)
        Me.Label16.TabIndex = 230
        Me.Label16.Text = "8"
        Me.Label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(172, 271)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(28, 26)
        Me.Label11.TabIndex = 227
        Me.Label11.Text = "7"
        Me.Label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(523, 22)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(28, 26)
        Me.Label4.TabIndex = 317
        Me.Label4.Text = "I"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(415, 22)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(28, 26)
        Me.Label12.TabIndex = 295
        Me.Label12.Text = "G"
        Me.Label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label13
        '
        Me.Label13.Location = New System.Drawing.Point(468, 22)
        Me.Label13.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(28, 26)
        Me.Label13.TabIndex = 296
        Me.Label13.Text = "H"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label17
        '
        Me.Label17.Location = New System.Drawing.Point(373, 59)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(28, 26)
        Me.Label17.TabIndex = 297
        Me.Label17.Text = "1"
        Me.Label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label18
        '
        Me.Label18.Location = New System.Drawing.Point(373, 94)
        Me.Label18.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(28, 26)
        Me.Label18.TabIndex = 298
        Me.Label18.Text = "2"
        Me.Label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label19
        '
        Me.Label19.Location = New System.Drawing.Point(373, 340)
        Me.Label19.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(28, 26)
        Me.Label19.TabIndex = 305
        Me.Label19.Text = "9"
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label20
        '
        Me.Label20.Location = New System.Drawing.Point(373, 129)
        Me.Label20.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(28, 26)
        Me.Label20.TabIndex = 299
        Me.Label20.Text = "3"
        Me.Label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label21
        '
        Me.Label21.Location = New System.Drawing.Point(373, 375)
        Me.Label21.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(28, 26)
        Me.Label21.TabIndex = 304
        Me.Label21.Text = "10"
        Me.Label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label22
        '
        Me.Label22.Location = New System.Drawing.Point(373, 164)
        Me.Label22.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(28, 26)
        Me.Label22.TabIndex = 300
        Me.Label22.Text = "4"
        Me.Label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label23
        '
        Me.Label23.Location = New System.Drawing.Point(373, 202)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(28, 26)
        Me.Label23.TabIndex = 301
        Me.Label23.Text = "5"
        Me.Label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label24
        '
        Me.Label24.Location = New System.Drawing.Point(373, 237)
        Me.Label24.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(28, 26)
        Me.Label24.TabIndex = 302
        Me.Label24.Text = "6"
        Me.Label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label25
        '
        Me.Label25.Location = New System.Drawing.Point(373, 306)
        Me.Label25.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(28, 26)
        Me.Label25.TabIndex = 306
        Me.Label25.Text = "8"
        Me.Label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label26
        '
        Me.Label26.Location = New System.Drawing.Point(373, 271)
        Me.Label26.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(28, 26)
        Me.Label26.TabIndex = 303
        Me.Label26.Text = "7"
        Me.Label26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'C10
        '
        Me.C10.AutoSize = True
        Me.C10.Location = New System.Drawing.Point(133, 378)
        Me.C10.Name = "C10"
        Me.C10.Size = New System.Drawing.Size(18, 17)
        Me.C10.TabIndex = 347
        Me.C10.UseVisualStyleBackColor = True
        '
        'C9
        '
        Me.C9.AutoSize = True
        Me.C9.Location = New System.Drawing.Point(133, 344)
        Me.C9.Name = "C9"
        Me.C9.Size = New System.Drawing.Size(18, 17)
        Me.C9.TabIndex = 346
        Me.C9.UseVisualStyleBackColor = True
        '
        'C8
        '
        Me.C8.AutoSize = True
        Me.C8.Location = New System.Drawing.Point(133, 309)
        Me.C8.Name = "C8"
        Me.C8.Size = New System.Drawing.Size(18, 17)
        Me.C8.TabIndex = 345
        Me.C8.UseVisualStyleBackColor = True
        '
        'C7
        '
        Me.C7.AutoSize = True
        Me.C7.Location = New System.Drawing.Point(133, 275)
        Me.C7.Name = "C7"
        Me.C7.Size = New System.Drawing.Size(18, 17)
        Me.C7.TabIndex = 344
        Me.C7.UseVisualStyleBackColor = True
        '
        'C6
        '
        Me.C6.AutoSize = True
        Me.C6.Location = New System.Drawing.Point(133, 240)
        Me.C6.Name = "C6"
        Me.C6.Size = New System.Drawing.Size(18, 17)
        Me.C6.TabIndex = 343
        Me.C6.UseVisualStyleBackColor = True
        '
        'C5
        '
        Me.C5.AutoSize = True
        Me.C5.Location = New System.Drawing.Point(133, 206)
        Me.C5.Name = "C5"
        Me.C5.Size = New System.Drawing.Size(18, 17)
        Me.C5.TabIndex = 342
        Me.C5.UseVisualStyleBackColor = True
        '
        'C4
        '
        Me.C4.AutoSize = True
        Me.C4.Location = New System.Drawing.Point(133, 171)
        Me.C4.Name = "C4"
        Me.C4.Size = New System.Drawing.Size(18, 17)
        Me.C4.TabIndex = 341
        Me.C4.UseVisualStyleBackColor = True
        '
        'C3
        '
        Me.C3.AutoSize = True
        Me.C3.Location = New System.Drawing.Point(133, 137)
        Me.C3.Name = "C3"
        Me.C3.Size = New System.Drawing.Size(18, 17)
        Me.C3.TabIndex = 340
        Me.C3.UseVisualStyleBackColor = True
        '
        'C2
        '
        Me.C2.AutoSize = True
        Me.C2.Location = New System.Drawing.Point(133, 103)
        Me.C2.Name = "C2"
        Me.C2.Size = New System.Drawing.Size(18, 17)
        Me.C2.TabIndex = 339
        Me.C2.UseVisualStyleBackColor = True
        '
        'C1
        '
        Me.C1.AutoSize = True
        Me.C1.Location = New System.Drawing.Point(133, 68)
        Me.C1.Name = "C1"
        Me.C1.Size = New System.Drawing.Size(18, 17)
        Me.C1.TabIndex = 338
        Me.C1.UseVisualStyleBackColor = True
        '
        'B10
        '
        Me.B10.AutoSize = True
        Me.B10.Location = New System.Drawing.Point(86, 378)
        Me.B10.Name = "B10"
        Me.B10.Size = New System.Drawing.Size(18, 17)
        Me.B10.TabIndex = 337
        Me.B10.UseVisualStyleBackColor = True
        '
        'A10
        '
        Me.A10.AutoSize = True
        Me.A10.Location = New System.Drawing.Point(34, 378)
        Me.A10.Name = "A10"
        Me.A10.Size = New System.Drawing.Size(18, 17)
        Me.A10.TabIndex = 336
        Me.A10.UseVisualStyleBackColor = True
        '
        'B9
        '
        Me.B9.AutoSize = True
        Me.B9.Location = New System.Drawing.Point(86, 344)
        Me.B9.Name = "B9"
        Me.B9.Size = New System.Drawing.Size(18, 17)
        Me.B9.TabIndex = 335
        Me.B9.UseVisualStyleBackColor = True
        '
        'A9
        '
        Me.A9.AutoSize = True
        Me.A9.Location = New System.Drawing.Point(34, 344)
        Me.A9.Name = "A9"
        Me.A9.Size = New System.Drawing.Size(18, 17)
        Me.A9.TabIndex = 334
        Me.A9.UseVisualStyleBackColor = True
        '
        'B8
        '
        Me.B8.AutoSize = True
        Me.B8.Location = New System.Drawing.Point(86, 309)
        Me.B8.Name = "B8"
        Me.B8.Size = New System.Drawing.Size(18, 17)
        Me.B8.TabIndex = 333
        Me.B8.UseVisualStyleBackColor = True
        '
        'A8
        '
        Me.A8.AutoSize = True
        Me.A8.Location = New System.Drawing.Point(34, 309)
        Me.A8.Name = "A8"
        Me.A8.Size = New System.Drawing.Size(18, 17)
        Me.A8.TabIndex = 332
        Me.A8.UseVisualStyleBackColor = True
        '
        'B7
        '
        Me.B7.AutoSize = True
        Me.B7.Location = New System.Drawing.Point(86, 275)
        Me.B7.Name = "B7"
        Me.B7.Size = New System.Drawing.Size(18, 17)
        Me.B7.TabIndex = 331
        Me.B7.UseVisualStyleBackColor = True
        '
        'A7
        '
        Me.A7.AutoSize = True
        Me.A7.Location = New System.Drawing.Point(34, 275)
        Me.A7.Name = "A7"
        Me.A7.Size = New System.Drawing.Size(18, 17)
        Me.A7.TabIndex = 330
        Me.A7.UseVisualStyleBackColor = True
        '
        'B6
        '
        Me.B6.AutoSize = True
        Me.B6.Location = New System.Drawing.Point(86, 240)
        Me.B6.Name = "B6"
        Me.B6.Size = New System.Drawing.Size(18, 17)
        Me.B6.TabIndex = 329
        Me.B6.UseVisualStyleBackColor = True
        '
        'A6
        '
        Me.A6.AutoSize = True
        Me.A6.Location = New System.Drawing.Point(34, 240)
        Me.A6.Name = "A6"
        Me.A6.Size = New System.Drawing.Size(18, 17)
        Me.A6.TabIndex = 328
        Me.A6.UseVisualStyleBackColor = True
        '
        'B5
        '
        Me.B5.AutoSize = True
        Me.B5.Location = New System.Drawing.Point(86, 206)
        Me.B5.Name = "B5"
        Me.B5.Size = New System.Drawing.Size(18, 17)
        Me.B5.TabIndex = 327
        Me.B5.UseVisualStyleBackColor = True
        '
        'A5
        '
        Me.A5.AutoSize = True
        Me.A5.Location = New System.Drawing.Point(34, 206)
        Me.A5.Name = "A5"
        Me.A5.Size = New System.Drawing.Size(18, 17)
        Me.A5.TabIndex = 326
        Me.A5.UseVisualStyleBackColor = True
        '
        'B4
        '
        Me.B4.AutoSize = True
        Me.B4.Location = New System.Drawing.Point(86, 171)
        Me.B4.Name = "B4"
        Me.B4.Size = New System.Drawing.Size(18, 17)
        Me.B4.TabIndex = 325
        Me.B4.UseVisualStyleBackColor = True
        '
        'A4
        '
        Me.A4.AutoSize = True
        Me.A4.Location = New System.Drawing.Point(34, 171)
        Me.A4.Name = "A4"
        Me.A4.Size = New System.Drawing.Size(18, 17)
        Me.A4.TabIndex = 324
        Me.A4.UseVisualStyleBackColor = True
        '
        'B3
        '
        Me.B3.AutoSize = True
        Me.B3.Location = New System.Drawing.Point(86, 137)
        Me.B3.Name = "B3"
        Me.B3.Size = New System.Drawing.Size(18, 17)
        Me.B3.TabIndex = 323
        Me.B3.UseVisualStyleBackColor = True
        '
        'A3
        '
        Me.A3.AutoSize = True
        Me.A3.Location = New System.Drawing.Point(34, 137)
        Me.A3.Name = "A3"
        Me.A3.Size = New System.Drawing.Size(18, 17)
        Me.A3.TabIndex = 322
        Me.A3.UseVisualStyleBackColor = True
        '
        'B2
        '
        Me.B2.AutoSize = True
        Me.B2.Location = New System.Drawing.Point(86, 103)
        Me.B2.Name = "B2"
        Me.B2.Size = New System.Drawing.Size(18, 17)
        Me.B2.TabIndex = 321
        Me.B2.UseVisualStyleBackColor = True
        '
        'A2
        '
        Me.A2.AutoSize = True
        Me.A2.Location = New System.Drawing.Point(34, 103)
        Me.A2.Name = "A2"
        Me.A2.Size = New System.Drawing.Size(18, 17)
        Me.A2.TabIndex = 320
        Me.A2.UseVisualStyleBackColor = True
        '
        'B1
        '
        Me.B1.AutoSize = True
        Me.B1.Location = New System.Drawing.Point(86, 68)
        Me.B1.Name = "B1"
        Me.B1.Size = New System.Drawing.Size(18, 17)
        Me.B1.TabIndex = 319
        Me.B1.UseVisualStyleBackColor = True
        '
        'A1
        '
        Me.A1.AutoSize = True
        Me.A1.Location = New System.Drawing.Point(34, 68)
        Me.A1.Name = "A1"
        Me.A1.Size = New System.Drawing.Size(18, 17)
        Me.A1.TabIndex = 318
        Me.A1.UseVisualStyleBackColor = True
        '
        'F10
        '
        Me.F10.AutoSize = True
        Me.F10.Location = New System.Drawing.Point(332, 378)
        Me.F10.Name = "F10"
        Me.F10.Size = New System.Drawing.Size(18, 17)
        Me.F10.TabIndex = 377
        Me.F10.UseVisualStyleBackColor = True
        '
        'F9
        '
        Me.F9.AutoSize = True
        Me.F9.Location = New System.Drawing.Point(332, 344)
        Me.F9.Name = "F9"
        Me.F9.Size = New System.Drawing.Size(18, 17)
        Me.F9.TabIndex = 376
        Me.F9.UseVisualStyleBackColor = True
        '
        'F8
        '
        Me.F8.AutoSize = True
        Me.F8.Location = New System.Drawing.Point(332, 309)
        Me.F8.Name = "F8"
        Me.F8.Size = New System.Drawing.Size(18, 17)
        Me.F8.TabIndex = 375
        Me.F8.UseVisualStyleBackColor = True
        '
        'F7
        '
        Me.F7.AutoSize = True
        Me.F7.Location = New System.Drawing.Point(332, 275)
        Me.F7.Name = "F7"
        Me.F7.Size = New System.Drawing.Size(18, 17)
        Me.F7.TabIndex = 374
        Me.F7.UseVisualStyleBackColor = True
        '
        'F6
        '
        Me.F6.AutoSize = True
        Me.F6.Location = New System.Drawing.Point(332, 240)
        Me.F6.Name = "F6"
        Me.F6.Size = New System.Drawing.Size(18, 17)
        Me.F6.TabIndex = 373
        Me.F6.UseVisualStyleBackColor = True
        '
        'F5
        '
        Me.F5.AutoSize = True
        Me.F5.Location = New System.Drawing.Point(332, 206)
        Me.F5.Name = "F5"
        Me.F5.Size = New System.Drawing.Size(18, 17)
        Me.F5.TabIndex = 372
        Me.F5.UseVisualStyleBackColor = True
        '
        'F4
        '
        Me.F4.AutoSize = True
        Me.F4.Location = New System.Drawing.Point(332, 171)
        Me.F4.Name = "F4"
        Me.F4.Size = New System.Drawing.Size(18, 17)
        Me.F4.TabIndex = 371
        Me.F4.UseVisualStyleBackColor = True
        '
        'F3
        '
        Me.F3.AutoSize = True
        Me.F3.Location = New System.Drawing.Point(332, 137)
        Me.F3.Name = "F3"
        Me.F3.Size = New System.Drawing.Size(18, 17)
        Me.F3.TabIndex = 370
        Me.F3.UseVisualStyleBackColor = True
        '
        'F2
        '
        Me.F2.AutoSize = True
        Me.F2.Location = New System.Drawing.Point(332, 103)
        Me.F2.Name = "F2"
        Me.F2.Size = New System.Drawing.Size(18, 17)
        Me.F2.TabIndex = 369
        Me.F2.UseVisualStyleBackColor = True
        '
        'F1
        '
        Me.F1.AutoSize = True
        Me.F1.Location = New System.Drawing.Point(332, 68)
        Me.F1.Name = "F1"
        Me.F1.Size = New System.Drawing.Size(18, 17)
        Me.F1.TabIndex = 368
        Me.F1.UseVisualStyleBackColor = True
        '
        'E10
        '
        Me.E10.AutoSize = True
        Me.E10.Location = New System.Drawing.Point(277, 378)
        Me.E10.Name = "E10"
        Me.E10.Size = New System.Drawing.Size(18, 17)
        Me.E10.TabIndex = 367
        Me.E10.UseVisualStyleBackColor = True
        '
        'E9
        '
        Me.E9.AutoSize = True
        Me.E9.Location = New System.Drawing.Point(277, 344)
        Me.E9.Name = "E9"
        Me.E9.Size = New System.Drawing.Size(18, 17)
        Me.E9.TabIndex = 366
        Me.E9.UseVisualStyleBackColor = True
        '
        'E8
        '
        Me.E8.AutoSize = True
        Me.E8.Location = New System.Drawing.Point(277, 309)
        Me.E8.Name = "E8"
        Me.E8.Size = New System.Drawing.Size(18, 17)
        Me.E8.TabIndex = 365
        Me.E8.UseVisualStyleBackColor = True
        '
        'E7
        '
        Me.E7.AutoSize = True
        Me.E7.Location = New System.Drawing.Point(277, 275)
        Me.E7.Name = "E7"
        Me.E7.Size = New System.Drawing.Size(18, 17)
        Me.E7.TabIndex = 364
        Me.E7.UseVisualStyleBackColor = True
        '
        'E6
        '
        Me.E6.AutoSize = True
        Me.E6.Location = New System.Drawing.Point(277, 240)
        Me.E6.Name = "E6"
        Me.E6.Size = New System.Drawing.Size(18, 17)
        Me.E6.TabIndex = 363
        Me.E6.UseVisualStyleBackColor = True
        '
        'E5
        '
        Me.E5.AutoSize = True
        Me.E5.Location = New System.Drawing.Point(277, 206)
        Me.E5.Name = "E5"
        Me.E5.Size = New System.Drawing.Size(18, 17)
        Me.E5.TabIndex = 362
        Me.E5.UseVisualStyleBackColor = True
        '
        'E4
        '
        Me.E4.AutoSize = True
        Me.E4.Location = New System.Drawing.Point(277, 171)
        Me.E4.Name = "E4"
        Me.E4.Size = New System.Drawing.Size(18, 17)
        Me.E4.TabIndex = 361
        Me.E4.UseVisualStyleBackColor = True
        '
        'E3
        '
        Me.E3.AutoSize = True
        Me.E3.Location = New System.Drawing.Point(277, 137)
        Me.E3.Name = "E3"
        Me.E3.Size = New System.Drawing.Size(18, 17)
        Me.E3.TabIndex = 360
        Me.E3.UseVisualStyleBackColor = True
        '
        'E2
        '
        Me.E2.AutoSize = True
        Me.E2.Location = New System.Drawing.Point(277, 103)
        Me.E2.Name = "E2"
        Me.E2.Size = New System.Drawing.Size(18, 17)
        Me.E2.TabIndex = 359
        Me.E2.UseVisualStyleBackColor = True
        '
        'E1
        '
        Me.E1.AutoSize = True
        Me.E1.Location = New System.Drawing.Point(277, 68)
        Me.E1.Name = "E1"
        Me.E1.Size = New System.Drawing.Size(18, 17)
        Me.E1.TabIndex = 358
        Me.E1.UseVisualStyleBackColor = True
        '
        'D10
        '
        Me.D10.AutoSize = True
        Me.D10.Location = New System.Drawing.Point(224, 378)
        Me.D10.Name = "D10"
        Me.D10.Size = New System.Drawing.Size(18, 17)
        Me.D10.TabIndex = 357
        Me.D10.UseVisualStyleBackColor = True
        '
        'D9
        '
        Me.D9.AutoSize = True
        Me.D9.Location = New System.Drawing.Point(224, 344)
        Me.D9.Name = "D9"
        Me.D9.Size = New System.Drawing.Size(18, 17)
        Me.D9.TabIndex = 356
        Me.D9.UseVisualStyleBackColor = True
        '
        'D8
        '
        Me.D8.AutoSize = True
        Me.D8.Location = New System.Drawing.Point(224, 309)
        Me.D8.Name = "D8"
        Me.D8.Size = New System.Drawing.Size(18, 17)
        Me.D8.TabIndex = 355
        Me.D8.UseVisualStyleBackColor = True
        '
        'D7
        '
        Me.D7.AutoSize = True
        Me.D7.Location = New System.Drawing.Point(224, 275)
        Me.D7.Name = "D7"
        Me.D7.Size = New System.Drawing.Size(18, 17)
        Me.D7.TabIndex = 354
        Me.D7.UseVisualStyleBackColor = True
        '
        'D6
        '
        Me.D6.AutoSize = True
        Me.D6.Location = New System.Drawing.Point(224, 240)
        Me.D6.Name = "D6"
        Me.D6.Size = New System.Drawing.Size(18, 17)
        Me.D6.TabIndex = 353
        Me.D6.UseVisualStyleBackColor = True
        '
        'D5
        '
        Me.D5.AutoSize = True
        Me.D5.Location = New System.Drawing.Point(224, 206)
        Me.D5.Name = "D5"
        Me.D5.Size = New System.Drawing.Size(18, 17)
        Me.D5.TabIndex = 352
        Me.D5.UseVisualStyleBackColor = True
        '
        'D4
        '
        Me.D4.AutoSize = True
        Me.D4.Location = New System.Drawing.Point(224, 171)
        Me.D4.Name = "D4"
        Me.D4.Size = New System.Drawing.Size(18, 17)
        Me.D4.TabIndex = 351
        Me.D4.UseVisualStyleBackColor = True
        '
        'D3
        '
        Me.D3.AutoSize = True
        Me.D3.Location = New System.Drawing.Point(224, 137)
        Me.D3.Name = "D3"
        Me.D3.Size = New System.Drawing.Size(18, 17)
        Me.D3.TabIndex = 350
        Me.D3.UseVisualStyleBackColor = True
        '
        'D2
        '
        Me.D2.AutoSize = True
        Me.D2.Location = New System.Drawing.Point(224, 103)
        Me.D2.Name = "D2"
        Me.D2.Size = New System.Drawing.Size(18, 17)
        Me.D2.TabIndex = 349
        Me.D2.UseVisualStyleBackColor = True
        '
        'D1
        '
        Me.D1.AutoSize = True
        Me.D1.Location = New System.Drawing.Point(224, 68)
        Me.D1.Name = "D1"
        Me.D1.Size = New System.Drawing.Size(18, 17)
        Me.D1.TabIndex = 348
        Me.D1.UseVisualStyleBackColor = True
        '
        'I10
        '
        Me.I10.AutoSize = True
        Me.I10.Location = New System.Drawing.Point(533, 378)
        Me.I10.Name = "I10"
        Me.I10.Size = New System.Drawing.Size(18, 17)
        Me.I10.TabIndex = 407
        Me.I10.UseVisualStyleBackColor = True
        '
        'I9
        '
        Me.I9.AutoSize = True
        Me.I9.Location = New System.Drawing.Point(533, 344)
        Me.I9.Name = "I9"
        Me.I9.Size = New System.Drawing.Size(18, 17)
        Me.I9.TabIndex = 406
        Me.I9.UseVisualStyleBackColor = True
        '
        'I8
        '
        Me.I8.AutoSize = True
        Me.I8.Location = New System.Drawing.Point(533, 309)
        Me.I8.Name = "I8"
        Me.I8.Size = New System.Drawing.Size(18, 17)
        Me.I8.TabIndex = 405
        Me.I8.UseVisualStyleBackColor = True
        '
        'I7
        '
        Me.I7.AutoSize = True
        Me.I7.Location = New System.Drawing.Point(533, 275)
        Me.I7.Name = "I7"
        Me.I7.Size = New System.Drawing.Size(18, 17)
        Me.I7.TabIndex = 404
        Me.I7.UseVisualStyleBackColor = True
        '
        'I6
        '
        Me.I6.AutoSize = True
        Me.I6.Location = New System.Drawing.Point(533, 240)
        Me.I6.Name = "I6"
        Me.I6.Size = New System.Drawing.Size(18, 17)
        Me.I6.TabIndex = 403
        Me.I6.UseVisualStyleBackColor = True
        '
        'I5
        '
        Me.I5.AutoSize = True
        Me.I5.Location = New System.Drawing.Point(533, 206)
        Me.I5.Name = "I5"
        Me.I5.Size = New System.Drawing.Size(18, 17)
        Me.I5.TabIndex = 402
        Me.I5.UseVisualStyleBackColor = True
        '
        'I4
        '
        Me.I4.AutoSize = True
        Me.I4.Location = New System.Drawing.Point(533, 171)
        Me.I4.Name = "I4"
        Me.I4.Size = New System.Drawing.Size(18, 17)
        Me.I4.TabIndex = 401
        Me.I4.UseVisualStyleBackColor = True
        '
        'I3
        '
        Me.I3.AutoSize = True
        Me.I3.Location = New System.Drawing.Point(533, 137)
        Me.I3.Name = "I3"
        Me.I3.Size = New System.Drawing.Size(18, 17)
        Me.I3.TabIndex = 400
        Me.I3.UseVisualStyleBackColor = True
        '
        'I2
        '
        Me.I2.AutoSize = True
        Me.I2.Location = New System.Drawing.Point(533, 103)
        Me.I2.Name = "I2"
        Me.I2.Size = New System.Drawing.Size(18, 17)
        Me.I2.TabIndex = 399
        Me.I2.UseVisualStyleBackColor = True
        '
        'I1
        '
        Me.I1.AutoSize = True
        Me.I1.Location = New System.Drawing.Point(533, 68)
        Me.I1.Name = "I1"
        Me.I1.Size = New System.Drawing.Size(18, 17)
        Me.I1.TabIndex = 398
        Me.I1.UseVisualStyleBackColor = True
        '
        'H10
        '
        Me.H10.AutoSize = True
        Me.H10.Location = New System.Drawing.Point(478, 378)
        Me.H10.Name = "H10"
        Me.H10.Size = New System.Drawing.Size(18, 17)
        Me.H10.TabIndex = 397
        Me.H10.UseVisualStyleBackColor = True
        '
        'H9
        '
        Me.H9.AutoSize = True
        Me.H9.Location = New System.Drawing.Point(478, 344)
        Me.H9.Name = "H9"
        Me.H9.Size = New System.Drawing.Size(18, 17)
        Me.H9.TabIndex = 396
        Me.H9.UseVisualStyleBackColor = True
        '
        'H8
        '
        Me.H8.AutoSize = True
        Me.H8.Location = New System.Drawing.Point(478, 309)
        Me.H8.Name = "H8"
        Me.H8.Size = New System.Drawing.Size(18, 17)
        Me.H8.TabIndex = 395
        Me.H8.UseVisualStyleBackColor = True
        '
        'H7
        '
        Me.H7.AutoSize = True
        Me.H7.Location = New System.Drawing.Point(478, 275)
        Me.H7.Name = "H7"
        Me.H7.Size = New System.Drawing.Size(18, 17)
        Me.H7.TabIndex = 394
        Me.H7.UseVisualStyleBackColor = True
        '
        'H6
        '
        Me.H6.AutoSize = True
        Me.H6.Location = New System.Drawing.Point(478, 240)
        Me.H6.Name = "H6"
        Me.H6.Size = New System.Drawing.Size(18, 17)
        Me.H6.TabIndex = 393
        Me.H6.UseVisualStyleBackColor = True
        '
        'H5
        '
        Me.H5.AutoSize = True
        Me.H5.Location = New System.Drawing.Point(478, 206)
        Me.H5.Name = "H5"
        Me.H5.Size = New System.Drawing.Size(18, 17)
        Me.H5.TabIndex = 392
        Me.H5.UseVisualStyleBackColor = True
        '
        'H4
        '
        Me.H4.AutoSize = True
        Me.H4.Location = New System.Drawing.Point(478, 171)
        Me.H4.Name = "H4"
        Me.H4.Size = New System.Drawing.Size(18, 17)
        Me.H4.TabIndex = 391
        Me.H4.UseVisualStyleBackColor = True
        '
        'H3
        '
        Me.H3.AutoSize = True
        Me.H3.Location = New System.Drawing.Point(478, 137)
        Me.H3.Name = "H3"
        Me.H3.Size = New System.Drawing.Size(18, 17)
        Me.H3.TabIndex = 390
        Me.H3.UseVisualStyleBackColor = True
        '
        'H2
        '
        Me.H2.AutoSize = True
        Me.H2.Location = New System.Drawing.Point(478, 103)
        Me.H2.Name = "H2"
        Me.H2.Size = New System.Drawing.Size(18, 17)
        Me.H2.TabIndex = 389
        Me.H2.UseVisualStyleBackColor = True
        '
        'H1
        '
        Me.H1.AutoSize = True
        Me.H1.Location = New System.Drawing.Point(478, 68)
        Me.H1.Name = "H1"
        Me.H1.Size = New System.Drawing.Size(18, 17)
        Me.H1.TabIndex = 388
        Me.H1.UseVisualStyleBackColor = True
        '
        'G10
        '
        Me.G10.AutoSize = True
        Me.G10.Location = New System.Drawing.Point(425, 378)
        Me.G10.Name = "G10"
        Me.G10.Size = New System.Drawing.Size(18, 17)
        Me.G10.TabIndex = 387
        Me.G10.UseVisualStyleBackColor = True
        '
        'G9
        '
        Me.G9.AutoSize = True
        Me.G9.Location = New System.Drawing.Point(425, 344)
        Me.G9.Name = "G9"
        Me.G9.Size = New System.Drawing.Size(18, 17)
        Me.G9.TabIndex = 386
        Me.G9.UseVisualStyleBackColor = True
        '
        'G8
        '
        Me.G8.AutoSize = True
        Me.G8.Location = New System.Drawing.Point(425, 309)
        Me.G8.Name = "G8"
        Me.G8.Size = New System.Drawing.Size(18, 17)
        Me.G8.TabIndex = 385
        Me.G8.UseVisualStyleBackColor = True
        '
        'G7
        '
        Me.G7.AutoSize = True
        Me.G7.Location = New System.Drawing.Point(425, 275)
        Me.G7.Name = "G7"
        Me.G7.Size = New System.Drawing.Size(18, 17)
        Me.G7.TabIndex = 384
        Me.G7.UseVisualStyleBackColor = True
        '
        'G6
        '
        Me.G6.AutoSize = True
        Me.G6.Location = New System.Drawing.Point(425, 240)
        Me.G6.Name = "G6"
        Me.G6.Size = New System.Drawing.Size(18, 17)
        Me.G6.TabIndex = 383
        Me.G6.UseVisualStyleBackColor = True
        '
        'G5
        '
        Me.G5.AutoSize = True
        Me.G5.Location = New System.Drawing.Point(425, 206)
        Me.G5.Name = "G5"
        Me.G5.Size = New System.Drawing.Size(18, 17)
        Me.G5.TabIndex = 382
        Me.G5.UseVisualStyleBackColor = True
        '
        'G4
        '
        Me.G4.AutoSize = True
        Me.G4.Location = New System.Drawing.Point(425, 171)
        Me.G4.Name = "G4"
        Me.G4.Size = New System.Drawing.Size(18, 17)
        Me.G4.TabIndex = 381
        Me.G4.UseVisualStyleBackColor = True
        '
        'G3
        '
        Me.G3.AutoSize = True
        Me.G3.Location = New System.Drawing.Point(425, 137)
        Me.G3.Name = "G3"
        Me.G3.Size = New System.Drawing.Size(18, 17)
        Me.G3.TabIndex = 380
        Me.G3.UseVisualStyleBackColor = True
        '
        'G2
        '
        Me.G2.AutoSize = True
        Me.G2.Location = New System.Drawing.Point(425, 103)
        Me.G2.Name = "G2"
        Me.G2.Size = New System.Drawing.Size(18, 17)
        Me.G2.TabIndex = 379
        Me.G2.UseVisualStyleBackColor = True
        '
        'G1
        '
        Me.G1.AutoSize = True
        Me.G1.Location = New System.Drawing.Point(425, 68)
        Me.G1.Name = "G1"
        Me.G1.Size = New System.Drawing.Size(18, 17)
        Me.G1.TabIndex = 378
        Me.G1.UseVisualStyleBackColor = True
        '
        'frmBoeing767_300F
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(581, 501)
        Me.Controls.Add(Me.I10)
        Me.Controls.Add(Me.I9)
        Me.Controls.Add(Me.I8)
        Me.Controls.Add(Me.I7)
        Me.Controls.Add(Me.I6)
        Me.Controls.Add(Me.I5)
        Me.Controls.Add(Me.I4)
        Me.Controls.Add(Me.I3)
        Me.Controls.Add(Me.I2)
        Me.Controls.Add(Me.I1)
        Me.Controls.Add(Me.H10)
        Me.Controls.Add(Me.H9)
        Me.Controls.Add(Me.H8)
        Me.Controls.Add(Me.H7)
        Me.Controls.Add(Me.H6)
        Me.Controls.Add(Me.H5)
        Me.Controls.Add(Me.H4)
        Me.Controls.Add(Me.H3)
        Me.Controls.Add(Me.H2)
        Me.Controls.Add(Me.H1)
        Me.Controls.Add(Me.G10)
        Me.Controls.Add(Me.G9)
        Me.Controls.Add(Me.G8)
        Me.Controls.Add(Me.G7)
        Me.Controls.Add(Me.G6)
        Me.Controls.Add(Me.G5)
        Me.Controls.Add(Me.G4)
        Me.Controls.Add(Me.G3)
        Me.Controls.Add(Me.G2)
        Me.Controls.Add(Me.G1)
        Me.Controls.Add(Me.F10)
        Me.Controls.Add(Me.F9)
        Me.Controls.Add(Me.F8)
        Me.Controls.Add(Me.F7)
        Me.Controls.Add(Me.F6)
        Me.Controls.Add(Me.F5)
        Me.Controls.Add(Me.F4)
        Me.Controls.Add(Me.F3)
        Me.Controls.Add(Me.F2)
        Me.Controls.Add(Me.F1)
        Me.Controls.Add(Me.E10)
        Me.Controls.Add(Me.E9)
        Me.Controls.Add(Me.E8)
        Me.Controls.Add(Me.E7)
        Me.Controls.Add(Me.E6)
        Me.Controls.Add(Me.E5)
        Me.Controls.Add(Me.E4)
        Me.Controls.Add(Me.E3)
        Me.Controls.Add(Me.E2)
        Me.Controls.Add(Me.E1)
        Me.Controls.Add(Me.D10)
        Me.Controls.Add(Me.D9)
        Me.Controls.Add(Me.D8)
        Me.Controls.Add(Me.D7)
        Me.Controls.Add(Me.D6)
        Me.Controls.Add(Me.D5)
        Me.Controls.Add(Me.D4)
        Me.Controls.Add(Me.D3)
        Me.Controls.Add(Me.D2)
        Me.Controls.Add(Me.D1)
        Me.Controls.Add(Me.C10)
        Me.Controls.Add(Me.C9)
        Me.Controls.Add(Me.C8)
        Me.Controls.Add(Me.C7)
        Me.Controls.Add(Me.C6)
        Me.Controls.Add(Me.C5)
        Me.Controls.Add(Me.C4)
        Me.Controls.Add(Me.C3)
        Me.Controls.Add(Me.C2)
        Me.Controls.Add(Me.C1)
        Me.Controls.Add(Me.B10)
        Me.Controls.Add(Me.A10)
        Me.Controls.Add(Me.B9)
        Me.Controls.Add(Me.A9)
        Me.Controls.Add(Me.B8)
        Me.Controls.Add(Me.A8)
        Me.Controls.Add(Me.B7)
        Me.Controls.Add(Me.A7)
        Me.Controls.Add(Me.B6)
        Me.Controls.Add(Me.A6)
        Me.Controls.Add(Me.B5)
        Me.Controls.Add(Me.A5)
        Me.Controls.Add(Me.B4)
        Me.Controls.Add(Me.A4)
        Me.Controls.Add(Me.B3)
        Me.Controls.Add(Me.A3)
        Me.Controls.Add(Me.B2)
        Me.Controls.Add(Me.A2)
        Me.Controls.Add(Me.B1)
        Me.Controls.Add(Me.A1)
        Me.Controls.Add(Me.btnCancel)
        Me.Controls.Add(Me.btnReserveSeat)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label25)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Labe)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Label)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.LabelD)
        Me.Name = "frmBoeing767_300F"
        Me.Text = "Flight Seats"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btnCancel As Button
    Friend WithEvents btnReserveSeat As Button
    Friend WithEvents Labe As Label
    Friend WithEvents Label As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents LabelD As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label16 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents Label22 As Label
    Friend WithEvents Label23 As Label
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label26 As Label
    Friend WithEvents C10 As CheckBox
    Friend WithEvents C9 As CheckBox
    Friend WithEvents C8 As CheckBox
    Friend WithEvents C7 As CheckBox
    Friend WithEvents C6 As CheckBox
    Friend WithEvents C5 As CheckBox
    Friend WithEvents C4 As CheckBox
    Friend WithEvents C3 As CheckBox
    Friend WithEvents C2 As CheckBox
    Friend WithEvents C1 As CheckBox
    Friend WithEvents B10 As CheckBox
    Friend WithEvents A10 As CheckBox
    Friend WithEvents B9 As CheckBox
    Friend WithEvents A9 As CheckBox
    Friend WithEvents B8 As CheckBox
    Friend WithEvents A8 As CheckBox
    Friend WithEvents B7 As CheckBox
    Friend WithEvents A7 As CheckBox
    Friend WithEvents B6 As CheckBox
    Friend WithEvents A6 As CheckBox
    Friend WithEvents B5 As CheckBox
    Friend WithEvents A5 As CheckBox
    Friend WithEvents B4 As CheckBox
    Friend WithEvents A4 As CheckBox
    Friend WithEvents B3 As CheckBox
    Friend WithEvents A3 As CheckBox
    Friend WithEvents B2 As CheckBox
    Friend WithEvents A2 As CheckBox
    Friend WithEvents B1 As CheckBox
    Friend WithEvents A1 As CheckBox
    Friend WithEvents F10 As CheckBox
    Friend WithEvents F9 As CheckBox
    Friend WithEvents F8 As CheckBox
    Friend WithEvents F7 As CheckBox
    Friend WithEvents F6 As CheckBox
    Friend WithEvents F5 As CheckBox
    Friend WithEvents F4 As CheckBox
    Friend WithEvents F3 As CheckBox
    Friend WithEvents F2 As CheckBox
    Friend WithEvents F1 As CheckBox
    Friend WithEvents E10 As CheckBox
    Friend WithEvents E9 As CheckBox
    Friend WithEvents E8 As CheckBox
    Friend WithEvents E7 As CheckBox
    Friend WithEvents E6 As CheckBox
    Friend WithEvents E5 As CheckBox
    Friend WithEvents E4 As CheckBox
    Friend WithEvents E3 As CheckBox
    Friend WithEvents E2 As CheckBox
    Friend WithEvents E1 As CheckBox
    Friend WithEvents D10 As CheckBox
    Friend WithEvents D9 As CheckBox
    Friend WithEvents D8 As CheckBox
    Friend WithEvents D7 As CheckBox
    Friend WithEvents D6 As CheckBox
    Friend WithEvents D5 As CheckBox
    Friend WithEvents D4 As CheckBox
    Friend WithEvents D3 As CheckBox
    Friend WithEvents D2 As CheckBox
    Friend WithEvents D1 As CheckBox
    Friend WithEvents I10 As CheckBox
    Friend WithEvents I9 As CheckBox
    Friend WithEvents I8 As CheckBox
    Friend WithEvents I7 As CheckBox
    Friend WithEvents I6 As CheckBox
    Friend WithEvents I5 As CheckBox
    Friend WithEvents I4 As CheckBox
    Friend WithEvents I3 As CheckBox
    Friend WithEvents I2 As CheckBox
    Friend WithEvents I1 As CheckBox
    Friend WithEvents H10 As CheckBox
    Friend WithEvents H9 As CheckBox
    Friend WithEvents H8 As CheckBox
    Friend WithEvents H7 As CheckBox
    Friend WithEvents H6 As CheckBox
    Friend WithEvents H5 As CheckBox
    Friend WithEvents H4 As CheckBox
    Friend WithEvents H3 As CheckBox
    Friend WithEvents H2 As CheckBox
    Friend WithEvents H1 As CheckBox
    Friend WithEvents G10 As CheckBox
    Friend WithEvents G9 As CheckBox
    Friend WithEvents G8 As CheckBox
    Friend WithEvents G7 As CheckBox
    Friend WithEvents G6 As CheckBox
    Friend WithEvents G5 As CheckBox
    Friend WithEvents G4 As CheckBox
    Friend WithEvents G3 As CheckBox
    Friend WithEvents G2 As CheckBox
    Friend WithEvents G1 As CheckBox
End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmManagePilots
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnAddPilotToFlight = New System.Windows.Forms.Button()
        Me.btnDeletePilot = New System.Windows.Forms.Button()
        Me.btnAddPilot = New System.Windows.Forms.Button()
        Me.btnUpdatePilot = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(116, 136)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(92, 50)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnAddPilotToFlight
        '
        Me.btnAddPilotToFlight.Location = New System.Drawing.Point(196, 11)
        Me.btnAddPilotToFlight.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnAddPilotToFlight.Name = "btnAddPilotToFlight"
        Me.btnAddPilotToFlight.Size = New System.Drawing.Size(92, 50)
        Me.btnAddPilotToFlight.TabIndex = 6
        Me.btnAddPilotToFlight.Text = "Add Pilot to Flight"
        Me.btnAddPilotToFlight.UseVisualStyleBackColor = True
        '
        'btnDeletePilot
        '
        Me.btnDeletePilot.Location = New System.Drawing.Point(196, 82)
        Me.btnDeletePilot.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnDeletePilot.Name = "btnDeletePilot"
        Me.btnDeletePilot.Size = New System.Drawing.Size(92, 50)
        Me.btnDeletePilot.TabIndex = 5
        Me.btnDeletePilot.Text = "Delete Pilot"
        Me.btnDeletePilot.UseVisualStyleBackColor = True
        '
        'btnAddPilot
        '
        Me.btnAddPilot.Location = New System.Drawing.Point(66, 10)
        Me.btnAddPilot.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnAddPilot.Name = "btnAddPilot"
        Me.btnAddPilot.Size = New System.Drawing.Size(92, 50)
        Me.btnAddPilot.TabIndex = 4
        Me.btnAddPilot.Text = "Add Pilot"
        Me.btnAddPilot.UseVisualStyleBackColor = True
        '
        'btnUpdatePilot
        '
        Me.btnUpdatePilot.Location = New System.Drawing.Point(66, 82)
        Me.btnUpdatePilot.Margin = New System.Windows.Forms.Padding(2)
        Me.btnUpdatePilot.Name = "btnUpdatePilot"
        Me.btnUpdatePilot.Size = New System.Drawing.Size(92, 50)
        Me.btnUpdatePilot.TabIndex = 8
        Me.btnUpdatePilot.Text = "Update Pilot"
        Me.btnUpdatePilot.UseVisualStyleBackColor = True
        '
        'frmManagePilots
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(340, 197)
        Me.Controls.Add(Me.btnUpdatePilot)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnAddPilotToFlight)
        Me.Controls.Add(Me.btnDeletePilot)
        Me.Controls.Add(Me.btnAddPilot)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "frmManagePilots"
        Me.Text = "Manage Pilots"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents btnAddPilotToFlight As Button
    Friend WithEvents btnDeletePilot As Button
    Friend WithEvents btnAddPilot As Button
    Friend WithEvents btnUpdatePilot As Button
End Class

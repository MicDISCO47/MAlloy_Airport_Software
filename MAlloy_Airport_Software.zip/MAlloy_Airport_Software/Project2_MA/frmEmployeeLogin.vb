﻿Public Class frmEmployeeLogin
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub

    Private Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim strSelect As String
        Dim cmdSelect As OleDb.OleDbCommand
        Dim drSourceTable As OleDb.OleDbDataReader
        Dim blnGotEmployee As Boolean

        Dim strUserID = txtUserID.Text
        Dim strPassword = txtPassword.Text

        Try
            ' open the DB
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            strSelect = "Select * " &
                            "From TEmployees "

            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader

            While drSourceTable.Read()
                If drSourceTable("strEmployeeLoginID") = txtUserID.Text.Trim Then
                    If drSourceTable("strEmployeePassword") = txtPassword.Text.Trim Then
                        blnGotEmployee = True
                        strCurrentUser = drSourceTable("intEmployeeID")
                        If drSourceTable("intEmployeeRoleID") = 1 Then
                            Dim frmPilotMainMenu As New frmPilotMainMenu
                            frmPilotMainMenu.ShowDialog()
                        ElseIf drSourceTable("intEmployeeRoleID") = 2 Then
                            Dim frmAttendantMainMenu As New frmAttendantMainMenu
                            frmAttendantMainMenu.ShowDialog()
                        ElseIf drSourceTable("intEmployeeRoleID") = 3 Then
                            Dim frmAdminMainMenu As New frmAdminMainMenu
                            frmAdminMainMenu.ShowDialog()
                        End If
                    End If
                End If
            End While

            If blnGotEmployee = False Then
                MessageBox.Show("Invalid UserID or Password.")
            End If

            ' Clean up
            drSourceTable.Close()

            ' close the database connection
            CloseDatabaseConnection()

        Catch ex As Exception

            ' Log and display error message
            MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class
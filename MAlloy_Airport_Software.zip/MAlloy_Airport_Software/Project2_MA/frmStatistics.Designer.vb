﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmStatistics
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lstPilotMiles = New System.Windows.Forms.ListBox()
        Me.lstAttendantMiles = New System.Windows.Forms.ListBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblTotalCustomers = New System.Windows.Forms.Label()
        Me.lblTotalPassengerFlights = New System.Windows.Forms.Label()
        Me.lblAveragePassengerMiles = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(42, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(241, 23)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Total Number of Passengers"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(42, 78)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(231, 23)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Total Passengers Flights"
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(42, 117)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(296, 23)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Average Miles Flown for All Passengers"
        '
        'lstPilotMiles
        '
        Me.lstPilotMiles.FormattingEnabled = True
        Me.lstPilotMiles.ItemHeight = 16
        Me.lstPilotMiles.Location = New System.Drawing.Point(45, 212)
        Me.lstPilotMiles.Name = "lstPilotMiles"
        Me.lstPilotMiles.Size = New System.Drawing.Size(238, 308)
        Me.lstPilotMiles.TabIndex = 3
        '
        'lstAttendantMiles
        '
        Me.lstAttendantMiles.FormattingEnabled = True
        Me.lstAttendantMiles.ItemHeight = 16
        Me.lstAttendantMiles.Location = New System.Drawing.Point(289, 212)
        Me.lstAttendantMiles.Name = "lstAttendantMiles"
        Me.lstAttendantMiles.Size = New System.Drawing.Size(238, 308)
        Me.lstAttendantMiles.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(42, 176)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(241, 23)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Pilot Miles Flown"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(286, 176)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(241, 23)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Attendant Miles Flown"
        '
        'lblTotalCustomers
        '
        Me.lblTotalCustomers.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalCustomers.Location = New System.Drawing.Point(344, 33)
        Me.lblTotalCustomers.Name = "lblTotalCustomers"
        Me.lblTotalCustomers.Size = New System.Drawing.Size(183, 23)
        Me.lblTotalCustomers.TabIndex = 7
        '
        'lblTotalPassengerFlights
        '
        Me.lblTotalPassengerFlights.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalPassengerFlights.Location = New System.Drawing.Point(344, 78)
        Me.lblTotalPassengerFlights.Name = "lblTotalPassengerFlights"
        Me.lblTotalPassengerFlights.Size = New System.Drawing.Size(183, 23)
        Me.lblTotalPassengerFlights.TabIndex = 8
        '
        'lblAveragePassengerMiles
        '
        Me.lblAveragePassengerMiles.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAveragePassengerMiles.Location = New System.Drawing.Point(344, 117)
        Me.lblAveragePassengerMiles.Name = "lblAveragePassengerMiles"
        Me.lblAveragePassengerMiles.Size = New System.Drawing.Size(183, 23)
        Me.lblAveragePassengerMiles.TabIndex = 9
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(188, 543)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(150, 59)
        Me.btnExit.TabIndex = 10
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'frmStatistics
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(567, 614)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.lblAveragePassengerMiles)
        Me.Controls.Add(Me.lblTotalPassengerFlights)
        Me.Controls.Add(Me.lblTotalCustomers)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.lstAttendantMiles)
        Me.Controls.Add(Me.lstPilotMiles)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "frmStatistics"
        Me.Text = "Statistics"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lstPilotMiles As ListBox
    Friend WithEvents lstAttendantMiles As ListBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblTotalCustomers As Label
    Friend WithEvents lblTotalPassengerFlights As Label
    Friend WithEvents lblAveragePassengerMiles As Label
    Friend WithEvents btnExit As Button
End Class

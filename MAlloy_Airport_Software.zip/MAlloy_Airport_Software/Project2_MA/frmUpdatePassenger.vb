﻿Public Class frmUpdatePassenger
    Private Sub frmUpdatePassenger_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Try

            Dim strSelect As String = ""
            Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement
            Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to
            Dim dts As DataTable = New DataTable ' this is the table we will load from our reader for State
            Dim dtp As DataTable = New DataTable 'this it the table we will load from our reader for Passengers

            ' open the DB
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            ' Build the select statement to obtain States
            strSelect = "SELECT * From TStates"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            dts.Load(drSourceTable)

            'load the States result set into the combobox.  For VB, we do this by binding the data to the combobox

            cboState.ValueMember = "intStateID"
            cboState.DisplayMember = "strState"
            cboState.DataSource = dts

            'Passenger select statement
            strSelect = "Select * From TPassengers " &
                "Where intPassengerID = " & strCurrentUser

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader


            drSourceTable.Read()
            txtFirstName.Text = drSourceTable("strFirstName")
            txtLastName.Text = drSourceTable("strLastName")
            txtAddress.Text = drSourceTable("strAddress")
            txtCity.Text = drSourceTable("strCity")
            cboState.SelectedValue = drSourceTable("intStateID")
            txtZipCode.Text = drSourceTable("strZip")
            txtPhoneNumber.Text = drSourceTable("strPhoneNumber")
            txtEmail.Text = drSourceTable("strEmail")
            txtUserID.Text = drSourceTable("strPassengerUserID")
            txtPassword.Text = drSourceTable("strPassengerPassword")
            dtpDateofBirth.Value = drSourceTable("dtmDateofBirth")

            ' close the database connection
            CloseDatabaseConnection()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Dim strFirstName As String
        Dim strLastName As String
        Dim strAddress As String
        Dim strCity As String
        Dim intState As Integer
        Dim strZipCode As String
        Dim strPhoneNumber As String
        Dim strEmail As String
        Dim strUserID As String
        Dim strPassword As String
        Dim strDateofBirth As String

        Dim blnValidated As Boolean

        Dim cmdUpdatePassenger As New OleDb.OleDbCommand
        Dim intRowsAffected As Integer  ' how many rows were affected when sql executed

        ' validate data is entered
        blnValidated = True
        Get_And_Validate_Inputs(strFirstName, strLastName, strAddress, strCity, intState, strZipCode, strPhoneNumber, strEmail, strUserID, strPassword, strDateofBirth, blnValidated)

        If blnValidated = True Then
            Try
                If OpenDatabaseConnectionSQLServer() = False Then

                    ' No, warn the user ...
                    MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                        "The application will now close.",
                                        Me.Text + " Error",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error)

                    ' and close the form/application
                    Me.Close()

                End If

                cmdUpdatePassenger.CommandText = "EXECUTE uspUpdatePassenger '" & strCurrentUser & "', '" & strFirstName & "', '" & strLastName & "', '" & strAddress & "', '" & strCity & "', '" & intState & "', '" & strZipCode & "', '" & strPhoneNumber & "', '" & strEmail & "', '" & strUserID & "', '" & strPassword & "', '" & strDateofBirth & "' "
                cmdUpdatePassenger.CommandType = CommandType.StoredProcedure

                cmdUpdatePassenger = New OleDb.OleDbCommand(cmdUpdatePassenger.CommandText, m_conAdministrator)

                ' IUpdate the row with execute the statement
                intRowsAffected = cmdUpdatePassenger.ExecuteNonQuery()

                ' have to let the user know what happened 
                If intRowsAffected = 1 Then
                    MessageBox.Show("Update successful")
                Else
                    MessageBox.Show("Update failed")
                End If

                ' close the database connection
                CloseDatabaseConnection()

                Close()
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
    End Sub
    Private Sub Get_And_Validate_Inputs(ByRef strFirstName As String, ByRef strLastName As String, ByRef strAddress As String, ByRef strCity As String, ByRef intState As Integer, ByRef strZipCode As String, ByRef strPhoneNumber As String, ByRef strEmail As String, ByRef strUserID As String, ByRef strPassword As String, ByRef strDateofBirth As String, ByRef blnValidated As Boolean)
        Get_And_Validate_FirstName(strFirstName, blnValidated, txtFirstName)
        If blnValidated = True Then
            Get_And_Validate_LastName(strLastName, blnValidated, txtLastName)
            If blnValidated = True Then
                Get_And_Validate_Address(strAddress, blnValidated, txtAddress)
                If blnValidated = True Then
                    Get_And_Validate_City(strCity, blnValidated, txtCity)
                    If blnValidated = True Then
                        Get_And_Validate_State(intState, blnValidated, cboState)
                        If blnValidated = True Then
                            Get_And_Validate_ZIPCode(strZipCode, blnValidated, txtZipCode)
                            If blnValidated = True Then
                                Get_And_Validate_PhoneNumber(strPhoneNumber, blnValidated, txtPhoneNumber)
                                If blnValidated = True Then
                                    Get_And_Validate_Email(strEmail, blnValidated, txtEmail)
                                    If blnValidated = True Then
                                        Get_And_Validate_PassengerUserIDUpd(strUserID, blnValidated, txtUserID)
                                        If blnValidated = True Then
                                            Get_And_Validate_Password(strPassword, blnValidated, txtPassword)
                                            If blnValidated = True Then
                                                Confirm_Password(strPassword, blnValidated, txtConfirmPassword)
                                                If blnValidated = True Then
                                                    Get_And_Validate_DateofBirth(strDateofBirth, blnValidated, dtpDateofBirth)
                                                End If
                                            End If
                                        End If
                                    End If
                                End If
                            End If
                        End If
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Close()
    End Sub
End Class
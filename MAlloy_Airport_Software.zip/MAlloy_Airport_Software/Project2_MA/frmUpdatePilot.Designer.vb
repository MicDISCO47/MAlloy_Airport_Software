﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmUpdatePilot
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.txtEmployeeID = New System.Windows.Forms.TextBox()
        Me.cboPilotRole = New System.Windows.Forms.ComboBox()
        Me.dtpDateofHire = New System.Windows.Forms.DateTimePicker()
        Me.dtpDateofTermination = New System.Windows.Forms.DateTimePicker()
        Me.dtpDateofLicense = New System.Windows.Forms.DateTimePicker()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.txtUserID = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txtLastName
        '
        Me.txtLastName.Location = New System.Drawing.Point(134, 34)
        Me.txtLastName.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(128, 20)
        Me.txtLastName.TabIndex = 38
        '
        'txtFirstName
        '
        Me.txtFirstName.Location = New System.Drawing.Point(134, 5)
        Me.txtFirstName.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(128, 20)
        Me.txtFirstName.TabIndex = 37
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(9, 36)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(121, 19)
        Me.Label3.TabIndex = 36
        Me.Label3.Text = "Last Name"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(9, 7)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(121, 19)
        Me.Label2.TabIndex = 35
        Me.Label2.Text = "First Name"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(9, 65)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(121, 19)
        Me.Label1.TabIndex = 39
        Me.Label1.Text = "Employee ID"
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(9, 94)
        Me.Label4.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(121, 19)
        Me.Label4.TabIndex = 40
        Me.Label4.Text = "Date of Hire"
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(9, 123)
        Me.Label5.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(121, 19)
        Me.Label5.TabIndex = 41
        Me.Label5.Text = "Date of Termination"
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(9, 152)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(121, 19)
        Me.Label6.TabIndex = 42
        Me.Label6.Text = "Date of License"
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(9, 181)
        Me.Label7.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(121, 19)
        Me.Label7.TabIndex = 43
        Me.Label7.Text = "Pilot Role"
        '
        'btnUpdate
        '
        Me.btnUpdate.Location = New System.Drawing.Point(43, 269)
        Me.btnUpdate.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(96, 54)
        Me.btnUpdate.TabIndex = 44
        Me.btnUpdate.Text = "Update"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(208, 269)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(96, 54)
        Me.btnExit.TabIndex = 45
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'txtEmployeeID
        '
        Me.txtEmployeeID.Location = New System.Drawing.Point(134, 63)
        Me.txtEmployeeID.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.txtEmployeeID.Name = "txtEmployeeID"
        Me.txtEmployeeID.Size = New System.Drawing.Size(128, 20)
        Me.txtEmployeeID.TabIndex = 46
        '
        'cboPilotRole
        '
        Me.cboPilotRole.FormattingEnabled = True
        Me.cboPilotRole.Location = New System.Drawing.Point(134, 179)
        Me.cboPilotRole.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.cboPilotRole.Name = "cboPilotRole"
        Me.cboPilotRole.Size = New System.Drawing.Size(120, 21)
        Me.cboPilotRole.TabIndex = 47
        '
        'dtpDateofHire
        '
        Me.dtpDateofHire.Location = New System.Drawing.Point(134, 92)
        Me.dtpDateofHire.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dtpDateofHire.Name = "dtpDateofHire"
        Me.dtpDateofHire.Size = New System.Drawing.Size(193, 20)
        Me.dtpDateofHire.TabIndex = 48
        '
        'dtpDateofTermination
        '
        Me.dtpDateofTermination.Location = New System.Drawing.Point(134, 121)
        Me.dtpDateofTermination.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dtpDateofTermination.Name = "dtpDateofTermination"
        Me.dtpDateofTermination.Size = New System.Drawing.Size(193, 20)
        Me.dtpDateofTermination.TabIndex = 49
        '
        'dtpDateofLicense
        '
        Me.dtpDateofLicense.Location = New System.Drawing.Point(134, 150)
        Me.dtpDateofLicense.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.dtpDateofLicense.Name = "dtpDateofLicense"
        Me.dtpDateofLicense.Size = New System.Drawing.Size(193, 20)
        Me.dtpDateofLicense.TabIndex = 50
        '
        'txtPassword
        '
        Me.txtPassword.Location = New System.Drawing.Point(134, 238)
        Me.txtPassword.Margin = New System.Windows.Forms.Padding(2)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.Size = New System.Drawing.Size(128, 20)
        Me.txtPassword.TabIndex = 74
        '
        'txtUserID
        '
        Me.txtUserID.Location = New System.Drawing.Point(134, 209)
        Me.txtUserID.Margin = New System.Windows.Forms.Padding(2)
        Me.txtUserID.Name = "txtUserID"
        Me.txtUserID.Size = New System.Drawing.Size(128, 20)
        Me.txtUserID.TabIndex = 73
        '
        'Label9
        '
        Me.Label9.Location = New System.Drawing.Point(9, 239)
        Me.Label9.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(121, 19)
        Me.Label9.TabIndex = 72
        Me.Label9.Text = "Pilot Password"
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(9, 210)
        Me.Label8.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(121, 19)
        Me.Label8.TabIndex = 71
        Me.Label8.Text = "Pilot UserID"
        '
        'frmUpdatePilot
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(347, 332)
        Me.Controls.Add(Me.txtPassword)
        Me.Controls.Add(Me.txtUserID)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.dtpDateofLicense)
        Me.Controls.Add(Me.dtpDateofTermination)
        Me.Controls.Add(Me.dtpDateofHire)
        Me.Controls.Add(Me.cboPilotRole)
        Me.Controls.Add(Me.txtEmployeeID)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtLastName)
        Me.Controls.Add(Me.txtFirstName)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "frmUpdatePilot"
        Me.Text = "Update Pilot"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtLastName As TextBox
    Friend WithEvents txtFirstName As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents btnUpdate As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents txtEmployeeID As TextBox
    Friend WithEvents cboPilotRole As ComboBox
    Friend WithEvents dtpDateofHire As DateTimePicker
    Friend WithEvents dtpDateofTermination As DateTimePicker
    Friend WithEvents dtpDateofLicense As DateTimePicker
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents txtUserID As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
End Class

﻿Public Class frmAddFlight
    Private Sub frmAddFlight_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim strSelect As String = ""
        Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement
        Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to
        Dim dtf As DataTable = New DataTable ' this is the table we will load from our reader for Airports From
        Dim dtt As DataTable = New DataTable ' this is the table we will load from our reader for Airports From
        Dim dtp As DataTable = New DataTable ' this is the table we will load from our reader for Planes

        Try
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            strSelect = "SELECT * From TAirports"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            dtf.Load(drSourceTable)

            cboAirportFrom.ValueMember = "intAirportID"
            cboAirportFrom.DisplayMember = "strAirportCity"
            cboAirportFrom.DataSource = dtf

            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            strSelect = "SELECT * From TAirports"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            dtt.Load(drSourceTable)

            cboAirportTo.ValueMember = "intAirportID"
            cboAirportTo.DisplayMember = "strAirportCity"
            cboAirportTo.DataSource = dtt

            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            strSelect = "SELECT * From TPlanes"

            ' Retrieve all the records 
            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            dtp.Load(drSourceTable)

            cboPlanes.ValueMember = "intPlaneID"
            cboPlanes.DisplayMember = "strPlaneNumber"
            cboPlanes.DataSource = dtp

            drSourceTable.Close()

            ' close the database connection
            CloseDatabaseConnection()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub cboAirportFrom_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboAirportFrom.SelectedIndexChanged
        Dim strSelect As String = ""
        Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement
        Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to

        Try
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            strSelect = "Select * From TAirports " &
                "Where intAirportID = " & cboAirportFrom.SelectedValue

            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            drSourceTable.Read()

            lblAirportFrom.Text = drSourceTable("strAirportCode")

            drSourceTable.Close()

            ' close the database connection
            CloseDatabaseConnection()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub cboAirportTo_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cboAirportTo.SelectedIndexChanged
        Dim strSelect As String = ""
        Dim cmdSelect As OleDb.OleDbCommand ' this will be used for our Select statement
        Dim drSourceTable As OleDb.OleDbDataReader ' this will be where our data is retrieved to

        Try
            If OpenDatabaseConnectionSQLServer() = False Then

                ' No, warn the user ...
                MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                    "The application will now close.",
                                    Me.Text + " Error",
                                    MessageBoxButtons.OK, MessageBoxIcon.Error)

                ' and close the form/application
                Me.Close()

            End If

            strSelect = "Select * From TAirports " &
                "Where intAirportID = " & cboAirportTo.SelectedValue

            cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
            drSourceTable = cmdSelect.ExecuteReader
            drSourceTable.Read()

            lblAirportTo.Text = drSourceTable("strAirportCode")

            drSourceTable.Close()

            ' close the database connection
            CloseDatabaseConnection()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Close()
    End Sub

    Private Sub btnAddFlight_Click(sender As Object, e As EventArgs) Handles btnAddFlight.Click
        Dim strFlightDate As String
        Dim strFlightNumber As String
        Dim strTimeofDeparture As String
        Dim strTimeofArrival As String
        Dim intAirportFrom As Integer
        Dim intAirportTo As Integer
        Dim intTotalMiles As Integer
        Dim intPlane As Integer

        Dim blnValidated As Boolean

        Dim strSelect As String
        Dim strInsert As String
        Dim cmdSelect As OleDb.OleDbCommand ' select command object
        Dim cmdInsert As OleDb.OleDbCommand ' insert command object
        Dim drSourceTable As OleDb.OleDbDataReader ' data reader for pulling info
        Dim intNextPrimaryKey As Integer ' holds next highest PK value
        Dim intRowsAffected As Integer  ' how many rows were affected when sql executed

        blnValidated = True
        Get_And_Validate_Inputs(strFlightDate, strFlightNumber, strTimeofDeparture, strTimeofArrival, intAirportFrom, intAirportTo, intTotalMiles, intPlane, blnValidated)

        If blnValidated = True Then
            Try
                If OpenDatabaseConnectionSQLServer() = False Then

                    ' No, warn the user ...
                    MessageBox.Show(Me, "Database connection error." & vbNewLine &
                                        "The application will now close.",
                                        Me.Text + " Error",
                                        MessageBoxButtons.OK, MessageBoxIcon.Error)

                    ' and close the form/application
                    Me.Close()

                End If

                strSelect = "Select MAX(intFlightID) + 1 As intNextPrimaryKey From TFlights"

                ' Execute command
                cmdSelect = New OleDb.OleDbCommand(strSelect, m_conAdministrator)
                drSourceTable = cmdSelect.ExecuteReader

                ' Read result( highest ID )
                drSourceTable.Read()

                ' Null? (empty table)
                If drSourceTable.IsDBNull(0) = True Then

                    ' Yes, start numbering at 1
                    intNextPrimaryKey = 1

                Else

                    ' No, get the next highest ID
                    intNextPrimaryKey = CInt(drSourceTable("intNextPrimaryKey"))

                End If

                strInsert = "INSERT INTO TFlights (intFlightID, dtmFlightDate, strFlightNumber,  dtmTimeofDeparture, dtmTimeOfLanding, intFromAirportID, intToAirportID, intMilesFlown, intPlaneID)" &
                    " VALUES (" & intNextPrimaryKey & ",'" & strFlightDate & "','" & strFlightNumber & "','" & strTimeofDeparture & "','" & strTimeofArrival & "', " & intAirportFrom & ", " & intAirportTo & ", " & intTotalMiles & ", " & intPlane & ")"

                ' use insert command with sql string and connection object
                cmdInsert = New OleDb.OleDbCommand(strInsert, m_conAdministrator)

                ' execute query to insert data
                intRowsAffected = cmdInsert.ExecuteNonQuery()

                ' If not 0 insert successful
                If intRowsAffected > 0 Then
                    MessageBox.Show("Flight has been added")    ' let user know success
                    ' close new player form
                End If


            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End If
    End Sub

    Private Sub Get_And_Validate_Inputs(ByRef strFlightDate As String, ByRef strFlightNumber As String, ByRef strTimeofDeparture As String, ByRef strTimeofArrival As String, ByRef intAirportFrom As Integer, ByRef intAirportTo As Integer, ByRef intTotalMiles As Integer, ByRef intPlane As Integer, ByRef blnValidated As Boolean)
        Get_And_Validate_FlightDate(strFlightDate, blnValidated)
        If blnValidated = True Then
            Get_And_Validate_FlightNumber(strFlightNumber, blnValidated)
            If blnValidated = True Then
                strTimeofDeparture = dtpTimeofDeparture.Value
                strTimeofArrival = dtpTimeofLanding.Value
                Get_And_Validate_AirportFrom(intAirportFrom, blnValidated)
                If blnValidated = True Then
                    Get_And_Validate_AirportTo(intAirportFrom, intAirportTo, blnValidated)
                    If blnValidated = True Then
                        Get_And_Validate_TotalMiles(intTotalMiles, blnValidated)
                        If blnValidated = True Then
                            Get_And_Validate_Plane(intPlane, blnValidated)
                        End If
                    End If
                End If
            End If
        End If
    End Sub

    Private Sub Get_And_Validate_FlightDate(ByRef strFlightDate As String, ByRef blnValidated As Boolean)
        If dtpFlightDate.Value <= Today Then
            blnValidated = False
            MessageBox.Show("Invalid flight date.")
        Else
            strFlightDate = dtpFlightDate.Value
            blnValidated = True
        End If
    End Sub

    Private Sub Get_And_Validate_FlightNumber(ByRef strFlightNumber As String, ByRef blnValidated As Boolean)
        If txtFlightNumber.Text.Trim = String.Empty Then
            blnValidated = False
            MessageBox.Show("Input a flight number.")
            txtFlightNumber.Focus()
        Else
            If Integer.TryParse(txtFlightNumber.Text.Trim, strFlightNumber) Then
                If txtFlightNumber.Text.Trim.Length = 3 Then
                    blnValidated = True
                    strFlightNumber = txtFlightNumber.Text.Trim.ToString()
                Else
                    blnValidated = False
                    MessageBox.Show("Flight number must be three numbers long.")
                    txtFlightNumber.Focus()
                End If
            Else
                blnValidated = False
                MessageBox.Show("Input an integer for Flight Number.")
                txtFlightNumber.Focus()
            End If
        End If
    End Sub

    Private Sub Get_And_Validate_AirportFrom(ByRef intAirportFrom As Integer, ByRef blnValidated As Boolean)
        If cboAirportFrom.Text = String.Empty Then
            blnValidated = False
            MessageBox.Show("Input an airport to depart from.")
            cboAirportFrom.Focus()
        Else
            intAirportFrom = cboAirportFrom.SelectedValue
            blnValidated = True
        End If
    End Sub

    Private Sub Get_And_Validate_AirportTo(ByRef intAirportFrom As Integer, ByRef intAirportTo As Integer, ByRef blnValidated As Boolean)
        If cboAirportTo.Text = String.Empty Then
            blnValidated = False
            MessageBox.Show("Input an airport to land in.")
            cboAirportTo.Focus()
        Else
            If cboAirportTo.SelectedValue = cboAirportFrom.SelectedValue Then
                blnValidated = False
                MessageBox.Show("The airport you land in can't be the same as the one you depart from.")
                cboAirportTo.Focus()
            Else
                intAirportTo = cboAirportTo.SelectedValue
                blnValidated = True
            End If
        End If
    End Sub

    Private Sub Get_And_Validate_TotalMiles(ByRef intTotalMiles As Integer, ByRef blnValidated As Boolean)
        If txtTotalMiles.Text = String.Empty Then
            blnValidated = False
            MessageBox.Show("Input a number of miles in Total Miles.")
            txtTotalMiles.Focus()
        Else
            If Integer.TryParse(txtTotalMiles.Text, intTotalMiles) Then
                If intTotalMiles <= 0 Then
                    blnValidated = False
                    MessageBox.Show("Total Miles must be an integer greater than 0.")
                    txtTotalMiles.Focus()
                Else
                    blnValidated = True
                    intTotalMiles = txtTotalMiles.Text
                End If
            Else
                blnValidated = False
                MessageBox.Show("Total Miles must be an integer greater than 0.")
                txtTotalMiles.Focus()
            End If
        End If
    End Sub

    Private Sub Get_And_Validate_Plane(ByRef intPlane As Integer, ByRef blnValidated As Boolean)
        If cboPlanes.Text = String.Empty Then
            blnValidated = False
            MessageBox.Show("Input an airplane.")
            cboAirportFrom.Focus()
        Else
            intPlane = cboPlanes.SelectedValue
            blnValidated = True
        End If
    End Sub

End Class
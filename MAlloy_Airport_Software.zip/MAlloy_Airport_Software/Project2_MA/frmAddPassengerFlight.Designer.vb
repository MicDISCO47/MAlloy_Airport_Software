﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAddPassengerFlight
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.cboFutureFlights = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.lblIsFull = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lblReserveCost = New System.Windows.Forms.Label()
        Me.lblNormalCost = New System.Windows.Forms.Label()
        Me.radReserveSeat = New System.Windows.Forms.RadioButton()
        Me.radNoReservation = New System.Windows.Forms.RadioButton()
        Me.btnBookFlight = New System.Windows.Forms.Button()
        Me.lblSeat = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cboFutureFlights
        '
        Me.cboFutureFlights.FormattingEnabled = True
        Me.cboFutureFlights.Location = New System.Drawing.Point(123, 26)
        Me.cboFutureFlights.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.cboFutureFlights.Name = "cboFutureFlights"
        Me.cboFutureFlights.Size = New System.Drawing.Size(155, 24)
        Me.cboFutureFlights.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(27, 28)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(74, 16)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Book Flight"
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(279, 204)
        Me.btnClose.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(121, 73)
        Me.btnClose.TabIndex = 5
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'lblIsFull
        '
        Me.lblIsFull.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblIsFull.Location = New System.Drawing.Point(319, 23)
        Me.lblIsFull.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblIsFull.Name = "lblIsFull"
        Me.lblIsFull.Size = New System.Drawing.Size(169, 28)
        Me.lblIsFull.TabIndex = 7
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lblReserveCost)
        Me.GroupBox1.Controls.Add(Me.lblNormalCost)
        Me.GroupBox1.Controls.Add(Me.radReserveSeat)
        Me.GroupBox1.Controls.Add(Me.radNoReservation)
        Me.GroupBox1.Location = New System.Drawing.Point(31, 57)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4)
        Me.GroupBox1.Size = New System.Drawing.Size(335, 98)
        Me.GroupBox1.TabIndex = 8
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Available Prices"
        '
        'lblReserveCost
        '
        Me.lblReserveCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblReserveCost.Location = New System.Drawing.Point(184, 49)
        Me.lblReserveCost.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblReserveCost.Name = "lblReserveCost"
        Me.lblReserveCost.Size = New System.Drawing.Size(143, 28)
        Me.lblReserveCost.TabIndex = 10
        '
        'lblNormalCost
        '
        Me.lblNormalCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblNormalCost.Location = New System.Drawing.Point(184, 17)
        Me.lblNormalCost.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblNormalCost.Name = "lblNormalCost"
        Me.lblNormalCost.Size = New System.Drawing.Size(143, 28)
        Me.lblNormalCost.TabIndex = 9
        '
        'radReserveSeat
        '
        Me.radReserveSeat.AutoSize = True
        Me.radReserveSeat.Location = New System.Drawing.Point(9, 57)
        Me.radReserveSeat.Margin = New System.Windows.Forms.Padding(4)
        Me.radReserveSeat.Name = "radReserveSeat"
        Me.radReserveSeat.Size = New System.Drawing.Size(111, 20)
        Me.radReserveSeat.TabIndex = 1
        Me.radReserveSeat.Text = "Reserve Seat"
        Me.radReserveSeat.UseVisualStyleBackColor = True
        '
        'radNoReservation
        '
        Me.radNoReservation.AutoSize = True
        Me.radNoReservation.Location = New System.Drawing.Point(9, 23)
        Me.radNoReservation.Margin = New System.Windows.Forms.Padding(4)
        Me.radNoReservation.Name = "radNoReservation"
        Me.radNoReservation.Size = New System.Drawing.Size(149, 20)
        Me.radNoReservation.TabIndex = 0
        Me.radNoReservation.Text = "Get Seat at Check-In"
        Me.radNoReservation.UseVisualStyleBackColor = True
        '
        'btnBookFlight
        '
        Me.btnBookFlight.Enabled = False
        Me.btnBookFlight.Location = New System.Drawing.Point(123, 204)
        Me.btnBookFlight.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.btnBookFlight.Name = "btnBookFlight"
        Me.btnBookFlight.Size = New System.Drawing.Size(121, 73)
        Me.btnBookFlight.TabIndex = 9
        Me.btnBookFlight.Text = "Book Flight"
        Me.btnBookFlight.UseVisualStyleBackColor = True
        '
        'lblSeat
        '
        Me.lblSeat.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSeat.Location = New System.Drawing.Point(373, 106)
        Me.lblSeat.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblSeat.Name = "lblSeat"
        Me.lblSeat.Size = New System.Drawing.Size(83, 28)
        Me.lblSeat.TabIndex = 10
        '
        'frmAddPassengerFlight
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(523, 303)
        Me.Controls.Add(Me.lblSeat)
        Me.Controls.Add(Me.btnBookFlight)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.lblIsFull)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cboFutureFlights)
        Me.Margin = New System.Windows.Forms.Padding(3, 2, 3, 2)
        Me.Name = "frmAddPassengerFlight"
        Me.Text = "Add Passenger to Flight"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents cboFutureFlights As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnClose As Button
    Friend WithEvents lblIsFull As Label
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents lblReserveCost As Label
    Friend WithEvents lblNormalCost As Label
    Friend WithEvents radReserveSeat As RadioButton
    Friend WithEvents radNoReservation As RadioButton
    Friend WithEvents btnBookFlight As Button
    Friend WithEvents lblSeat As Label
End Class

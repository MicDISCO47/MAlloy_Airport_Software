﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAddFlight
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dtpFlightDate = New System.Windows.Forms.DateTimePicker()
        Me.txtFlightNumber = New System.Windows.Forms.TextBox()
        Me.dtpTimeofDeparture = New System.Windows.Forms.DateTimePicker()
        Me.dtpTimeofLanding = New System.Windows.Forms.DateTimePicker()
        Me.cboAirportFrom = New System.Windows.Forms.ComboBox()
        Me.cboAirportTo = New System.Windows.Forms.ComboBox()
        Me.txtTotalMiles = New System.Windows.Forms.TextBox()
        Me.cboPlanes = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.btnAddFlight = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.lblAirportFrom = New System.Windows.Forms.Label()
        Me.lblAirportTo = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'dtpFlightDate
        '
        Me.dtpFlightDate.Location = New System.Drawing.Point(154, 9)
        Me.dtpFlightDate.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpFlightDate.Name = "dtpFlightDate"
        Me.dtpFlightDate.Size = New System.Drawing.Size(244, 22)
        Me.dtpFlightDate.TabIndex = 0
        '
        'txtFlightNumber
        '
        Me.txtFlightNumber.Location = New System.Drawing.Point(156, 54)
        Me.txtFlightNumber.Margin = New System.Windows.Forms.Padding(4)
        Me.txtFlightNumber.Name = "txtFlightNumber"
        Me.txtFlightNumber.Size = New System.Drawing.Size(140, 22)
        Me.txtFlightNumber.TabIndex = 1
        '
        'dtpTimeofDeparture
        '
        Me.dtpTimeofDeparture.Format = System.Windows.Forms.DateTimePickerFormat.Time
        Me.dtpTimeofDeparture.Location = New System.Drawing.Point(156, 99)
        Me.dtpTimeofDeparture.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpTimeofDeparture.Name = "dtpTimeofDeparture"
        Me.dtpTimeofDeparture.ShowUpDown = True
        Me.dtpTimeofDeparture.Size = New System.Drawing.Size(119, 22)
        Me.dtpTimeofDeparture.TabIndex = 2
        Me.dtpTimeofDeparture.Value = New Date(2025, 4, 2, 0, 0, 0, 0)
        '
        'dtpTimeofLanding
        '
        Me.dtpTimeofLanding.Format = System.Windows.Forms.DateTimePickerFormat.Time
        Me.dtpTimeofLanding.Location = New System.Drawing.Point(156, 144)
        Me.dtpTimeofLanding.Margin = New System.Windows.Forms.Padding(4)
        Me.dtpTimeofLanding.Name = "dtpTimeofLanding"
        Me.dtpTimeofLanding.ShowUpDown = True
        Me.dtpTimeofLanding.Size = New System.Drawing.Size(119, 22)
        Me.dtpTimeofLanding.TabIndex = 3
        Me.dtpTimeofLanding.Value = New Date(2025, 4, 2, 0, 0, 0, 0)
        '
        'cboAirportFrom
        '
        Me.cboAirportFrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboAirportFrom.FormattingEnabled = True
        Me.cboAirportFrom.Location = New System.Drawing.Point(156, 189)
        Me.cboAirportFrom.Name = "cboAirportFrom"
        Me.cboAirportFrom.Size = New System.Drawing.Size(121, 24)
        Me.cboAirportFrom.TabIndex = 4
        '
        'cboAirportTo
        '
        Me.cboAirportTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboAirportTo.FormattingEnabled = True
        Me.cboAirportTo.Location = New System.Drawing.Point(156, 236)
        Me.cboAirportTo.Name = "cboAirportTo"
        Me.cboAirportTo.Size = New System.Drawing.Size(121, 24)
        Me.cboAirportTo.TabIndex = 5
        '
        'txtTotalMiles
        '
        Me.txtTotalMiles.Location = New System.Drawing.Point(156, 283)
        Me.txtTotalMiles.Margin = New System.Windows.Forms.Padding(4)
        Me.txtTotalMiles.Name = "txtTotalMiles"
        Me.txtTotalMiles.Size = New System.Drawing.Size(140, 22)
        Me.txtTotalMiles.TabIndex = 6
        '
        'cboPlanes
        '
        Me.cboPlanes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPlanes.FormattingEnabled = True
        Me.cboPlanes.Location = New System.Drawing.Point(156, 328)
        Me.cboPlanes.Name = "cboPlanes"
        Me.cboPlanes.Size = New System.Drawing.Size(121, 24)
        Me.cboPlanes.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(29, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(120, 23)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Flight Date"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(29, 54)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(120, 23)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "Flight Number"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(29, 98)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(120, 23)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "Time of Departure"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(29, 146)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(120, 23)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "Time of Arrival"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label5
        '
        Me.Label5.Location = New System.Drawing.Point(27, 190)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(120, 23)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "Airport From"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(27, 233)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(120, 28)
        Me.Label6.TabIndex = 17
        Me.Label6.Text = "Airport To"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label7
        '
        Me.Label7.Location = New System.Drawing.Point(29, 282)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(120, 23)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "Total Miles"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(27, 329)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(120, 23)
        Me.Label8.TabIndex = 19
        Me.Label8.Text = "Plane"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnAddFlight
        '
        Me.btnAddFlight.Location = New System.Drawing.Point(110, 391)
        Me.btnAddFlight.Name = "btnAddFlight"
        Me.btnAddFlight.Size = New System.Drawing.Size(104, 53)
        Me.btnAddFlight.TabIndex = 24
        Me.btnAddFlight.Text = "Add Flight"
        Me.btnAddFlight.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(243, 391)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(104, 53)
        Me.btnClose.TabIndex = 25
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'lblAirportFrom
        '
        Me.lblAirportFrom.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAirportFrom.Location = New System.Drawing.Point(283, 189)
        Me.lblAirportFrom.Name = "lblAirportFrom"
        Me.lblAirportFrom.Size = New System.Drawing.Size(122, 23)
        Me.lblAirportFrom.TabIndex = 26
        Me.lblAirportFrom.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAirportTo
        '
        Me.lblAirportTo.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAirportTo.Location = New System.Drawing.Point(283, 238)
        Me.lblAirportTo.Name = "lblAirportTo"
        Me.lblAirportTo.Size = New System.Drawing.Size(122, 23)
        Me.lblAirportTo.TabIndex = 27
        Me.lblAirportTo.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'frmAddFlight
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(417, 465)
        Me.Controls.Add(Me.lblAirportTo)
        Me.Controls.Add(Me.lblAirportFrom)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnAddFlight)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cboPlanes)
        Me.Controls.Add(Me.txtTotalMiles)
        Me.Controls.Add(Me.cboAirportTo)
        Me.Controls.Add(Me.cboAirportFrom)
        Me.Controls.Add(Me.dtpTimeofLanding)
        Me.Controls.Add(Me.dtpTimeofDeparture)
        Me.Controls.Add(Me.txtFlightNumber)
        Me.Controls.Add(Me.dtpFlightDate)
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "frmAddFlight"
        Me.Text = "Add Flight"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dtpFlightDate As DateTimePicker
    Friend WithEvents txtFlightNumber As TextBox
    Friend WithEvents dtpTimeofDeparture As DateTimePicker
    Friend WithEvents dtpTimeofLanding As DateTimePicker
    Friend WithEvents cboAirportFrom As ComboBox
    Friend WithEvents cboAirportTo As ComboBox
    Friend WithEvents txtTotalMiles As TextBox
    Friend WithEvents cboPlanes As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents btnAddFlight As Button
    Friend WithEvents btnClose As Button
    Friend WithEvents lblAirportFrom As Label
    Friend WithEvents lblAirportTo As Label
End Class

﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDeletePilot
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnDeletePassenger = New System.Windows.Forms.Button()
        Me.cboPilots = New System.Windows.Forms.ComboBox()
        Me.a = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(205, 106)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(139, 65)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnDeletePassenger
        '
        Me.btnDeletePassenger.Location = New System.Drawing.Point(41, 106)
        Me.btnDeletePassenger.Name = "btnDeletePassenger"
        Me.btnDeletePassenger.Size = New System.Drawing.Size(139, 65)
        Me.btnDeletePassenger.TabIndex = 6
        Me.btnDeletePassenger.Text = "Delete Pilot"
        Me.btnDeletePassenger.UseVisualStyleBackColor = True
        '
        'cboPilots
        '
        Me.cboPilots.FormattingEnabled = True
        Me.cboPilots.Location = New System.Drawing.Point(205, 30)
        Me.cboPilots.Name = "cboPilots"
        Me.cboPilots.Size = New System.Drawing.Size(147, 24)
        Me.cboPilots.TabIndex = 5
        '
        'a
        '
        Me.a.Location = New System.Drawing.Point(38, 33)
        Me.a.Name = "a"
        Me.a.Size = New System.Drawing.Size(142, 23)
        Me.a.TabIndex = 4
        Me.a.Text = "Pilot To Delete"
        '
        'frmDeletePilot
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(390, 214)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnDeletePassenger)
        Me.Controls.Add(Me.cboPilots)
        Me.Controls.Add(Me.a)
        Me.Name = "frmDeletePilot"
        Me.Text = "Delete Pilot"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents btnDeletePassenger As Button
    Friend WithEvents cboPilots As ComboBox
    Friend WithEvents a As Label
End Class
